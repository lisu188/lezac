import gzip
import hashlib
import json
from pathlib import Path
import shutil

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/recovery/evidence/bios_menu_input_20261001"
SHM = Path("/dev/shm")
assert not OUT.exists()
OUT.mkdir()

cases = {
    "control_one": "lezac-original-main-ctrl-one-typing-20261001",
    "control_two": "lezac-original-main-ctrl-two-typing-settled-20261001",
    "control_noncharacters": "lezac-original-main-control-noncharacters-20261001",
    "enhanced_functions": "lezac-original-main-enhanced-function-typing-20261001",
    "alt_one": "lezac-original-main-alt-keypad-one-typing-20261001",
    "alt_language": "lezac-original-main-alt-keypad-language-20261001",
    "alt_zero": "lezac-original-alt-zero-overflow-typing-20261001",
    "alt_modulo": "lezac-original-alt-modulo-language-20261001",
    "alt_release": "lezac-original-alt-two-release-language-20261001",
    "alt_overlap": "lezac-original-alt-overlap-following-keypad-20261001",
    "alt_interruption": "lezac-original-alt-raw-interruption-language-20261001",
    "alt_tab": "lezac-original-alt-tab-typing-20261001",
    "control_valid": "lezac-original-control-valid-typing-20261001",
    "control_two_transitional_failure": "lezac-original-main-ctrl-two-typing-20261001",
    "alt_chord_failure": "lezac-original-alt-interruption-language-20261001",
    "cpp_control_one_negative": "lezac-cpp-main-ctrl-one-typing-negative-20261001",
    "cpp_cleanup_failure": "lezac-bios-menu-physical-20261001/lezac-bios-menu-59_bcs62/noncharacters",
    "cpp_noncharacters": "lezac-bios-menu-physical-20261001/lezac-bios-menu-soat01ft/noncharacters",
    "cpp_intro": "lezac-bios-menu-physical-20261001/lezac-bios-menu-soat01ft/intro",
    "cpp_composition": "lezac-bios-menu-physical-20261001/lezac-bios-menu-soat01ft/composition",
}
manifest = dict(schema=1, whole_game_parity=False, manual_input=False, cases={}, images={}, files={})

def sha(data):
    return hashlib.sha256(data).hexdigest()

def retain(path, name):
    shutil.copyfile(path, OUT / name)
    manifest["files"][name] = sha((OUT / name).read_bytes())

manifest["original_exe_sha256"] = sha((ROOT / "LEZAC.EXE").read_bytes())
for name, directory in cases.items():
    directory = SHM / directory
    record = json.loads((directory / "result.json").read_bytes())
    field = "harness_sha256" if "scenario" in record else "observer_sha256"
    source = directory / "observer.py"
    if not source.exists():
        source = directory.parent / "observer.py"
    data = source.read_bytes()
    assert sha(data) == record[field], (name, "exact source missing")
    source_name = "source_" + sha(data) + ".py.gz"
    (OUT / source_name).write_bytes(gzip.compress(data, mtime=0))
    manifest["files"][source_name] = sha((OUT / source_name).read_bytes())
    retain(directory / "result.json", name + ".json")
    manifest["cases"][name] = dict(record=name + ".json", source=source_name,
                                   raw_directory=str(directory), status=record["status"])

images = {
    "original_control_ignored": ("control_noncharacters", "after-choice-0.2"),
    "cpp_control_negative": ("cpp_control_one_negative", "after-choice-0.2"),
    "original_english": ("alt_language", "english-ready-control"),
    "cpp_english": ("cpp_composition", "alt-108-released-english"),
    "cpp_control_fixed": ("cpp_noncharacters", "control-noncharacter-0"),
    "cpp_intro_consumed": ("cpp_intro", "intro-alt-release-consumed-skip"),
}
for name, (case, capture) in images.items():
    source = SHM / cases[case] / (capture + ".png")
    record = json.loads((OUT / (case + ".json")).read_bytes())
    digest = sha(Image.open(source).convert("RGB").tobytes())
    assert digest == next(row["pixel_sha256"] for row in record["captures"] if row["name"] == capture)
    retain(source, name + ".png")
    manifest["images"][name] = dict(file=name + ".png", case=case, capture=capture, pixel_sha256=digest)
assert manifest["images"]["original_english"]["pixel_sha256"] == manifest["images"]["cpp_english"]["pixel_sha256"]
manifest["producer_sha256"] = sha(Path(__file__).read_bytes())
(OUT / "producer.py.gz").write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
manifest["files"]["producer.py.gz"] = sha((OUT / "producer.py.gz").read_bytes())
(OUT / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
print(json.dumps(dict(records=len(cases), images=len(images), files=len(manifest["files"]),
                     manifest_sha256=sha((OUT / "manifest.json").read_bytes()),
                     english_pixel_sha256=manifest["images"]["original_english"]["pixel_sha256"])))
