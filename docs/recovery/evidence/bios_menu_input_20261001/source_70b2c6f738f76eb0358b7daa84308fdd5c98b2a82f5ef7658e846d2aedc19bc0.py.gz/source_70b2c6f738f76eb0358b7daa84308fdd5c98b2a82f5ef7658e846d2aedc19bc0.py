import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from PIL import Image, ImageGrab

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
import capture_original_startup_rng as startup
from check_main_menu_fixture import HEADER, load_fixture

parser = argparse.ArgumentParser()
parser.add_argument('--version', choices=('original', 'cpp'), required=True)
parser.add_argument('--exe', type=Path)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--keys', nargs='+', default=['Return'])
parser.add_argument('--expected', choices=['italian', 'english', 'intro', 'page', 'skip'], default='italian')
parser.add_argument('--stage', choices=['ready', 'typing'], default='ready')
args = parser.parse_args()
output = args.out.resolve()
startup.require(not output.exists() and os.environ.get('DISPLAY') and
                os.environ.get('SDL_AUDIODRIVER') == 'dummy', 'fresh silent private capture required')
output.mkdir(parents=True)
_, expected = load_fixture()
session = startup.Session(output) if args.version == 'original' else None
child = None
log = None
env = dict(os.environ, SDL_AUDIODRIVER='dummy', SDL_VIDEODRIVER='x11', SDL_RENDER_DRIVER='software')
result = dict(status='capturing', version=args.version, audio='dummy', gameplay_seeded=False,
              delay_gates=False, physical_keys=True, manual_input=False, events=[], captures=[],
              observer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
result['probe_keys'] = args.keys
result['expected_after_input'] = args.expected
result['stage'] = args.stage
try:
    if session:
        result.update(session.launch(clock_only=True))
        child, window = session.child, session.window
    else:
        startup.require(args.exe is not None, 'C++ executable required')
        exe = args.exe.resolve()
        result['exe_sha256'] = hashlib.sha256(exe.read_bytes()).hexdigest()
        log = (output / 'process.log').open('w')
        child = subprocess.Popen([str(exe)], cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 15
        window = None
        while time.monotonic() < deadline:
            try:
                window = subprocess.check_output(['xdotool', 'search', '--pid', str(child.pid), '--name', 'Larax'],
                    env=env, text=True, stderr=subprocess.DEVNULL, timeout=5).split()[-1]
                break
            except (subprocess.CalledProcessError, IndexError):
                time.sleep(.01)
        startup.require(window is not None, 'owned window not found')

    def xdo(*command):
        return subprocess.check_output(['xdotool', *command], env=env, text=True, timeout=5).strip()

    xdo('windowfocus', '--sync', window)
    geometry = dict(line.split('=', 1) for line in xdo('getwindowgeometry', '--shell', window).splitlines())
    x, y, w, h = (int(geometry[key]) for key in ('X', 'Y', 'WIDTH', 'HEIGHT'))
    startup.require((w, h) == ((320, 200) if session else (960, 600)), 'owned window geometry')

    def frame():
        return ImageGrab.grab(xdisplay=env['DISPLAY']).crop((x, y, x+w, y+h)).convert('RGB').resize(
            (320, 200), Image.Resampling.NEAREST)

    def is_intro(image):
        colors = image.crop((0, 0, 320, 80)).getcolors(25600)
        return bool(colors and len(colors) == 7 and min(count for count, _ in colors) > 1000)

    def original_input_bytes():
        data = session.base + (session.data_segment << 4)
        return dict(bios_flags_417=session.read(session.base + 0x417, 1)[0],
                    bios_buffer_head_41a=int.from_bytes(session.read(session.base + 0x41a, 2), 'little'),
                    bios_buffer_tail_41c=int.from_bytes(session.read(session.base + 0x41c, 2), 'little'),
                    last_menu_character_2058=session.read(data + 0x2058, 1)[0],
                    player_count_79b8=session.read(data + 0x79b8, 1)[0],
                    language_79cc=session.read(data + 0x79cc, 1)[0])

    def capture(name, image=None):
        image = frame() if image is None else image
        image.save(output / (name + '.png'))
        image.resize((960, 600), Image.Resampling.NEAREST).save(output / (name + '-preview.png'))
        result['captures'].append(dict(name=name, seconds=time.monotonic() - started,
            full_menu=image.tobytes() == expected['italian-full'][len(HEADER):],
            english_full=image.tobytes() == expected['english-full'][len(HEADER):],
            intro=is_intro(image),
            pixel_sha256=hashlib.sha256(image.tobytes()).hexdigest()))

    def key(name):
        result['events'].append(dict(kind='press', key=name, seconds=time.monotonic() - started))
        if name.startswith('down:'):
            xdo('keydown', name[5:])
        elif name.startswith('up:'):
            xdo('keyup', name[3:])
        elif name.startswith('raw:'):
            x11 = ctypes.CDLL('libX11.so.6')
            xtst = ctypes.CDLL('libXtst.so.6')
            x11.XOpenDisplay.argtypes = [ctypes.c_char_p]
            x11.XOpenDisplay.restype = ctypes.c_void_p
            x11.XFlush.argtypes = [ctypes.c_void_p]
            x11.XCloseDisplay.argtypes = [ctypes.c_void_p]
            xtst.XTestFakeKeyEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_ulong]
            display = x11.XOpenDisplay(env['DISPLAY'].encode())
            startup.require(display, 'private X display unavailable')
            try:
                for down in (1, 0):
                    startup.require(xtst.XTestFakeKeyEvent(display, int(name[4:]), down, 0), 'raw key event failed')
                    x11.XFlush(display)
                    time.sleep(.04)
            finally:
                x11.XCloseDisplay(display)
        else:
            xdo('key', '--delay', '0', name)

    started = time.monotonic()
    deadline = started + 25
    while time.monotonic() < deadline:
        startup.require(child.poll() is None, 'owned app exited early')
        image = frame()
        target = 'italian-full' if args.stage == 'ready' else 'italian-line0-step06'
        if image.tobytes() == expected[target][len(HEADER):]:
            capture('menu-ready' if args.stage == 'ready' else 'typing-checkpoint', image)
            break
        time.sleep(.005)
    else:
        raise RuntimeError('complete original-backed menu pixels not reached')
    if args.stage == 'ready':
        time.sleep(.3)
    if session:
        result['before_rng'] = session.sample('before-menu-choice')
        result['before_input_bytes'] = original_input_bytes()
    result['x_keyboard_before'] = subprocess.check_output(['xset', 'q'], env=env, text=True, timeout=5)
    for value in args.keys:
        key(value)
        time.sleep(.05)
        if session:
            result['events'][-1]['after_input_bytes'] = original_input_bytes()
    result['x_keyboard_after'] = subprocess.check_output(['xset', 'q'], env=env, text=True, timeout=5)
    pressed = time.monotonic()
    for elapsed in (.05, .2, .5, 1.0, 2.5):
        time.sleep(max(0, pressed + elapsed - time.monotonic()))
        capture('after-choice-' + str(elapsed))
    if session:
        result['after_input_bytes'] = original_input_bytes()
    if args.expected in ('italian', 'skip'):
        if args.stage == 'typing' and args.expected == 'skip':
            startup.require(all(row['full_menu'] for row in result['captures'] if row['name'].startswith('after-choice-')),
                            'probe key did not skip menu typing')
        elif args.stage == 'typing':
            startup.require(all(not row['full_menu'] for row in result['captures']), 'probe key skipped menu typing')
            if session:
                startup.require(all(result['before_input_bytes'][name] == result['after_input_bytes'][name]
                                    for name in ('bios_buffer_head_41a', 'bios_buffer_tail_41c')),
                                'probe changed the original BIOS character queue')
            key('raw:10')
            deadline = time.monotonic() + 3
            while time.monotonic() < deadline:
                image = frame()
                if image.tobytes() == expected['italian-full'][len(HEADER):]:
                    capture('fresh-key-typing-skip-control', image)
                    time.sleep(.3)
                    break
                time.sleep(.005)
            else:
                raise RuntimeError('fresh physical digit did not skip typing')
        else:
            startup.require(all(row['full_menu'] for row in result['captures']),
                            'probe keys changed the ready main menu')
    elif args.expected == 'english':
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            image = frame()
            if image.tobytes() == expected['english-full'][len(HEADER):]:
                capture('english-ready-control', image)
                time.sleep(.3)
                break
            time.sleep(.005)
        else:
            raise RuntimeError('probe keys did not reach the completed English menu')
    elif args.expected == 'page':
        startup.require(session and result['after_input_bytes']['last_menu_character_2058'] in (105, 122),
                        'page alias did not expose a lowercase menu character')
        startup.require(not any(result['captures'][-1][name] for name in ('full_menu', 'english_full', 'intro')),
                        'page alias did not leave the main menu')
    else:
        startup.require(result['captures'][-1]['intro'], 'keypad selection did not reach the intro')
    if args.expected == 'page':
        result['positive_selection_control'] = False
        result['page_navigation_observed'] = False
    else:
        if args.expected != 'intro':
            key('raw:10')
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            image = frame()
            if is_intro(image):
                capture('fresh-one-intro-control', image)
                break
            time.sleep(.005)
        else:
            raise RuntimeError('fresh 1 did not open the level intro after ignored probe keys')
        result['positive_selection_control'] = True
        if session:
            result['selection_control_bytes'] = original_input_bytes()
    result['status'] = 'observed'
except Exception as error:
    result.update(status='failed', error=str(error))
    raise
finally:
    if child is None and session is not None:
        child = session.child
    if child is not None:
        if session:
            session.close()
            result['hooks_restored'] = len(session.restored)
        elif child.poll() is None:
            for _ in range(4):
                subprocess.run(['xdotool', 'key', 'Escape'], env=env, check=False, timeout=5)
                time.sleep(.15)
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                child.terminate()
                child.wait(timeout=5)
        result['child_exit_code'] = child.returncode
    if log is not None:
        log.close()
    (output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
