#!/usr/bin/env python3
"""Package the verified second capture and a fresh production replay."""

import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
RAW = Path("/dev/shm/lezac-original-boss-active-combat-20261001-v2")
EXE = Path("/dev/shm/lezac-main-menu-test-build-20260930/lezac_cpp")
OUT = Path("/dev/shm/lezac-boss-active-combat-seal-20261001")
EVIDENCE = ROOT / "docs/recovery/evidence/boss_active_combat_20261001"
FIXTURE = ROOT / "tests/fixtures/boss_active_combat_original_level7.txt.gz"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    if os.environ.get("SDL_AUDIODRIVER") != "dummy" or os.environ.get("SDL_VIDEODRIVER") != "dummy":
        raise RuntimeError("packaging replay must be silent/headless")
    if EVIDENCE.exists() or FIXTURE.exists() or OUT.exists():
        raise RuntimeError("packaging output exists")
    metadata = json.loads((RAW / "trace.candidate.json").read_bytes())
    if metadata["status"] != "captured_candidate" or metadata["observer_exit_code"] or not metadata["hooks_restored"]:
        raise RuntimeError("original capture is not complete and restored")
    if any(child["returncode"] is None for child in metadata["owned_dosbox"]):
        raise RuntimeError("original child still running")
    capture = (RAW / "trace.txt").read_bytes()
    replay = subprocess.run([str(EXE), "--debug-boss-active-combat-original", str(RAW / "trace.txt"), str(OUT)],
                            cwd=ROOT, capture_output=True, text=True, timeout=60)
    if replay.returncode or "different_pixels=0" not in replay.stdout or "input_reentry=1" not in replay.stdout:
        raise RuntimeError("fresh production replay failed: " + replay.stdout + replay.stderr)
    EVIDENCE.mkdir()
    FIXTURE.write_bytes(gzip.compress(capture, mtime=0))
    shutil.copyfile(RAW / "trace.candidate.json", EVIDENCE / "original.json")
    for item in metadata["sources"].values():
        source = RAW / item["file"]
        if sha(gzip.decompress(source.read_bytes())) != item["sha256"]:
            raise RuntimeError("original source archive changed")
        shutil.copyfile(source, EVIDENCE / source.name)
    source = (ROOT / "src/app/app.cpp").read_bytes()
    (EVIDENCE / "cpp_source.cpp.gz").write_bytes(gzip.compress(source, mtime=0))
    result = dict(status="passed", audio="dummy", video="dummy", exit_code=replay.returncode,
                  stdout=replay.stdout, stderr=replay.stderr, exe_sha256=sha(EXE.read_bytes()),
                  source_sha256=sha(source), source_lf_sha256=sha(source.replace(b"\r\n", b"\n")),
                  production_replay=True, whole_game_parity=False, physical_keyboard=False)
    (EVIDENCE / "cpp.json").write_text(json.dumps(result, indent=2) + "\n", encoding="ascii")
    image_hashes = {}
    for version, source in (("original", RAW / "trace_latched_fire_even_799.ppm"),
                            ("cpp", OUT / "latched_fire_even_799.ppm")):
        raw = source.read_bytes()
        (EVIDENCE / (version + "_799.ppm.gz")).write_bytes(gzip.compress(raw, mtime=0))
        frame = Image.open(source).convert("RGB")
        if frame.size != (312, 152):
            raise RuntimeError("unexpected preview dimensions")
        image_hashes[version] = sha(frame.tobytes())
        frame.resize((936, 456), Image.Resampling.NEAREST).save(EVIDENCE / (version + "_799.png"))
    if image_hashes["original"] != image_hashes["cpp"]:
        raise RuntimeError("preview pixels differ")
    producer = Path(__file__).read_bytes()
    (EVIDENCE / "producer.py.gz").write_bytes(gzip.compress(producer, mtime=0))
    manifest = dict(schema=1, fixture=str(FIXTURE.relative_to(ROOT)).replace("\\", "/"),
                    fixture_sha256=sha(FIXTURE.read_bytes()), trace_sha256=sha(capture),
                    original_exe_sha256=sha((ROOT / "LEZAC.EXE").read_bytes()),
                    producer_sha256=sha(producer), images=image_hashes,
                    whole_game_parity=False, natural_campaign=False, physical_keyboard=False,
                    sources_lf={name: sha(gzip.decompress((EVIDENCE / item["file"]).read_bytes()).replace(b"\r\n", b"\n"))
                                for name, item in metadata["sources"].items()},
                    files={path.name: sha(path.read_bytes()) for path in sorted(EVIDENCE.iterdir())})
    raw = (json.dumps(manifest, indent=2) + "\n").encode("ascii")
    (EVIDENCE / "manifest.json").write_bytes(raw)
    print("manifest_sha256=" + sha(raw))
    print("trace_sha256=" + sha(capture))
    print("sealed_bytes=" + str(sum(p.stat().st_size for p in EVIDENCE.iterdir()) + FIXTURE.stat().st_size))
    print(replay.stdout, end="")


if __name__ == "__main__":
    main()
