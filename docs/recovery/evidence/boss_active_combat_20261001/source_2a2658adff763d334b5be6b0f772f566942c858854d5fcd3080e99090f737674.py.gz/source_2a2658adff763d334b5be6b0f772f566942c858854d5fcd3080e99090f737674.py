#!/usr/bin/env python3
"""Retain candidate outcome and exact sources without claiming C++ parity."""

import gzip
import hashlib
import json
import os
from pathlib import Path
import struct
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
import capture_original_boss_defeat as boss


def main():
    output = Path(sys.argv[sys.argv.index("--out") + 1]).resolve()
    metadata = output.with_suffix(".candidate.json")
    if metadata.exists() or output.exists():
        raise RuntimeError("candidate exists; use a fresh output")
    if os.environ.get("SDL_AUDIODRIVER") != "dummy" or not os.environ.get("DISPLAY"):
        raise RuntimeError("candidate requires dummy audio and private Xvfb")
    free = os.statvfs(output.parent)
    if free.f_bavail * free.f_frsize < 64 * 1024 * 1024:
        raise RuntimeError("insufficient RAM output reserve")
    record = dict(status="running", audio="dummy", physical_keyboard=False,
                  natural_campaign=False, whole_game_parity=False, production_replay=False,
                  head_health_modified=False, seeded_bomb=False, sources={}, owned_dosbox=[])
    sources = {Path(__file__).resolve()}
    sources.update(Path(module.__file__).resolve() for module in list(sys.modules.values())
                   if getattr(module, "__file__", None) and
                   Path(module.__file__).resolve().is_relative_to(ROOT / "tools"))
    for source in sorted(sources):
        raw = source.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        archive = output.with_name("source_" + digest + ".py.gz")
        if archive.exists():
            raise RuntimeError("candidate source archive exists")
        archive.write_bytes(gzip.compress(raw, mtime=0))
        record["sources"][str(source.relative_to(ROOT))] = dict(sha256=digest, file=archive.name)

    def persist():
        metadata.write_text(json.dumps(record, indent=2) + "\n", encoding="ascii")

    original_capture = boss.capture

    def capture(pid, base, target, image, *args):
        ds = base + (boss.seeder.RUNTIME_DS << 4)
        cs = base + (boss.actors.CS << 4)
        with open(f"/proc/{pid}/mem", "rb", buffering=0) as memory:
            raw = os.pread(memory.fileno(), 38, ds + 0x1BD4)
        record["head_before_warmup"] = dict(raw=raw.hex(), lives=raw[2], hp=raw[36])
        persist()
        original_capture(pid, base, target, image, *args)
        with open(f"/proc/{pid}/mem", "rb", buffering=0) as memory:
            runtime_cs = struct.unpack("<H", os.pread(memory.fileno(), 2, cs + 0xF802))[0]
            expected = bytearray(image)
            expected[0x2C72:0x2C77] = boss.INTRO_CALL[:3] + struct.pack("<H", 0x084A + runtime_cs)
            record["hooks_restored"] = all(
                os.pread(memory.fileno(), size, cs + at) == expected[at:at + size]
                for at, size in boss.REENTRY_HOOKS)
        if not record["hooks_restored"]:
            raise RuntimeError("candidate hooks not restored")
        persist()

    original_popen = boss.seeder.subprocess.Popen
    children = []

    def popen(*args, **kwargs):
        process = original_popen(*args, **kwargs)
        command = args[0] if args else kwargs.get("args")
        if isinstance(command, (list, tuple)) and Path(str(command[0])).name == "dosbox":
            children.append(process)
        return process

    boss.capture = capture
    boss.seeder.subprocess.Popen = popen
    os.environ["LEZAC_BOSS_DEFEAT_XVFB"] = "1"
    started = time.monotonic()
    persist()
    try:
        code = boss.main()
        record.update(status="captured_candidate" if code == 0 else "failed", observer_exit_code=code)
        return code
    except BaseException as error:
        record.update(status="failed", error=str(error), error_type=type(error).__name__)
        raise
    finally:
        record["elapsed_seconds"] = time.monotonic() - started
        record["owned_dosbox"] = [dict(pid=child.pid, returncode=child.poll()) for child in children]
        record["child_cleanup"] = "established_seeder_finally_terminates_owned_dosbox"
        persist()


if __name__ == "__main__":
    raise SystemExit(main())
