#!/usr/bin/env python3
"""Bind a portable AST representation without rewriting captured Python 3.12."""

import ast
import gzip
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
EVIDENCE = ROOT / "docs/recovery/evidence/boss_extended_combat_20261001"
OUT = Path("/dev/shm/lezac-boss-extended-sealed-replay-20261001/ast-proof")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(node):
    if isinstance(node, ast.AST):
        return dict(type=type(node).__name__, fields={key: encode(value) for key, value in ast.iter_fields(node)})
    if isinstance(node, list):
        return [encode(value) for value in node]
    if isinstance(node, bytes):
        return {"bytes": node.hex()}
    if node is None or isinstance(node, (str, int, float, bool)):
        return node
    raise RuntimeError("unhandled AST value")


def main():
    if sys.version_info < (3, 12) or OUT.exists():
        raise RuntimeError("proof requires original observer grammar and fresh output")
    original = json.loads((EVIDENCE / "original.json").read_bytes())
    item = original["sources"]["generated/extended_boss_observer.py"]
    source = gzip.decompress((EVIDENCE / item["file"]).read_bytes())
    if sha(source) != item["sha256"]:
        raise RuntimeError("captured observer changed")
    tree = ast.parse(source)
    record = dict(schema=1, python_version=list(sys.version_info[:3]), source_sha256=sha(source), tree=encode(tree))
    OUT.mkdir()
    proof = gzip.compress((json.dumps(record, separators=(",", ":")) + "\n").encode("ascii"), mtime=0)
    (OUT / "observer_ast.json.gz").write_bytes(proof)
    producer = gzip.compress(Path(__file__).read_bytes(), mtime=0)
    (OUT / "observer_ast_producer.py.gz").write_bytes(producer)
    previous_manifest = (EVIDENCE / "manifest.json").read_bytes()
    (OUT / "previous_manifest.json").write_bytes(previous_manifest)
    manifest = json.loads(previous_manifest)
    for name, data in (("observer_ast.json.gz", proof), ("observer_ast_producer.py.gz", producer)):
        if (EVIDENCE / name).exists():
            raise RuntimeError("proof output exists")
        (EVIDENCE / name).write_bytes(data)
        manifest["files"][name] = sha(data)
    manifest["observer_ast_producer_sha256"] = sha(Path(__file__).read_bytes())
    raw = (json.dumps(manifest, indent=2) + "\n").encode("ascii")
    (EVIDENCE / "manifest.json").write_bytes(raw)
    print(json.dumps(dict(manifest_sha256=sha(raw), observer_source_sha256=sha(source),
                          observer_ast_bytes=len(proof), ast_production_python=record["python_version"]), indent=2))


if __name__ == "__main__":
    main()
