#!/usr/bin/env python3
"""Bind retained original combat to a fresh silent continuous C++ replay."""

import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
RAW = Path("/dev/shm/lezac-original-boss-extended-combat-20261001-v4")
FAILED = Path("/dev/shm/lezac-boss-extended-replay-20261001")
EXE = Path("/dev/shm/lezac-main-menu-test-build-20260930/lezac_cpp")
OUT = Path("/dev/shm/lezac-boss-extended-sealed-replay-20261001")
EVIDENCE = ROOT / "docs/recovery/evidence/boss_extended_combat_20261001"
FIXTURE = ROOT / "tests/fixtures/boss_extended_combat_original_level7.txt.gz"
TRACE_SHA = "1e5425c095ac833b577647d63b6aebd3a8803fbc6eef348ac7903f951ee27ce9"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(record):
    return (json.dumps(record, indent=2) + "\n").encode("ascii")


def main():
    if os.environ.get("SDL_AUDIODRIVER") != "dummy" or os.environ.get("SDL_VIDEODRIVER") != "dummy":
        raise RuntimeError("sealing requires silent headless replay")
    if EVIDENCE.exists() or OUT.exists() or FIXTURE.exists():
        raise RuntimeError("sealed output already exists")
    if shutil.disk_usage("/dev/shm").free < 128 * 1024 * 1024:
        raise RuntimeError("RAM reserve")
    raw = (RAW / "trace.txt").read_bytes()
    original = json.loads((RAW / "trace.candidate.json").read_bytes())
    if sha(raw) != TRACE_SHA or original["trace_sha256"] != TRACE_SHA:
        raise RuntimeError("retained original trace changed")
    source = (ROOT / "src/app/app.cpp").read_bytes()
    executable_sha = sha(EXE.read_bytes())
    result = subprocess.run([str(EXE), "--debug-boss-extended-combat-original", str(RAW / "trace.txt"), str(OUT)],
                            cwd=ROOT, capture_output=True, text=True, timeout=90)
    required = ("samples=3200", "views=15 compared_pixels=711360 different_pixels=0", "shots=96 reentries=10",
                "defeat_sample=1714 cleanup_sample=1833", "whole_game_parity=0")
    if result.returncode or any(value not in result.stdout for value in required):
        raise RuntimeError("extended production replay failed: " + result.stdout + result.stderr)
    if (ROOT / "src/app/app.cpp").read_bytes() != source or sha(EXE.read_bytes()) != executable_sha:
        raise RuntimeError("replay source/executable changed during sealing")
    images = {}
    staged = OUT / "evidence"
    staged.mkdir()
    shutil.copyfile(RAW / "trace.candidate.json", staged / "original.json")
    sources_lf = {}
    for name, item in original["sources"].items():
        archive = (RAW / item["file"]).read_bytes()
        captured = gzip.decompress(archive)
        if sha(captured) != item["sha256"]:
            raise RuntimeError("capture source archive changed")
        (staged / item["file"]).write_bytes(archive)
        if name.startswith("tools/"):
            normalized = sha(captured.replace(b"\r\n", b"\n"))
            if sha((ROOT / name).read_bytes().replace(b"\r\n", b"\n")) != normalized:
                raise RuntimeError("current capture source changed")
            sources_lf[name] = normalized
    for name in ("failed-replay.json", "failed_source.cpp.gz"):
        shutil.copyfile(FAILED / name, staged / name)
    for sample in (1599, 2399, 3199):
        original_ppm = (RAW / f"trace_latched_fire_even_{sample}.ppm").read_bytes()
        cpp_ppm = (OUT / f"latched_fire_even_{sample}.ppm").read_bytes()
        if original_ppm != cpp_ppm:
            raise RuntimeError("original/C++ PPM mismatch")
        for version, ppm in (("original", original_ppm), ("cpp", cpp_ppm)):
            name = f"{version}_{sample}"
            frame = Image.open(RAW / f"trace_latched_fire_even_{sample}.ppm" if version == "original" else
                               OUT / f"latched_fire_even_{sample}.ppm").convert("RGB")
            if frame.size != (312, 152):
                raise RuntimeError("preview dimensions")
            images[name] = sha(frame.tobytes())
            (staged / (name + ".ppm.gz")).write_bytes(gzip.compress(ppm, mtime=0))
            frame.resize((936, 456), Image.Resampling.NEAREST).save(staged / (name + ".png"))
    replay = dict(status="passed", exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr,
                  source_sha256=sha(source), source_lf_sha256=sha(source.replace(b"\r\n", b"\n")),
                  executable_sha256=executable_sha, trace_sha256=TRACE_SHA, audio="dummy", video="dummy",
                  production_replay=True, natural_campaign=False, physical_keyboard=False, whole_game_parity=False)
    (staged / "cpp.json").write_bytes(json_bytes(replay))
    (staged / "cpp_source.cpp.gz").write_bytes(gzip.compress(source, mtime=0))
    producer = Path(__file__).read_bytes()
    (staged / "producer.py.gz").write_bytes(gzip.compress(producer, mtime=0))
    packed = gzip.compress(raw, mtime=0)
    manifest = dict(schema=1, fixture=FIXTURE.relative_to(ROOT).as_posix(), fixture_sha256=sha(packed),
                    trace_sha256=TRACE_SHA, original_exe_sha256=sha((ROOT / "LEZAC.EXE").read_bytes()),
                    producer_sha256=sha(producer), images=images, whole_game_parity=False, natural_campaign=False,
                    physical_keyboard=False, sources_lf=sources_lf,
                    files={path.name: sha(path.read_bytes()) for path in sorted(staged.iterdir())})
    manifest_raw = json_bytes(manifest)
    (staged / "manifest.json").write_bytes(manifest_raw)
    total = len(packed) + sum(path.stat().st_size for path in staged.iterdir())
    if total > 3 * 1024 * 1024:
        raise RuntimeError("small evidence-write budget exceeded")
    # All large/raw artifacts stay in RAM; only the compact recovery fixture is promoted.
    shutil.copytree(staged, EVIDENCE)
    FIXTURE.write_bytes(packed)
    print(result.stdout, end="")
    print(json.dumps(dict(manifest_sha256=sha(manifest_raw), fixture_sha256=sha(packed),
                          trace_sha256=TRACE_SHA, files=len(manifest["files"]), bytes=total,
                          source_sha256=replay["source_sha256"], images=images), indent=2))


if __name__ == "__main__":
    main()
