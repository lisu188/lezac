#!/usr/bin/env python3
"""Version the existing observer for a longer unpromoted original combat run."""

import ast
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import struct
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
OUT = Path("/dev/shm/lezac-original-boss-extended-combat-20261001-v4")
TEMPLATE_SHA = "395e5baa223c8f228d0655de7f800f864173fd8f8708a935db8a3e4a4c8d012d"
SAMPLES = 3200
VIEWS = (0, 1, 15, 16, 20, 39, 59, 99, 199, 399, 599, 799, 1599, 2399, 3199)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def observer_variant():
    source = (ROOT / "tools/capture_original_boss_defeat.py").read_bytes()
    if sha(source.replace(b"\r\n", b"\n")) != TEMPLATE_SHA:
        raise RuntimeError("observer template changed")
    tree = ast.parse(source)
    changes = dict(root=0, views=0, samples=0, summary=0, header=0)

    class Extend(ast.NodeTransformer):
        def visit_Assign(self, node):
            names = [target.id for target in node.targets if isinstance(target, ast.Name)]
            if names == ["ROOT"]:
                node.value = ast.Call(func=ast.Name(id="Path", ctx=ast.Load()),
                                      args=[ast.Constant(str(ROOT))], keywords=[])
                changes["root"] += 1
            elif names == ["COMBAT_VIEWS"]:
                node.value = ast.Tuple(elts=[ast.Constant(value) for value in VIEWS], ctx=ast.Load())
                changes["views"] += 1
            elif len(node.targets) == 1 and isinstance(node.targets[0], ast.Tuple) and \
                    [getattr(value, "id", None) for value in node.targets[0].elts] == ["cases", "samples", "views"] and \
                    isinstance(node.value, ast.Tuple) and isinstance(node.value.elts[1], ast.Constant) and \
                    node.value.elts[1].value == 800:
                node.value.elts[1] = ast.Constant(SAMPLES)
                changes["samples"] += 1
            return self.generic_visit(node)

        def visit_IfExp(self, node):
            if isinstance(node.test, ast.Attribute) and isinstance(node.test.value, ast.Name) and \
                    node.test.value.id == "args" and node.test.attr == "active_combat" and \
                    isinstance(node.body, ast.Constant) and node.body.value == 800:
                node.body = ast.Constant(SAMPLES)
                changes["summary"] += 1
            return self.generic_visit(node)

        def visit_Constant(self, node):
            old = ("capture=boss_active_combat_original_v1 level=7 temp_copy=1 seeded_case_boundary=1"
                   " head_health_modified=0 seeded_bomb=0 latched_input=1 physical_keyboard=0"
                   " per_tick_actor_seed=0 natural_campaign=0")
            if node.value == old:
                node.value = old.replace("boss_active_combat_original_v1", "boss_extended_combat_candidate_v1")
                changes["header"] += 1
            return node

    tree = ast.fix_missing_locations(Extend().visit(tree))
    if changes != dict(root=1, views=1, samples=1, summary=1, header=1):
        raise RuntimeError("unexpected observer parameter locations: " + str(changes))
    generated = (ast.unparse(tree) + "\n").encode("ascii")
    variant = OUT / "extended_boss_observer.py"
    variant.write_bytes(generated)
    return variant, source, changes


def main():
    if os.environ.get("SDL_AUDIODRIVER") != "dummy" or not os.environ.get("DISPLAY"):
        raise RuntimeError("extended capture requires dummy audio and private Xvfb")
    if OUT.exists():
        raise RuntimeError("capture output exists")
    reserve = os.statvfs(OUT.parent)
    if reserve.f_bavail * reserve.f_frsize < 128 * 1024 * 1024:
        raise RuntimeError("insufficient RAM reserve")
    OUT.mkdir()
    variant, template, changes = observer_variant()
    sys.path.insert(0, str(ROOT / "tools"))
    spec = importlib.util.spec_from_file_location("lezac_extended_boss_observer", variant)
    boss = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = boss
    spec.loader.exec_module(boss)
    run_dir = OUT / "run"
    run_dir.mkdir()
    assets = dict.fromkeys((*boss.environment.REQUIRED_ASSETS, "FONTS.SPR", "PROVA.SPR", "GRAN.MST",
                          "RECS.DAT", "SETUP.LOG", "ENGLISH.DOC", "ITALIANO.DOC"))
    for name in assets:
        if Path(name).name != name:
            raise RuntimeError("invalid asset name")
        shutil.copyfile(ROOT / name, run_dir / name)
    trace = OUT / "trace.txt"
    metadata = OUT / "trace.candidate.json"
    record = dict(status="running", audio="dummy", requested_samples=SAMPLES, requested_views=list(VIEWS),
                  transformations=changes, template_lf_sha256=TEMPLATE_SHA,
                  head_health_modified=False, seeded_bomb=False, physical_keyboard=False,
                  natural_campaign=False, whole_game_parity=False, production_replay=False,
                  sources={}, owned_dosbox=[], initial_assets={name: sha((run_dir / name).read_bytes()) for name in assets})
    sources = {Path(__file__).resolve(), variant, ROOT / "tools/capture_original_boss_defeat.py"}
    sources.update(Path(module.__file__).resolve() for module in list(sys.modules.values())
                   if getattr(module, "__file__", None) and Path(module.__file__).resolve().is_relative_to(ROOT / "tools"))
    for source in sorted(sources):
        raw = source.read_bytes()
        digest = sha(raw)
        archive = OUT / ("source_" + digest + ".py.gz")
        if archive.exists():
            raise RuntimeError("source archive exists")
        archive.write_bytes(gzip.compress(raw, mtime=0))
        name = str(source.relative_to(ROOT)) if source.is_relative_to(ROOT) else "generated/" + source.name
        record["sources"][name] = dict(sha256=digest, file=archive.name)

    def persist():
        metadata.write_text(json.dumps(record, indent=2) + "\n", encoding="ascii")

    original_capture = boss.capture

    def capture(pid, base, target, image, *args):
        ds = base + (boss.seeder.RUNTIME_DS << 4)
        cs = base + (boss.actors.CS << 4)
        with open(f"/proc/{pid}/mem", "rb", buffering=0) as memory:
            raw = os.pread(memory.fileno(), 38, ds + 0x1BD4)
        record["head_before_warmup"] = dict(raw=raw.hex(), lives=raw[2], hp=raw[36])
        persist()
        if raw[2] != 1 or raw[36] != 10:
            raise RuntimeError("original initial head health differs")
        original_capture(pid, base, target, image, *args)
        with open(f"/proc/{pid}/mem", "rb", buffering=0) as memory:
            runtime_cs = struct.unpack("<H", os.pread(memory.fileno(), 2, cs + 0xF802))[0]
            expected = bytearray(image)
            expected[0x2C72:0x2C77] = boss.INTRO_CALL[:3] + struct.pack("<H", 0x084A + runtime_cs)
            record["hooks_restored"] = all(os.pread(memory.fileno(), size, cs + at) == expected[at:at + size]
                                            for at, size in boss.REENTRY_HOOKS)
        if not record["hooks_restored"]:
            raise RuntimeError("extended capture hooks not restored")
        persist()

    original_popen = boss.seeder.subprocess.Popen
    children = []

    def popen(*args, **kwargs):
        process = original_popen(*args, **kwargs)
        command = args[0] if args else kwargs.get("args")
        if isinstance(command, (list, tuple)) and Path(str(command[0])).name == "dosbox":
            children.append(process)
            record["owned_dosbox"] = [dict(pid=child.pid, returncode=child.poll()) for child in children]
            persist()
            original_terminate = process.terminate

            def terminate():
                if record.get("hooks_restored") is not True and process.poll() is None:
                    screenshot = boss.seeder.subprocess.run(["xdotool", "key", "--clearmodifiers", "ctrl+F5"],
                                                            capture_output=True, timeout=5)
                    time.sleep(0.5)
                    record["cleanup_screenshot"] = dict(exit_code=screenshot.returncode,
                                                         files=[path.name for path in sorted(run_dir.glob("*.png"))])
                    persist()
                original_terminate()

            process.terminate = terminate
        return process

    boss.capture = capture
    boss.seeder.subprocess.Popen = popen
    os.environ["LEZAC_BOSS_DEFEAT_XVFB"] = "1"
    sys.argv = [str(variant), "--active-combat", "--run-dir", str(OUT / "run"), "--out", str(trace),
                "--approve-procmem", "--approve-runtime-instrumentation"]
    started = time.monotonic()
    persist()
    try:
        code = boss.main()
        record.update(status="captured_candidate" if code == 0 else "failed", observer_exit_code=code)
        return code
    except BaseException as error:
        record.update(status="failed", error=str(error), error_type=type(error).__name__)
        raise
    finally:
        record["elapsed_seconds"] = time.monotonic() - started
        record["owned_dosbox"] = [dict(pid=child.pid, returncode=child.poll()) for child in children]
        record["child_cleanup"] = "established_seeder_finally_terminates_owned_dosbox"
        if trace.exists():
            rows = trace.read_text(encoding="ascii").splitlines()
            ticks = [row for row in rows if row.startswith("tick ")]
            record["observed_samples"] = len(ticks)
            record["trace_sha256"] = sha(trace.read_bytes())
            record["completion"] = rows[-1] if rows else ""
            record["head_conversion_sample"] = None
            for row in ticks:
                fields = dict(token.split("=", 1) for token in row.split()[1:])
                first = fields["actors"].split(",", 1)[0].split(":", 1)[0]
                if first != "-" and bytes.fromhex(first)[0] == 14:
                    record["head_conversion_sample"] = int(fields["sample"])
                    break
        persist()


if __name__ == "__main__":
    raise SystemExit(main())
