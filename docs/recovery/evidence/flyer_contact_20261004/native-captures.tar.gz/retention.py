import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

ROOT = Path('/mnt/c/Users/andrz/git/LEZAC')
RAM = Path('/dev/shm')
OUTPUT = RAM / 'lezac-flyer-contact-20261004-native-captures.tar.gz'
usage = shutil.disk_usage(RAM)
assert usage.free - 128 * 1024 * 1024 > usage.total // 10
assert not OUTPUT.exists()
sources = {}
for suffix in ('a', 'b'):
    directory = RAM / ('lezac-flyer-contact-20261004-' + suffix)
    assert directory.is_dir() and not directory.is_symlink()
    for path in directory.iterdir():
        assert path.is_file() and not path.is_symlink()
        sources[f'{suffix}/{path.name}'] = path.read_bytes()
for name in ('capture_original_flyer_contacts.py', 'check_flyer_contact_fixture.py'):
    sources['tools/' + name] = (ROOT / 'tools' / name).read_bytes()
for name in ('negative', 'positive'):
    path = RAM / f'lezac-flyer-contact-20261004-{name}.json'
    sources[name + '.json'] = path.read_bytes()
sources['retention.py'] = Path(__file__).read_bytes()
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name, data in sources.items()}
sources['manifest.json'] = (json.dumps(manifest, sort_keys=True) + '\n').encode()
raw = io.BytesIO()
with tarfile.open(fileobj=raw, mode='w') as archive:
    for name, data in sources.items():
        member = tarfile.TarInfo(name)
        member.size, member.mode, member.mtime = len(data), 0o644, 0
        archive.addfile(member, io.BytesIO(data))
encoded = gzip.compress(raw.getvalue(), compresslevel=9, mtime=0)
assert len(encoded) <= 131072, len(encoded)
with tarfile.open(fileobj=io.BytesIO(encoded), mode='r:gz') as archive:
    assert set(archive.getnames()) == set(sources)
    for member in archive:
        assert member.isfile() and archive.extractfile(member).read() == sources[member.name]
OUTPUT.write_bytes(encoded)
assert OUTPUT.read_bytes() == encoded
receipt = {'complete': True, 'members': len(sources), 'bytes': len(encoded),
           'sha256': hashlib.sha256(encoded).hexdigest(),
           'all_original_files_byte_verified': True, 'private_assets_duplicated': False,
           'negative_diagnostic_commit': 'c8f674c', 'source_assets_pinned_in_captures': True}
path = RAM / 'lezac-flyer-contact-20261004-retention.json'
assert not path.exists()
path.write_text(json.dumps(receipt, sort_keys=True) + '\n')
print(json.dumps(receipt, sort_keys=True))
