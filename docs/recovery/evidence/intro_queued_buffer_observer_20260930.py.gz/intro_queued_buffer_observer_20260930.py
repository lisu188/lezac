import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from PIL import Image, ImageGrab

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
import capture_original_startup_rng as startup
from check_main_menu_fixture import HEADER, load_fixture

output = Path(sys.argv[1]).resolve()
startup.require(not output.exists() and os.environ.get('DISPLAY') and
                os.environ.get('SDL_AUDIODRIVER') == 'dummy', 'fresh silent private capture required')
output.mkdir(parents=True)
session = startup.Session(output)
_, expected = load_fixture()
result = dict(status='capturing', audio='dummy', gameplay_seeded=False, delay_gates=False,
              physical_keys=True, manual_input=False, captures=[], events=[],
              observer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
queued = '--queued' in sys.argv[2:]
result['input_batch_gated'] = queued
try:
    result.update(session.launch(clock_only=True))
    session.xdo('windowfocus', '--sync', session.window)
    geometry = dict(row.split('=', 1) for row in session.xdo('getwindowgeometry', '--shell', session.window).splitlines())
    x, y, w, h = (int(geometry[key]) for key in ('X', 'Y', 'WIDTH', 'HEIGHT'))
    startup.require((w, h) == (320, 200), 'original geometry')
    def frame():
        return ImageGrab.grab(xdisplay=os.environ['DISPLAY']).crop((x, y, x+w, y+h)).convert('RGB')
    def intro(image):
        colors = image.crop((0, 0, 320, 80)).getcolors(25600)
        return len(colors) == 7 and min(count for count, _ in colors) > 1000
    def white(image):
        return sum(count for count, color in image.getcolors(64000) if color == (255,255,255))
    def wait(predicate, timeout=25):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            startup.require(session.child.poll() is None, 'owned child exited')
            image = frame()
            if predicate(image):
                return image
            time.sleep(.005)
        raise RuntimeError('original input checkpoint timed out')
    def capture(name, image=None):
        image = frame() if image is None else image
        image.save(output / (name+'.png'))
        image.resize((960,600), Image.Resampling.NEAREST).save(output / (name+'-preview.png'))
        result['captures'].append(dict(name=name, intro=intro(image), white_pixels=white(image),
            pixel_sha256=hashlib.sha256(image.tobytes()).hexdigest()))
        return image
    def key(name):
        result['events'].append(dict(kind='press', key=name, seconds=time.monotonic()-started))
        session.xdo('key', '--delay', '0', name)
    started = time.monotonic()
    capture('menu-ready', wait(lambda image: image.tobytes() == expected['italian-full'][len(HEADER):]))
    time.sleep(.2)
    result['before_rng'] = session.sample('before-intro-choice')
    key('1')
    image = wait(lambda image: intro(image) and 0 < white(image) < 620)
    capture('intro-typing', image)
    if queued:
        with session.stopped():
            result['events'].append(dict(kind='queued-press', keys=['space', 'Return'], seconds=time.monotonic()-started))
            session.xdo('key', '--delay', '0', 'space', 'Return')
    else:
        key('space')
    time.sleep(.2)
    capture('after-typing-key')
    time.sleep(2)
    capture('after-wait')
    key('Shift_L')
    time.sleep(.2)
    capture('after-modifier')
    key('Return')
    capture('after-fresh-ack', wait(lambda image: not intro(image) and len(image.getcolors(64000)) > 12))
    result['status'] = 'observed'
except Exception as error:
    result.update(status='failed', error=str(error))
    raise
finally:
    session.close()
    result['hooks_restored'] = len(session.restored)
    result['child_exit_code'] = session.child.returncode if session.child else None
    (output/'result.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result), flush=True)
