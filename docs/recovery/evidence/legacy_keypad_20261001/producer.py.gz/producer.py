import gzip
import hashlib
import json
from pathlib import Path
import shutil

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/recovery/evidence/legacy_keypad_20261001"
SHM = Path("/dev/shm")
assert not OUT.exists()
OUT.mkdir()
cases = {
    "original_queue_guard_failure": "lezac-original-alt-keypad-operators-typing-20261001",
    "original_alt_four": "lezac-original-alt-keypad-operators-confirmed-20261001",
    "cpp_alt_negative": "lezac-cpp-alt-keypad-operators-negative-20261001",
    "original_alt_six": "lezac-original-alt-keypad-six-typing-20261001",
    "original_control_five": "lezac-original-control-keypad-five-typing-20261001",
    "original_clock_boundary_failure": "lezac-original-control-keypad-enter-typing-20261001",
    "original_control_enter": "lezac-original-control-keypad-enter-confirmed-20261001",
    "original_decimal_expectation_failure": "lezac-original-alt-keypad-interruption-language-20261001",
    "original_allocation_failure": "lezac-original-alt-keypad-decimal-language-20261001",
    "original_decimal": "lezac-original-alt-keypad-decimal-language-confirmed-20261001",
    "cpp_decimal_negative": "lezac-pr254-alt-keypad-decimal-negative-20261001",
    "original_control_alt_decimal": "lezac-original-alt-control-keypad-decimal-confirmed-20261001",
    "original_unmodified_plus": "lezac-original-unmodified-keypad-plus-typing-20261001",
    "original_control_alt_priority": "lezac-original-control-alt-priority-typing-20261001",
    "cpp_alt_fixed": "lezac-cpp-alt-keypad-operators-fixed-20261001",
    "cpp_decimal_fixed": "lezac-cpp-alt-keypad-decimal-fixed-20261001",
}
for scenario in ("noncharacters", "intro", "composition"):
    cases["cpp_initial_" + scenario] = "lezac-legacy-keypad-physical-20261001/lezac-bios-menu-qyewe8u0/" + scenario
for scenario in ("noncharacters", "intro", "composition", "keypad"):
    cases["cpp_live_" + scenario] = "lezac-legacy-keypad-physical-20261001/lezac-bios-menu-nydg2q1q/" + scenario
manifest = dict(schema=1, whole_game_parity=False, manual_input=False, cases={}, images={}, files={})


def sha(data):
    return hashlib.sha256(data).hexdigest()


def retain(path, name):
    shutil.copyfile(path, OUT / name)
    manifest["files"][name] = sha((OUT / name).read_bytes())


manifest["original_exe_sha256"] = sha((ROOT / "LEZAC.EXE").read_bytes())
for name, directory in cases.items():
    directory = SHM / directory
    record = json.loads((directory / "result.json").read_bytes())
    field = "harness_sha256" if "scenario" in record else "observer_sha256"
    source = directory / "observer.py"
    if not source.exists():
        source = directory.parent / "observer.py"
    data = source.read_bytes()
    assert sha(data) == record[field], (name, "exact source missing")
    source_name = "source_" + sha(data) + ".py.gz"
    (OUT / source_name).write_bytes(gzip.compress(data, mtime=0))
    manifest["files"][source_name] = sha((OUT / source_name).read_bytes())
    retain(directory / "result.json", name + ".json")
    manifest["cases"][name] = dict(record=name + ".json", source=source_name,
                                   raw_directory=str(directory), status=record["status"])

images = {
    "original_filtered": ("original_alt_four", "after-choice-0.2"),
    "cpp_negative": ("cpp_alt_negative", "after-choice-0.2"),
    "cpp_fixed": ("cpp_alt_fixed", "after-choice-0.2"),
    "original_decimal": ("original_decimal", "english-ready-control"),
    "cpp_decimal": ("cpp_decimal_fixed", "english-ready-control"),
    "original_control_enter": ("original_control_enter", "after-choice-0.2"),
    "cpp_intro_control_enter": ("cpp_live_keypad", "control-keypad-enter-consumed-skip"),
    "cpp_gameplay": ("cpp_live_keypad", "fresh-control-keypad-enter-gameplay"),
}
for name, (case, capture) in images.items():
    source = SHM / cases[case] / (capture + ".png")
    record = json.loads((OUT / (case + ".json")).read_bytes())
    digest = sha(Image.open(source).convert("RGB").tobytes())
    assert digest == next(row["pixel_sha256"] for row in record["captures"] if row["name"] == capture)
    retain(source, name + ".png")
    manifest["images"][name] = dict(file=name + ".png", case=case, capture=capture, pixel_sha256=digest)
assert manifest["images"]["original_decimal"]["pixel_sha256"] == manifest["images"]["cpp_decimal"]["pixel_sha256"]
manifest["producer_sha256"] = sha(Path(__file__).read_bytes())
(OUT / "producer.py.gz").write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
manifest["files"]["producer.py.gz"] = sha((OUT / "producer.py.gz").read_bytes())
(OUT / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
print(json.dumps(dict(records=len(cases), images=len(images), files=len(manifest["files"]),
                     manifest_sha256=sha((OUT / "manifest.json").read_bytes()),
                     english_pixel_sha256=manifest["images"]["original_decimal"]["pixel_sha256"])))
