"""Archive the complete, matched V21 replay under the unchanged evidence guards."""
import gzip
import importlib.util
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import level1_fidelity as fidelity
import level1_original as original

SOURCE = Path("/dev/shm/lezac-level-setup-handoff-cpp-20261001-v21")
COMPARISON = Path("/dev/shm/lezac-level-setup-handoff-comparison-20261001-v21")
BASE = ROOT / "build-codex-tmp/archive-completed-handoff-20261001.py"
RETAINED = ROOT / "build-codex-tmp/level-setup-evidence-20261001-v21"
PUBLIC = ROOT / "docs/recovery/evidence/level_setup_2026-10-02"


def copy(source, target):
    fidelity.require(source.is_file() and not source.is_symlink() and not target.exists(), "unsafe archive provenance copy")
    digest = fidelity.sha256(source)
    with source.open("rb") as reader, target.open("xb") as writer:
        shutil.copyfileobj(reader, writer)
    fidelity.require(fidelity.sha256(source) == fidelity.sha256(target) == digest, "archive provenance copy differs")


def main():
    fidelity.require(fidelity.sha256(BASE) == "eb1da5c57f838daf9eca6b80277f8b543fabe5406e0fdc57dc79a135d275a7f9", "archiver changed")
    usage = shutil.disk_usage("/dev/shm")
    fidelity.require(usage.free - 64 * 1024 * 1024 > usage.total // 10, "archive staging crosses reserve")
    report = fidelity.strict_json((COMPARISON / "comparison.json").read_text())
    manifest = fidelity.load_manifest(SOURCE)
    fidelity.require(report["status"] == "match" and report["first_difference"] is None and
                     sum(report["differing_pixels"].values()) == 0 and
                     report["cpp_trace_sha256"] == manifest["trace_sha256"] ==
                     "322f1849139ce0c3e6d2469d34b7d3af383524203441c2345fdd6306ad104b55", "matched full replay changed")
    copies = ((Path(__file__), "level-setup-archive-producer.py"), (BASE, "lossless-archive-producer.py"),
              (COMPARISON / "comparison.json", "matched-comparison.json"),
              (COMPARISON / "comparison-producer.py", "matched-comparison-producer.py"),
              (Path("/dev/shm/lezac-level-setup-focused-20261001-v1.log"), "focused-ctest.log"))
    fidelity.require(sum(path.stat().st_size for path, _ in copies) < 1024 * 1024, "provenance staging exceeds reserve")
    for source, name in copies:
        copy(source, SOURCE / name)
    spec = importlib.util.spec_from_file_location("matched_level_setup_archiver", BASE)
    archiver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(archiver)
    archiver.SOURCE = SOURCE
    archiver.ARCHIVE = SOURCE.with_name(SOURCE.name + ".tar.gz")
    archiver.PROOF = SOURCE.with_name(SOURCE.name + "-archive-verification.json")
    archiver.main()
    proof = fidelity.strict_json(archiver.PROOF.read_text())
    fidelity.require(proof["all_files_byte_verified"] and proof["raw_directory_removed"] and
                     proof["files"]["trace.jsonl"]["sha256"] == report["cpp_trace_sha256"], "archive retention failed")
    planned = archiver.PROOF.stat().st_size * 2 + 1024 * 1024
    fidelity.require(planned < 32 * 1024 * 1024 and shutil.disk_usage(ROOT).free - planned > 1024**3,
                     "compact archival proof crosses backing reserve")
    copy(archiver.PROOF, RETAINED / "archive-verification.json")
    copy(archiver.PROOF, PUBLIC / "archive-verification.json")
    with (PUBLIC / "archive-producer.py.gz").open("xb") as raw, gzip.GzipFile(fileobj=raw, mode="wb", mtime=0) as compressed:
        compressed.write(Path(__file__).read_bytes())
    public_manifest = fidelity.strict_json((PUBLIC / "manifest.json").read_text())
    for name in ("archive-verification.json", "archive-producer.py.gz"):
        path = PUBLIC / name
        public_manifest["files"][name] = {"bytes": path.stat().st_size, "sha256": fidelity.sha256(path)}
    (PUBLIC / "manifest.json").write_bytes(original.json_bytes(public_manifest))
    retention = {"schema": "lezac-private-level-setup-archive-retention-v1", "archive_sha256": proof["archive_sha256"],
                 "archive_bytes": proof["archive_bytes"], "raw_bytes": proof["raw_bytes"], "full_cpp_archive_in_ram": True,
                 "full_cpp_archive_on_backing_disk": False, "raw_directory_removed": True,
                 "comparison_status": "match", "original_fidelity_claim": False, "port_functionally_complete": False}
    (RETAINED / "archive-retention.json").write_bytes(original.json_bytes(retention))
    print(original.json_bytes(retention).decode("ascii"), flush=True)


if __name__ == "__main__":
    main()
