"""Compare the fixed full replay to retained native boundaries and the strict V19 prefix."""
import copy
import hashlib
import importlib.util
from pathlib import Path
import shutil
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import level1_fidelity as fidelity
import level1_handoff as handoff
import level1_original as original
import level1_results as results

OBSERVER = ROOT / "build-codex-tmp/capture-natural-level3-handoff-20261001.py"
OBSERVER_SHA = "98a98127128d7aededb97f92468bcdac790a2eb59a4c425e39ea333de8b5b282"
NATIVE = Path("/dev/shm/lezac-natural-level3-handoff-original-20261001-v20")
CPP = Path("/dev/shm/lezac-level-setup-handoff-cpp-20261001-v21")
OUT = Path("/dev/shm/lezac-level-setup-handoff-comparison-20261001-v21")
PREFIX = Path("/dev/shm/lezac-natural-level2-outcome-results-cpp-20261001-v19")
ARCHIVE = PREFIX.with_name(PREFIX.name + ".tar.gz")
PROOF = PREFIX.with_name(PREFIX.name + "-archive-verification.json")
EXE_SHA = "1e2875688fe9f606f34932819d8de89d27f837abf7793aa8462976f0533b54a7"


def corrected_intro(row, native_projection):
    expected = copy.deepcopy(row)
    state = expected.get("state")
    if expected.get("kind") == "checkpoint" and state["level"] == 2 and state["flow"][3] == 1:
        for index in (0, 1):
            state["progress"][index] = native_projection["progress"][index]
        for index in (0, 1, 2, 5):
            state["hud"][index] = native_projection["hud"][index]
    return expected


def policy_guard(native_projection):
    row = {"kind": "checkpoint", "state": {"level": 2, "flow": [0, 0, 0, 1],
           "progress": [1, 34, 3], "hud": [1, 51, 51, 1, 0, 2, 246], "energy": 100, "rng": 42}}
    before = copy.deepcopy(row)
    expected = corrected_intro(row, native_projection)
    fidelity.require(row == before and expected != row, "intro policy mutated input or did not exercise correction")
    for key in ("energy", "rng"):
        altered = copy.deepcopy(expected)
        altered["state"][key] += 1
        fidelity.require(fidelity.first_difference(expected, altered) is not None, "policy hid unrelated scalar")
    for key, index in (("hud", 6), ("progress", 2), ("flow", 0)):
        altered = copy.deepcopy(expected)
        altered["state"][key][index] += 1
        fidelity.require(fidelity.first_difference(expected, altered) is not None, "policy hid unrelated cell")
    for level, active in ((1, 1), (3, 1), (2, 0)):
        altered = copy.deepcopy(row)
        altered["state"]["level"], altered["state"]["flow"][3] = level, active
        fidelity.require(corrected_intro(altered, native_projection) == altered, "policy escaped Level 2 intro")
    return 8


def image_rgb(path):
    from PIL import Image
    with Image.open(path) as image:
        fidelity.require(image.size == (320, 200), "incorrect native image dimensions")
        return image.convert("RGB").tobytes()


def main():
    fidelity.require(fidelity.sha256(OBSERVER) == OBSERVER_SHA, "native validator changed")
    spec = importlib.util.spec_from_file_location("fixed_handoff_native_validator", OBSERVER)
    observer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(observer)
    base = observer.base_module()
    route_base, events = base.setup()
    route_base.reserve(96 * 1024 * 1024)
    fidelity.require(not OUT.exists() and not (NATIVE / "failure.json").exists(), "output exists or native is incomplete")
    outcome = fidelity.strict_json((NATIVE / "outcome-manifest.json").read_text())
    native_manifest = fidelity.strict_json((NATIVE / "level3-manifest.json").read_text())
    fidelity.require(native_manifest["status"] == "captured" and native_manifest["patches_restored"] is True and
                     native_manifest["producer_sha256"] == OBSERVER_SHA and
                     native_manifest["outcome_manifest_sha256"] == fidelity.sha256(NATIVE / "outcome-manifest.json") and
                     native_manifest["handoff_sha256"] == fidelity.sha256(NATIVE / "level3-handoff.jsonl.gz") ==
                     "f47daa4962c1294c315ccfa66a8d99e074721068abb159a610862d4d4889e69e",
                     "native handoff provenance changed")
    for name, digest in outcome["files"].items():
        fidelity.require(fidelity.sha256(fidelity.safe_file(NATIVE, name)) == digest, "native capture file changed")
    gameplay_rows = handoff.load(NATIVE / "gameplay.jsonl.gz")
    gameplay = base.validate_gameplay(gameplay_rows, events)
    native_reels = base.validate_results(handoff.load(NATIVE / "results.jsonl.gz"),
                                        gameplay[-1]["post"], gameplay_rows[0]["atlas"])
    next_rows = handoff.load(NATIVE / "level3-handoff.jsonl.gz")
    next_samples = observer.validate_rows(next_rows)
    entry_rows = handoff.load(NATIVE / "handoff.jsonl.gz")
    entry_samples = handoff.validate(entry_rows)
    entry_header, next_header = entry_rows[0], next_rows[0]
    level1_reel_header, level1_reels = results.fixture()
    manifest = fidelity.load_manifest(CPP)
    fidelity.require(manifest["asset_sha256"] == outcome["assets"] and manifest["executable_sha256"] == EXE_SHA and
                     (CPP / "route.txt").read_bytes() == (NATIVE / "level3-route.txt").read_bytes() == observer.route_bytes() and
                     manifest["environment"] == {"SDL_AUDIODRIVER": "dummy", "SDL_VIDEODRIVER": "dummy"},
                     "different assets, executable, full route, or audio environment")
    plan = fidelity.strict_json((CPP / "reserve-plan.json").read_text())
    fidelity.require(plan["executable_sha256"] == EXE_SHA and plan["same_full_route"] is True and
                     plan["full_ticks"] == 3788 and plan["producer_sha256"] == fidelity.sha256(CPP / "level-setup-replay-producer.py"),
                     "replay source provenance differs")
    for name, digest in plan["source_sha256"].items():
        fidelity.require(fidelity.sha256(CPP / "cpp-source-snapshots" / name) == fidelity.sha256(ROOT / name) == digest,
                         "tested source snapshot changed")

    # The old prefix is exact except six objective cells during the Level 2 intro.
    # Replacement values come from the retained native bytes, not the new C++ output.
    native_intro = original.project_original(entry_header["intro"], 1, entry_header["atlas"])
    fidelity.require(native_intro["progress"] == [0, 0] and
                     [native_intro["hud"][i] for i in (0, 1, 2, 5)] == [20000, 200, 0, 0], "native reset rule changed")
    guard_cases = policy_guard(native_intro)
    proof = fidelity.strict_json(PROOF.read_text())
    fidelity.require(proof["all_files_byte_verified"] and proof["raw_directory_removed"] and
                     fidelity.sha256(ARCHIVE) == proof["archive_sha256"] ==
                     "9df2660801375f0a62e1b9f4e01d2cc789dc615a052a3a2584981de3dda9e82c", "retained V19 prefix changed")
    first, prefix_records, corrected_records = None, 0, 0
    digest = hashlib.sha256()
    settings, _ = fidelity.read_route(CPP / "route.txt")
    with tarfile.open(ARCHIVE, "r:gz") as archive, (CPP / "trace.jsonl").open("rb") as actual_stream:
        member = archive.getmember(PREFIX.name + "/trace.jsonl")
        fidelity.require(member.isfile() and member.size == proof["files"]["trace.jsonl"]["bytes"], "invalid archived trace")
        for index, line in enumerate(archive.extractfile(member)):
            digest.update(line)
            old = fidelity.strict_json(line.decode("ascii"))
            if old["kind"] == "complete":
                fidelity.require(old["ticks"] == observer.PREFIX_TICKS, "incorrect archived footer")
                continue
            actual_line = actual_stream.readline()
            fidelity.require(actual_line, "truncated prefix")
            actual = fidelity.strict_json(actual_line.decode("ascii"))
            expected = corrected_intro(old, native_intro)
            corrected_records += expected != old
            if index == 0:
                expected = {**expected, "ticks": settings["ticks"],
                            "route_fnv1a64": fidelity.fnv1a64((CPP / "route.txt").read_bytes())}
            diff = fidelity.first_difference(expected, actual)
            if diff and first is None:
                first = {"region": "cpp_prefix_outside_native_reset", "record": index, **diff}
            prefix_records += 1
    fidelity.require(digest.hexdigest() == proof["files"]["trace.jsonl"]["sha256"] ==
                     "51aa06c0df31d0070aef3d678ee90f76cc49ac62fabe1a1d50385b256e25d41c" and corrected_records > 0,
                     "archived trace changed or correction was not exercised")
    prefix_frames, identical_frames = 0, 0
    for name, item in proof["files"].items():
        if name.startswith("frame_") and name.endswith(".ppm"):
            fidelity.require(name in manifest["frames"], "missing prefix image")
            prefix_frames += 1
            identical_frames += manifest["frames"][name] == item["sha256"]
            if manifest["frames"][name] != item["sha256"] and first is None:
                first = {"region": "cpp_prefix", "frame": name, "path": "$.ppm_sha256"}
        elif name == "result_reels.jsonl" or name.startswith("result_frame_") and name.endswith(".ppm"):
            fidelity.require(fidelity.sha256(fidelity.safe_file(CPP, name)) == item["sha256"], "previous result bytes changed")
    fidelity.require(prefix_frames == observer.PREFIX_TICKS + 1, "incomplete archived frame inventory")

    expected_boundaries = {}
    def add(tick, phase, region, state, rgb=None):
        fidelity.require((tick, phase) not in expected_boundaries, "overlapping native boundaries")
        expected_boundaries[tick, phase] = (region, state, rgb)

    def add_sample(tick, region, row, atlas, palette=True):
        for field, phase, pi in (("rendered", "present", 1), ("post", "post_update", 2)):
            state = handoff.native_boundary(row[field], row["dac"][pi], atlas) if palette else original.project_original(row[field], 1, atlas)
            rgb = (row.get("rgb") or (row["rgb_delta_zlib_hex"], row["rgb_sha256"])) if phase == "present" else None
            add(tick, phase, region, state, rgb)

    level1_atlas, level1_frames = None, 0
    for row in original.reference_rows(NATIVE):
        if row["kind"] == "header":
            level1_atlas = row["atlas"]
        elif row["kind"] == "sample":
            add_sample(row["cpp_tick"], "level1_gameplay", row, level1_atlas, False)
            level1_frames += 1
    fidelity.require(level1_frames == 305, "original Level 1 prefix count changed")
    for phase in ("present", "post_update"):
        add(660, phase, "level1_ack", handoff.native_boundary(entry_header["baseline"], entry_header["baseline_dac"], level1_atlas),
            level1_reels[-1]["rgb"] if phase == "present" else None)
        add(730, phase, "level2_intro", handoff.native_boundary(entry_header["intro"], entry_header["intro_dac"], entry_header["atlas"]),
            fidelity.read_ppm(NATIVE / "level2-intro-wait.ppm") if phase == "present" else None)
        add(observer.PREFIX_TICKS, phase, "level2_ack", handoff.native_boundary(next_header["baseline"], next_header["baseline_dac"], gameplay_rows[0]["atlas"]),
            image_rgb(NATIVE / "original_level2_results_before_ack.png") if phase == "present" else None)
        add(observer.FIRST_TICK - 1, phase, "level3_intro", handoff.native_boundary(next_header["intro"], next_header["intro_dac"], next_header["atlas"]),
            image_rgb(NATIVE / "original_level3_intro.png") if phase == "present" else None)
    for index, row in enumerate(entry_samples):
        add_sample(handoff.FIRST_TICK + index, "level2_entry", row, entry_header["atlas"])
    for row in gameplay:
        add_sample(row["cpp_tick"], "level2_gameplay", row, gameplay_rows[0]["atlas"])
    for row in next_samples:
        add_sample(row["cpp_tick"], "level3_entry", row, next_header["atlas"])
    fidelity.require(hashlib.sha256(image_rgb(NATIVE / "original_level2_results_before_ack.png")).hexdigest() == next_header["ack_rgb_sha256"] and
                     hashlib.sha256(image_rgb(NATIVE / "original_level3_intro.png")).hexdigest() == next_header["intro_rgb_sha256"], "native boundary image changed")

    OUT.mkdir()
    regions = sorted({item[0] for item in expected_boundaries.values()} | {"level1_results", "level2_results"})
    boundaries, pixels_changed, frames = ({region: 0 for region in regions} for _ in range(3))
    previous, seen, footer = {}, set(), None
    def compare_frame(region, tick, rgb, path, suffix=None):
        nonlocal first
        pixels = fidelity.read_ppm(path)
        count = sum(rgb[i:i+3] != pixels[i:i+3] for i in range(0, 192000, 3))
        frames[region] += 1
        pixels_changed[region] += count
        if count and first is None:
            first = {"region": region, "tick": tick, "path": "$.rgb", "differing_pixels": count}
        if suffix is not None:
            from PIL import Image
            for label, data in (("original", rgb), ("cpp", pixels)):
                Image.frombytes("RGB", (320, 200), data).save(OUT / f"{label}_{suffix}.png")

    for row in fidelity.trace_rows(CPP, manifest):
        footer = row
        if row["kind"] != "checkpoint" or (row["tick"], row["phase"]) not in expected_boundaries:
            continue
        key = row["tick"], row["phase"]
        fidelity.require(key not in seen, "duplicate mapped boundary")
        seen.add(key)
        region, expected, rgb = expected_boundaries[key]
        actual = handoff.boundary(row["state"], bytes.fromhex(row["state"]["palette_rgb_hex"])) if "palette" in expected else original.project_cpp(row["state"], 1)
        diff = fidelity.first_difference(expected, actual)
        boundaries[region] += 1
        if diff and first is None:
            first = {"region": region, "tick": key[0], "phase": key[1], **diff}
        if rgb is not None:
            if isinstance(rgb, tuple):
                rgb = original.decode_frame(rgb[0], previous.get(region, bytes(192000)), rgb[1])
                previous[region] = rgb
            suffix = region if region.endswith("intro") or region.endswith("ack") else None
            if region == "level3_entry" and key[0] in (observer.FIRST_TICK, observer.FIRST_TICK + observer.FRAMES - 1):
                suffix = f"level3_{key[0] - observer.FIRST_TICK:02d}"
            compare_frame(region, key[0], rgb, CPP / row["frame"], suffix)
    fidelity.require(seen == set(expected_boundaries) and footer["kind"] == "complete" and footer["ticks"] == 3788,
                     "incomplete native comparison or full replay footer")

    candidates = [fidelity.strict_json(line) for line in (CPP / "result_reels.jsonl").read_text().splitlines()]
    fidelity.require(candidates[0] == {"kind": "header", "schema": "lezac.level1.result-reels.v1",
                     "boundary": "prepared-score-then-after-delayed-rng", "original_fidelity_claim": False} and
                     candidates[-1] == {"kind": "complete", "samples": 76, "original_fidelity_claim": False} and len(candidates) == 78,
                     "incomplete whole result stream")
    samples = candidates[1:-1]
    fidelity.require({p.name for p in CPP.glob("result_frame_*.ppm")} == {row["frame"] for row in samples}, "result image inventory differs")
    for index, row in enumerate(samples):
        fidelity.require(set(row) == {"kind", "sample", "player", "frame", "state"} and row["kind"] == "sample" and
                         type(row["sample"]) is int and row["sample"] == index and row["player"] == 1 and
                         row["frame"] == f"result_frame_{index:06d}.ppm" and row["state"]["level"] == (1 if index < 42 else 2),
                         "result alignment changed")
        fidelity.validate_state(row["state"])
    for region, native_samples, actual_samples, atlas in (
        ("level1_results", level1_reels, samples[:42], level1_reel_header["atlas"]),
        ("level2_results", native_reels, samples[42:], gameplay_rows[0]["atlas"])):
        old_rgb = bytes(192000)
        for index, (expected, actual) in enumerate(zip(native_samples, actual_samples)):
            rgb = expected.get("rgb") or original.decode_frame(expected["rgb_delta_zlib_hex"], old_rgb, expected["rgb_sha256"])
            old_rgb = rgb
            projected = handoff.native_boundary(expected["state"], expected["dac"], atlas) if region == "level2_results" else original.project_original(expected["state"], 1, atlas)
            current = handoff.boundary(actual["state"], bytes.fromhex(actual["state"]["palette_rgb_hex"])) if region == "level2_results" else original.project_cpp(actual["state"], 1)
            diff = fidelity.first_difference(projected, current)
            boundaries[region] += 1
            if diff and first is None:
                first = {"region": region, "sample": index, **diff}
            compare_frame(region, index, rgb, CPP / actual["frame"])

    report = {"schema": "lezac-private-level-setup-handoff-comparison-v1",
              "status": "match" if first is None and sum(pixels_changed.values()) == 0 else "diverged",
              "first_difference": first, "boundaries": boundaries, "frames": frames, "differing_pixels": pixels_changed,
              "cpp_prefix_records_compared": prefix_records, "cpp_prefix_corrected_intro_records": corrected_records,
              "cpp_prefix_frames_compared": prefix_frames, "cpp_prefix_frames_byte_identical": identical_frames,
              "prefix_policy_guard_cases": guard_cases, "native_handoff_sha256": native_manifest["handoff_sha256"],
              "native_gameplay_sha256": fidelity.sha256(NATIVE / "gameplay.jsonl.gz"),
              "native_results_sha256": fidelity.sha256(NATIVE / "results.jsonl.gz"),
              "cpp_trace_sha256": manifest["trace_sha256"], "cpp_executable_sha256": EXE_SHA,
              "cpp_result_stream_sha256": fidelity.sha256(CPP / "result_reels.jsonl"),
              "prefix_archive_sha256": proof["archive_sha256"], "source_sha256": plan["source_sha256"],
              "comparator_sha256": fidelity.sha256(Path(__file__)), **observer.CLAIMS}
    (OUT / "comparison.json").write_bytes(original.json_bytes(report))
    shutil.copyfile(Path(__file__), OUT / "comparison-producer.py")
    print(original.json_bytes(report).decode("ascii"), flush=True)
    fidelity.require(report["status"] == "match", "full replay or native handoff comparison diverged")


if __name__ == "__main__":
    main()
