import hashlib
import json
import os
from pathlib import Path
import sys
import time
from PIL import ImageGrab

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'tools'))
import capture_original_startup_rng as startup
from check_main_menu_fixture import HEADER, load_fixture

output = Path(sys.argv[1])
output.mkdir(exist_ok=False)
_, expected = load_fixture()
session = startup.Session(output)
result = dict(status='capturing', audio='dummy', clock_forced=False, gameplay_seeded=False, delay_gates=False,
              observer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), events=[])
try:
    result.update(session.launch(clock_only=True))
    geometry = dict(line.split('=', 1) for line in session.xdo('getwindowgeometry', '--shell', session.window).splitlines())
    x, y, w, h = (int(geometry[k]) for k in ('X', 'Y', 'WIDTH', 'HEIGHT'))
    startup.require((w, h) == (320, 200), 'original geometry changed')
    def frame():
        return ImageGrab.grab(xdisplay=os.environ['DISPLAY']).crop((x,y,x+w,y+h)).convert('RGB')
    def wait(labels):
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            image = frame()
            for label in labels:
                if image.tobytes() == expected[label][len(HEADER):]:
                    return label, image
            time.sleep(.005)
        raise RuntimeError('original phase timeout')
    name, image = wait(['italian-line0-step02', 'italian-line0-step06'])
    image.save(output / 'before-shift.png')
    pressed = time.monotonic()
    for modifier in ('Shift_L','Shift_R','Control_L','Control_R','Alt_L','Alt_R','Caps_Lock','Num_Lock','Scroll_Lock'):
        session.key(modifier)
        result['events'].append(dict(key=modifier, phase=name))
        time.sleep(.12)
        image = frame()
        image.save(output / ('after-'+modifier+'.png'))
        startup.require(image.tobytes() != expected['italian-full'][len(HEADER):], modifier+' skipped original typing')
    _, image = wait(['italian-full'])
    image.save(output / 'full.png')
    result.update(status='observed', modifier_consumed_as_character=False,
                  seconds_after_shift_to_full=time.monotonic()-pressed, rng=session.sample('italian-full'))
except Exception as error:
    result.update(status='failed', error=str(error))
    raise
finally:
    session.close()
    result.update(hooks_restored=len(session.restored), child_exit_code=session.child.returncode if session.child else None)
    (output / 'result.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result), flush=True)
