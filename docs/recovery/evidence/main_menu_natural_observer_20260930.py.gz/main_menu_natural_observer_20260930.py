import hashlib
import json
import os
from pathlib import Path
import sys
import time
from PIL import Image, ImageGrab

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'tools'))
import capture_original_startup_rng as startup
from check_main_menu_fixture import HEADER, load_fixture

output = Path(sys.argv[1])
output.mkdir(exist_ok=False)
_, frames = load_fixture()
session = startup.Session(output)
result = dict(status='capturing', audio='dummy', delay_gates=False, clock_forced=False,
              gameplay_seeded=False, whole_game_parity=False, samples=[], rng_samples=[],
              observer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              original_exe_sha256=startup.oracle.EXE_SHA256)
try:
    result.update(session.launch(clock_only=True))
    geometry = dict(line.split('=', 1) for line in session.xdo('getwindowgeometry', '--shell', session.window).splitlines())
    x, y, w, h = (int(geometry[k]) for k in ('X', 'Y', 'WIDTH', 'HEIGHT'))
    startup.require((w, h) == (320, 200), 'natural frame geometry')
    for language, last in (('italian', 30), ('english', 33)):
        labels = [language + '-line0-step02', language + '-line0-step06',
                  language + f'-line0-step{last:02d}', language + '-full']
        expected = {hashlib.sha256(frames[name][len(HEADER):]).digest(): name for name in labels}
        observations = {}
        started = time.monotonic()
        deadline = started + 40
        previous = started
        while time.monotonic() < deadline:
            startup.require(session.child.poll() is None, 'owned DOSBox exited')
            before = time.monotonic()
            frame = ImageGrab.grab(xdisplay=os.environ['DISPLAY']).crop((x, y, x + w, y + h)).convert('RGB')
            now = time.monotonic()
            name = expected.get(hashlib.sha256(frame.tobytes()).digest())
            if name:
                if name not in observations:
                    observations[name] = dict(name=name, first=before - started,
                                              previous=previous - started, last=now - started,
                                              sha256=hashlib.sha256(frame.tobytes()).hexdigest())
                    frame.save(output / (name + '.png'))
                    frame.resize((960, 600), Image.Resampling.NEAREST).save(output / (name + '-preview.png'))
                observations[name]['last'] = now - started
                if name.endswith('-full'):
                    break
            previous = now
            time.sleep(.005)
        startup.require(set(observations) == set(labels), 'missing natural menu phase: ' + str(observations))
        word = int.from_bytes(session.read(session.base + (session.data_segment << 4) + 0x78ce, 2), 'little')
        result['samples'].append(dict(language=language, delay_word=word, observations=list(observations.values())))
        result['rng_samples'].append(session.sample(language + '-full'))
        if language == 'italian':
            time.sleep(.2)
            session.key('l')
    result['status'] = 'observed'
except Exception as error:
    result.update(status='failed', error=str(error))
    raise
finally:
    session.close()
    result.update(hooks_restored=len(session.restored), child_exit_code=session.child.returncode if session.child else None)
    (output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
