import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from PIL import Image, ImageGrab

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'tools'))
import capture_original_startup_rng as startup
from check_main_menu_fixture import HEADER, load_fixture

parser = argparse.ArgumentParser()
parser.add_argument('--version', choices=('original', 'cpp'), required=True)
parser.add_argument('--exe', type=Path)
parser.add_argument('--choice', choices=('1', '2'), default='1')
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
output = args.out.resolve()
startup.require(not output.exists() and os.environ.get('DISPLAY') and os.environ.get('SDL_AUDIODRIVER') == 'dummy',
                'fresh output/private display/dummy audio required')
output.mkdir(parents=True)
_, expected = load_fixture()
session = startup.Session(output) if args.version == 'original' else None
child = None
env = dict(os.environ, SDL_AUDIODRIVER='dummy', SDL_VIDEODRIVER='x11', SDL_RENDER_DRIVER='software')
result = dict(status='capturing', version=args.version, audio='dummy', gameplay_seeded=False, delay_gates=False,
              physical_keys=True, manual_input=False, player_choice=int(args.choice), captures=[], events=[],
              observer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
try:
    if session:
        result.update(session.launch(clock_only=True))
        child, window = session.child, session.window
    else:
        startup.require(args.exe is not None, 'C++ executable required')
        result['exe_sha256'] = hashlib.sha256(args.exe.read_bytes()).hexdigest()
        log = (output / 'process.log').open('w')
        child = subprocess.Popen([str(args.exe.resolve())], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 15
        window = None
        while not window and time.monotonic() < deadline:
            try:
                window = subprocess.check_output(['xdotool', 'search', '--pid', str(child.pid), '--name', 'Larax'],
                                                 text=True, env=env, stderr=subprocess.DEVNULL).split()[-1]
            except (subprocess.CalledProcessError, IndexError):
                time.sleep(.01)
        startup.require(window is not None, 'owned window not found')
    def xdo(*command):
        return subprocess.check_output(['xdotool', *command], text=True, env=env, timeout=5).strip()
    xdo('windowfocus', '--sync', window)
    result['x_repeat'] = subprocess.check_output(['xset', 'q'], env=env, text=True, timeout=5)
    geometry = dict(line.split('=', 1) for line in xdo('getwindowgeometry', '--shell', window).splitlines())
    x, y, w, h = (int(geometry[k]) for k in ('X', 'Y', 'WIDTH', 'HEIGHT'))
    startup.require((w,h) == ((320,200) if session else (960,600)), 'owned frame geometry')
    def frame():
        return ImageGrab.grab(xdisplay=env['DISPLAY']).crop((x,y,x+w,y+h)).convert('RGB').resize((320,200), Image.Resampling.NEAREST)
    def capture(name, elapsed):
        image = frame()
        image.save(output / (name+'.png'))
        image.resize((960,600), Image.Resampling.NEAREST).save(output / (name+'-preview.png'))
        result['captures'].append(dict(name=name, seconds=elapsed,
            full_menu=image.tobytes() == expected['italian-full'][len(HEADER):],
            pixel_sha256=hashlib.sha256(image.tobytes()).hexdigest()))
    deadline = time.monotonic()+25
    while time.monotonic() < deadline:
        startup.require(child.poll() is None, 'owned child exited early')
        image = frame()
        if image.tobytes() in (expected['italian-line0-step02'][len(HEADER):], expected['italian-line0-step06'][len(HEADER):]):
            break
        time.sleep(.005)
    else:
        raise RuntimeError('natural typing phase not reached')
    if session:
        result['before_rng'] = session.sample('before-held-choice')
    capture('before-hold', 0)
    pressed = time.monotonic()
    xdo('keydown', args.choice)
    result['events'].append(dict(kind='keydown', key=args.choice, seconds=0))
    for elapsed in (.15, 1.0, 2.0, 3.0):
        time.sleep(max(0, pressed+elapsed-time.monotonic()))
        capture('hold-'+str(elapsed), time.monotonic()-pressed)
    xdo('keyup', args.choice)
    result['events'].append(dict(kind='keyup', key=args.choice, seconds=time.monotonic()-pressed))
    time.sleep(.15)
    capture('released', time.monotonic()-pressed)
    xdo('key', args.choice)
    result['events'].append(dict(kind='press', key=args.choice, seconds=time.monotonic()-pressed))
    time.sleep(.25)
    capture('fresh-press', time.monotonic()-pressed)
    result['status'] = 'observed'
except Exception as error:
    result.update(status='failed', error=str(error))
    raise
finally:
    if child is not None:
        try:
            subprocess.run(['xdotool','keyup',args.choice], env=env, check=False, timeout=5)
        finally:
            if session:
                session.close()
                result['hooks_restored'] = len(session.restored)
            elif child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait(timeout=5)
            result['child_exit_code'] = child.returncode
    (output/'result.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k != 'x_repeat'}), flush=True)
