import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/mnt/c/Users/andrz/git/LEZAC')
OUT = Path('/dev/shm/lezac-monster-tile-damage-20261004')
files = {}
for suffix in ('a', 'b'):
    for path in sorted((OUT / 'expanded' / suffix).iterdir()):
        assert path.is_file() and not path.is_symlink()
        files[f'{suffix}/{path.name}'] = path.read_bytes()
    files[f'capture-{suffix}-stdout.log'] = (OUT / 'expanded' / f'capture-{suffix}-stdout.log').read_bytes()
for name in ('capture_original_monster_tile_damage.py', 'capture_original_monster_writeback.py',
             'capture_original_flyer_contacts.py', 'check_monster_writeback_fixture.py',
             'check_monster_tile_damage_fixture.py'):
    files[f'tools/{name}'] = (ROOT / 'tools' / name).read_bytes()
for name in ('successful-extractor.py', 'initial-extractor.py'):
    files[f'extraction/{name}'] = (OUT / 'expanded/sources' / name).read_bytes()
for name in ('stage-expanded.py', 'replay.py', 'archive-native.py', 'negative.json', 'positive.json'):
    files[name] = (OUT / name).read_bytes()
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in files.items()}
files['manifest.json'] = (json.dumps(manifest, sort_keys=True) + '\n').encode()
archive = OUT / 'native-captures.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=9) as handle:
    for name, data in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.size = len(data)
        member.mode = 0o644
        handle.addfile(member, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as handle:
    assert len(handle.getmembers()) == len(files)
    assert {m.name: handle.extractfile(m).read() for m in handle.getmembers()} == files
receipt = {'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'members': len(files), 'raw_bytes': sum(map(len, files.values())), 'all_members_byte_verified': True}
(OUT / 'archive-native.json').write_text(json.dumps(receipt, sort_keys=True) + '\n')
print(json.dumps(receipt, sort_keys=True))
