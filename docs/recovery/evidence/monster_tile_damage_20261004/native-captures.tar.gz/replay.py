import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/mnt/c/Users/andrz/git/LEZAC')
OUT = Path('/dev/shm/lezac-monster-tile-damage-20261004')
mode = sys.argv[1]
assert mode in ('negative', 'positive', 'final')
sys.path.insert(0, str(ROOT / 'tools'))
import check_monster_tile_damage_fixture as check
exe = OUT / 'build/lezac_cpp'
fixture = ROOT / 'tests/fixtures/monster_tile_damage_original.bin'
data = fixture.read_bytes()
check.validate(data, (ROOT / 'LEZAC.EXE').read_bytes())
git = ['git', '-c', 'core.autocrlf=true', '-C', str(ROOT)]
head = subprocess.check_output([*git, 'rev-parse', 'HEAD'], text=True).strip()
assert subprocess.run([*git, 'diff', '--quiet', 'HEAD', '--', 'src/app/app.cpp']).returncode == 0
env = dict(os.environ, SDL_AUDIODRIVER='dummy', SDL_VIDEODRIVER='dummy', TMPDIR='/dev/shm', PYTHONDONTWRITEBYTECODE='1')
command = [str(exe), '--debug-monster-tile-damage', str(fixture)]
result = subprocess.run(command, env=env, cwd=ROOT, capture_output=True, text=True, timeout=30)
mismatches = []
if mode == 'negative':
    expected = [i for i in check.damage_cases(data) if data[64 + i * 80 + 2] >= 5]
    assert len(expected) == 276 and result.returncode == 1
    assert result.stderr.strip() == 'fatal: monster production tile damage differs at cases ' + ','.join(map(str, expected)), result.stderr
    mismatches = expected
    shutil.copyfile(exe, OUT / 'negative-lezac_cpp')
else:
    assert result.returncode == 0 and 'cases=1312 production_updates=1312' in result.stdout, (result.stdout, result.stderr)
receipt = {'command': command, 'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
           'mismatches': mismatches, 'mismatch_count': len(mismatches), 'audio': 'dummy', 'video': 'dummy',
           'fixture_sha256': hashlib.sha256(data).hexdigest(), 'source_commit': head, 'app_source_dirty': False,
           'app_sha256': hashlib.sha256((ROOT / 'src/app/app.cpp').read_bytes()).hexdigest(),
           'executable_sha256': hashlib.sha256(exe.read_bytes()).hexdigest(), 'natural_route_claim': False}
(OUT / f'{mode}.json').write_text(json.dumps(receipt, sort_keys=True) + '\n')
print(f'tile_damage_{mode}=ok returncode={result.returncode} mismatches={len(mismatches)} source={head} binary={receipt["executable_sha256"]}', flush=True)
if mode != 'negative':
    print(result.stdout, end='', flush=True)
