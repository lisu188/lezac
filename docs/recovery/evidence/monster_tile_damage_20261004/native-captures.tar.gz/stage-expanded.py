import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/mnt/c/Users/andrz/git/LEZAC')
OUT = Path('/dev/shm/lezac-monster-tile-damage-20261004/expanded')
assert OUT.parent.resolve() == OUT.parent
usage = shutil.disk_usage(OUT.parent)
memory = {key: int(value.split()[0]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines()
          for key, value in [line.split(':', 1)] if key in ('MemTotal', 'MemAvailable')}
assert usage.free - 512 * 1024 * 1024 > usage.total // 10
assert memory['MemAvailable'] - 512 * 1024 * 1024 > memory['MemTotal'] // 10
sys.path.insert(0, str(ROOT / 'tools'))
import capture_original_monster_tile_damage as producer
OUT.mkdir()
snapshot = OUT / 'sources'
snapshot.mkdir()
for name in ('capture_original_monster_tile_damage.py', 'capture_original_monster_writeback.py',
             'capture_original_flyer_contacts.py', 'check_monster_writeback_fixture.py'):
    shutil.copyfile(ROOT / 'tools' / name, snapshot / name)
env = dict(os.environ, SDL_AUDIODRIVER='dummy', PYTHONDONTWRITEBYTECODE='1', TMPDIR='/dev/shm')
for suffix in ('a', 'b'):
    run, output = OUT / f'run-{suffix}', OUT / suffix
    run.mkdir()
    for name in producer.flyers.base.ASSETS:
        shutil.copyfile(ROOT / name, run / name)
        assert hashlib.sha256((ROOT / name).read_bytes()).digest() == hashlib.sha256((run / name).read_bytes()).digest()
    command = [sys.executable, '-B', str(ROOT / 'tools/capture_original_monster_tile_damage.py'),
               '--run-dir', str(run), '--out-dir', str(output),
               '--approve-procmem', '--approve-runtime-instrumentation']
    with (OUT / f'capture-{suffix}-stdout.log').open('wb') as log:
        result = subprocess.run(command, env=env, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=600)
    assert result.returncode == 0, (suffix, result.returncode)
    report = json.loads((output / 'capture.json').read_text())
    assert report['case_count'] == 1312 and report['complete'] and report['owned_child_returncode'] is not None
    print(f'expanded_original_tile_damage_run={suffix} cases=1312 closed=1 audio=dummy', flush=True)
