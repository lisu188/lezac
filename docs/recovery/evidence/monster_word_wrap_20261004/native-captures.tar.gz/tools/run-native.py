import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/mnt/c/Users/andrz/git/LEZAC')
OUT = Path('/dev/shm/lezac-monster-word-wrap-20261004')
sys.path.insert(0, str(ROOT / 'tools'))
import capture_original_behavior4_targets as support

memory = {key: int(value.split()[0]) * 1024
          for line in Path('/proc/meminfo').read_text().splitlines()
          for key, value in [line.split(':', 1)]}
usage = shutil.disk_usage(OUT)
assert usage.free - 128 * 1024 * 1024 > usage.total // 10
assert memory['MemAvailable'] - 512 * 1024 * 1024 > memory['MemTotal'] // 10
env = dict(os.environ, TMPDIR='/dev/shm', SDL_AUDIODRIVER='dummy', PYTHONDONTWRITEBYTECODE='1')
for suffix in ('a', 'b'):
    run = OUT / f'original-{suffix}'
    run.mkdir()
    for name in support.ASSETS:
        source, target = ROOT / name, run / name
        shutil.copyfile(source, target)
        assert hashlib.sha256(source.read_bytes()).digest() == hashlib.sha256(target.read_bytes()).digest()
    command = [sys.executable, '-B', str(ROOT / 'tools/capture_original_monster_word_wrap.py'),
               '--run-dir', str(run), '--out-dir', str(OUT / f'native-{suffix}'),
               '--approve-procmem', '--approve-runtime-instrumentation']
    with (OUT / f'native-{suffix}.log').open('wb') as log:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=600)
    print(json.dumps({'capture': suffix, 'returncode': result.returncode}), flush=True)
    assert result.returncode == 0
    report = json.loads((OUT / f'native-{suffix}/capture.json').read_text())
    assert report['complete'] and report['case_count'] == 768 and report['owned_child_returncode'] is not None
print('monster_word_wrap_native_pair=ok captures=2 cases_each=768 audio=dummy', flush=True)
