"""Observe the new ammo route and retain every new raw DOS boundary."""
import gzip
import hashlib
import importlib.util
import os
from pathlib import Path
import shutil
import struct
from common import *

protected()
protocol.owner()
producer('common.py')
producer('capture.py')
save('native-capacity.json',reserve(2*1024**3))
assert not OUT.exists() and fidelity.sha256(PARENT) == PARENT_SHA and fidelity.sha256(NATIVE) == NATIVE_SHA
route_bytes()
os.environ['SDL_AUDIODRIVER'] = 'dummy'
spec = importlib.util.spec_from_file_location('ammo_native_parent',PARENT)
parent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parent)
assert parent.FRAMES == 662
parent.WORK,parent.OUT,parent.ROUTE,parent.FRAMES = WORK,OUT,ROUTE,FRAMES
parent.route_bytes = route_bytes
inherited_loader = parent.load_observer


def configured_loader():
    observer = inherited_loader()
    factory = observer.session_class

    def session_class(base):
        inherited_session = factory(base)

        class AmmoSession(inherited_session):
            def __init__(self,*args):
                self.raw_records,self.raw_stream = [],None
                super().__init__(*args)
                self.raw_stream = gzip.GzipFile(filename=str(self.output / 'new-suffix-ds.bin.gz'),mode='wb',mtime=0)
                shutil.copyfile(Path(__file__),self.output / 'capture.py')
                (self.output / 'ammo-runtime-configuration.json').write_bytes(original.json_bytes(dict(
                    source_sha256=fidelity.sha256(Path(__file__)),parent_sha256=PARENT_SHA,
                    runtime_frames=FRAMES,route_ticks=TICKS,route_sha256=fidelity.sha256(ROUTE),
                    unchanged_native_prefix_tick=FORK,prior_native_stream_sha256=NATIVE_SHA,
                    raw_suffix_boundaries=(TICKS-FORK)*3,audio='dummy',private_display='xvfb-run -a',
                    new_gameplay_state_injections=False,whole_game_complete=False)))

            def next_state(self):
                state,dimensions = super().next_state()
                tick = state['frame']-2670+3777
                if tick > FORK:
                    scratch = struct.unpack('<8HI',self.read(self.resident+original.SCRATCH,20))
                    stage,sequence = scratch[0],scratch[8]
                    assert stage in (2,3,4) and sequence == self.sequence
                    assert len(self.raw_records) == (tick-FORK-1)*3+stage-2
                    data = self.read(self.ds,65536)
                    assert len(data) == 65536 and original.word(data,0x78c2) == state['frame']
                    self.raw_stream.write(data)
                    self.raw_records.append(dict(index=len(self.raw_records),cpp_tick=tick,
                        native_frame=state['frame'],stage=stage,sequence=sequence,sha256=hashlib.sha256(data).hexdigest()))
                return state,dimensions

            def close(self):
                try:
                    super().close()
                finally:
                    if self.raw_stream is not None:
                        self.raw_stream.close()
                    if self.output.is_dir():
                        (self.output / 'new-suffix-ds-journal.json').write_bytes(original.json_bytes(dict(
                            complete=len(self.raw_records) == (TICKS-FORK)*3,records=self.raw_records,
                            snapshot_bytes=65536,first_cpp_tick=FORK+1,expected_frames=TICKS-FORK,
                            raw_bytes=(TICKS-FORK)*3*65536,input_boundary='pre precedes declared input-bank writes',
                            new_gameplay_state_injections=False,manual_input_claim=False)))
        return AmmoSession
    observer.session_class = session_class
    return observer


parent.load_observer = configured_loader


def validate():
    outcome = fidelity.strict_json((OUT / 'outcome-manifest.json').read_text())
    assert outcome['status'] == 'captured' and outcome['patches_restored']
    assert outcome['gameplay_frames'] == 2352 and outcome['result_samples'] == 34
    assert outcome['gate_cpp_tick'] == 3094 and outcome['gate_native_frame'] == 2669
    assert not (OUT / 'failure.json').exists() and not (OUT / 'objective-observer-failure.json').exists()
    for name,digest in outcome['files'].items():
        assert fidelity.sha256(fidelity.safe_file(OUT,name)) == digest
    assert outcome['assets'] == {name:fidelity.sha256(ROOT / name) for name in fidelity.ASSETS}
    assert original.fingerprint(OUT) == handoff.PREFIX_SHA256
    assert (OUT / 'level3-route.txt').read_bytes() == route_bytes()
    rows = handoff.load(OUT / 'level3-handoff.jsonl.gz')
    samples = parent.load_observer().validate_rows(rows)
    assert len(samples) == FRAMES and rows[0]['dimensions'] == [150,60]
    journal = fidelity.strict_json((OUT / 'objective-input-journal.json').read_text())
    assert journal['complete'] and len(journal['samples']) == FRAMES
    events = parent.extension_events()
    for index,entry in enumerate(journal['samples']):
        assert entry['sample'] == index and entry['cpp_tick'] == 3777+index and entry['events'] == events.get(index,[])
        before,after = bytes.fromhex(entry['before_bank_hex']),bytes.fromhex(entry['after_bank_hex'])
        assert len(before) == len(after) == 10
        wanted = bytearray(before)
        for event in entry['events']:
            wanted[original.BANK[event['key']]-0x1b78] = event['action'] != 'up'
        assert bytes(wanted) == after
    previous = handoff.load(NATIVE)
    unchanged = [row for row in previous[1:-1] if row['cpp_tick'] <= FORK]
    assert len(unchanged) == PREFIX_FRAMES
    for index,old in enumerate(unchanged):
        new = samples[index]
        for pi,phase in enumerate(('pre','rendered','post')):
            assert handoff.native_boundary(old[phase],old['dac'][pi],previous[0]['atlas']) == handoff.native_boundary(new[phase],new['dac'][pi],rows[0]['atlas'])
        assert old['rgb_sha256'] == new['rgb_sha256']
    raw = fidelity.strict_json((OUT / 'new-suffix-ds-journal.json').read_text())
    assert raw['complete'] and len(raw['records']) == (TICKS-FORK)*3
    with gzip.open(OUT / 'new-suffix-ds.bin.gz','rb') as stream:
        for index,entry in enumerate(raw['records']):
            data = stream.read(65536)
            tick,phase = FORK+1+index//3,('pre','rendered','post')[index%3]
            state = samples[tick-3777][phase]
            assert entry['index'] == index and entry['cpp_tick'] == tick and entry['stage'] == 2+index%3
            assert entry['sequence'] == samples[tick-3777]['sequences'][index%3]
            assert len(data) == 65536 and hashlib.sha256(data).hexdigest() == entry['sha256']
            assert original.word(data,0xC204) == 150 and original.word(data,0x2096)//8+21 == 60
            assert data[0x79B7] == 3 and original.word(data,0x78C2) == state['frame']
            assert struct.unpack_from('<I',data,0x1AFE)[0] == state['rng'] and data[0x208D] == state['actor_count']
            for key,offset,length in (('actors',0x1BD4,state['actor_count']*38),('visuals',0xC21E,data[0xC496]*8),
                ('inventory',0x1B6C,12),('scores',0x785A,92),('destruction',0x78C6,4),('progress',0x2076,36),('spawners',0x74C6,data[0x79A6]*30)):
                assert data[offset:offset+length].hex() == state[key],(tick,phase,key)
            for pi,player in enumerate(state['players'],1):
                offset = 0x1B62+pi*38
                assert data[offset:offset+38].hex() == player['raw']
                visual = 0xC21E+data[offset+1]*8
                assert data[visual:visual+8].hex() == player['visual']
        assert stream.read(1) == b''
    final_raw = data
    assert original.word(final_raw,0x2080) == 0
    assert final_raw[0x79C5] and final_raw[0x79C6]
    assert original.word(final_raw,0x78C8) >= 148
    report = dict(status='original_double_medium_gate_prefix_and_raw_suffix_verified',frames=FRAMES,ticks=TICKS,
        unchanged_native_prefix_frames=PREFIX_FRAMES,unchanged_native_prefix_boundaries=PREFIX_FRAMES*3,
        new_suffix_frames=TICKS-FORK,native_stream_sha256=fidelity.sha256(OUT / 'level3-handoff.jsonl.gz'),
        route_sha256=fidelity.sha256(ROUTE),source_sha256=fidelity.sha256(Path(__file__)),parent_sha256=PARENT_SHA,
        prior_native_stream_sha256=NATIVE_SHA,raw_suffix_boundaries=(TICKS-FORK)*3,
        raw_suffix_sha256=fidelity.sha256(OUT / 'new-suffix-ds.bin.gz'),
        raw_suffix_journal_sha256=fidelity.sha256(OUT / 'new-suffix-ds-journal.json'),patches_restored=True,
        final_mapped=campaign.native_boundary(samples[-1]['post'],samples[-1]['dac'][2],rows[0]['atlas']),
        original_gate_eligible=True,gate_sample_before_blocking_results=True,
        audio='dummy',new_gameplay_state_injections=False,cpp_compared=False,
        raw_clock_sound_actor_byte_equivalence_claim=False,natural_level3_completion_claim=False,whole_game_complete=False)
    save('native-audit.json',report)
    protected()
    print(original.json_bytes({k:v for k,v in report.items() if k != 'final_mapped'}).decode(),flush=True)
    return report


parent.validate_capture = validate
parent.main()
