"""Pin the Medium/Large route and unchanged original observation protocol."""
import importlib.util
import os
from pathlib import Path
import shutil
import sys

ROOT = Path('/mnt/c/Users/andrz/git/LEZAC')
DURABLE = Path(__file__).parent
WORK = Path('/dev/shm/lezac-level3-double-medium-gate-original-20261006-t1')
OUT = Path('/dev/shm/lezac-double-medium-gate-original-20261006-t1')
CPP_WORK = Path('/dev/shm/lezac-reward-pickup-phase-20261006-t1')
CPP_CONTROL = ROOT / 'build-codex-tmp/bonus-pickup-rng-work-20261006'
OLD_CONTROL = ROOT / 'build-codex-tmp/level3-medium-large-original-work-20261006'
SCOUT_CONTROL = ROOT / 'build-codex-tmp/level3-double-medium-settle-work-20261006'
sys.path.insert(0, str(ROOT / 'tools'))
import level1_fidelity as fidelity
import level1_original as original
import level1_handoff as handoff
import natural_campaign as campaign

SOURCE = ROOT / 'build-codex-tmp/level3-first-large-retime-work-20261006/probe-capture-version.py'
SOURCE_SHA = '626f4cb419ab7cb315bc7d56d7d80bf0fbfd93a62dbbc78967ef1aec3fc6e5a7'
assert fidelity.sha256(SOURCE) == SOURCE_SHA
spec = importlib.util.spec_from_file_location('medium_large_preserved_protocol', SOURCE)
reuse = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reuse)
protocol = reuse.protocol
protocol.DURABLE, protocol.WORK = DURABLE, WORK
protocol.SRC, protocol.EXE = CPP_WORK / 'src', CPP_WORK / 'build/lezac_cpp'
protocol.HEAD = protocol.BUILT_HEAD = 'e4a7f90872c3b9ea3d089b4aa652e9b16b33d6b8'
protocol.EXE_SHA = 'e1c95b811de11b1be1b0651448570a6f5736e3b6e39a5e34d2571aa14eee18d3'
protocol.MARKER = ['lezac-double-medium-gate-native-keepalive-20261006-t1', '86400']
save, reserve = protocol.save, protocol.reserve
FORK, TICKS, PREFIX_FRAMES, FRAMES = 8420, 8905, 4644, 5129
NATIVE = Path('/dev/shm/lezac-medium-large-original-20261006-t1/level3-handoff.jsonl.gz')
NATIVE_SHA = 'a1b38d1e8c1d60932c0fa05decb6453cf3c2fb599495e884bc93357d91efc632'
PARENT = Path('/dev/shm/lezac-level3-east-support-20261006-t1/objective-observer-wrapper.py')
PARENT_SHA = '67fbad0106d75c06652708f8ec9667d2b607665947b26d5811d05e6c1c5206f7'
ROUTE = WORK / 'double-medium-gate-v1.route'
PRIOR_ROUTE = Path('/dev/shm/lezac-level3-medium-large-original-20261006-t1/medium-large-overlap-v1.route')
ROUTE_SOURCE = SCOUT_CONTROL / 'double-medium-settle-v1.route'

def load(name):
    return fidelity.strict_json((DURABLE / name).read_text())

def protected():
    protocol.protected()
    relationship = fidelity.strict_json((CPP_CONTROL / 'source-binary-relationship.json').read_text())
    command = fidelity.strict_json((CPP_CONTROL / 'fixed-replay-command.json').read_text())
    assert relationship['head'] == protocol.HEAD and relationship['cpp_app_bytes_unchanged_since_build']
    assert relationship['executable_sha256'] == protocol.EXE_SHA
    assert fidelity.sha256(protocol.SRC / 'src/app/app.cpp') == command['source_files']['src/app/app.cpp']
    assert fidelity.sha256(NATIVE) == NATIVE_SHA
    assert fidelity.sha256(PARENT) == PARENT_SHA

def producer(name):
    assert fidelity.sha256(DURABLE / name) == load('preparation-proof.json')['producer_hashes'][name]

def route_bytes():
    command = fidelity.strict_json((SCOUT_CONTROL / 'command.json').read_text())
    assert fidelity.sha256(ROUTE_SOURCE) == command['route_sha256'] == 'a775cb2a5961c4477fc1c409aa8807dd72bf8aa1140cbfd7e9a19afacd7d706b'
    assert fidelity.sha256(PRIOR_ROUTE) == 'b769afc25fa1284d67fa0f67ed9619e57a67046606babb402111e0d164354134'
    settings, events = fidelity.read_route(ROUTE)
    baseline, prior = fidelity.read_route(PRIOR_ROUTE)
    source_settings, source_events = fidelity.read_route(ROUTE_SOURCE)
    assert source_settings['ticks'] == 9300
    assert events == {tick: rows for tick, rows in source_events.items() if tick <= TICKS}
    assert settings['ticks'] == TICKS and baseline['ticks'] == FORK
    assert all(settings[key] == baseline[key] for key in ('seed', 'step_us'))
    assert {tick: rows for tick, rows in events.items() if tick <= FORK} == prior
    assert all(row['key'] in ('x', 'z', 'm', 'n') and row['action'] in ('up', 'down')
        for tick, rows in events.items() if tick > FORK for row in rows)
    return ROUTE.read_bytes()

if __name__ == '__main__':
    protected()
    print('Protected source, binary, assets and native prefix remain pinned', flush=True)
