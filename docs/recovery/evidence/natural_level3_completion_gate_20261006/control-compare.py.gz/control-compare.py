"""Compare the corrected ordinary-input suffix without claiming full fidelity."""
from common import *
import copy
import gzip
import hashlib
import json
import struct
from PIL import Image
import natural_level3_return as returned

CPP = WORK / 'cpp-settle-readback'
PROJECTION = ROOT / 'build-codex-tmp/level3-ninth-roof-jump-work-20261006/roof-projections.py'
assert fidelity.sha256(PROJECTION) == '6ff16f237f9540d969d31c9052b56013bdaf5aeeca53686d0dd3cca8fcdc52c7'
sys.path.insert(0, str(OLD_CONTROL))
spec = importlib.util.spec_from_file_location('corrected_ammo_native_projection', PROJECTION)
projection = importlib.util.module_from_spec(spec)
spec.loader.exec_module(projection)

def native_markers(state):
    actors, visuals = bytes.fromhex(state['actors']), bytes.fromhex(state['visuals'])
    result = []
    for index in range(state['actor_count']):
        raw = actors[index*38:(index+1)*38]
        visual = visuals[raw[1]*8:raw[1]*8+8]
        if raw[0] == 11 and raw[20] == 10 and list(visual[4:6]) == [20,6]:
            result.append(dict(xy=list(struct.unpack_from('<hh', visual)),
                motion=list(struct.unpack_from('<hhHH', raw, 6)), kind=raw[0], timer=raw[2], hotspot=raw[20]))
    return result

def cpp_markers(state):
    return [dict(xy=row['state'][:2], motion=row['state'][2:6], kind=row['state'][6],
        timer=row['state'][7], hotspot=row['state'][8])
        for row in sorted(state['transients'], key=lambda item:item['order'])
        if row['state'][6] == 11 and row['state'][9] == 88]

def main():
    protected()
    protocol.owner()
    producer('compare.py')
    receipt = load('capture-terminal-receipt.json')
    assert receipt['terminal'] and receipt['exit_code'] == 0
    audit = load('native-audit.json')
    assert audit['status'] == 'original_double_medium_gate_prefix_and_raw_suffix_verified'
    assert audit['original_gate_eligible'] and audit['gate_sample_before_blocking_results']
    assert load('cpp-extraction-proof.json')['trace_sha256'] == fidelity.sha256(CPP / 'trace.jsonl')
    report = fidelity.strict_json((SCOUT_CONTROL / 'scout-proof.json').read_text())
    assert fidelity.sha256(CPP / 'trace.jsonl') == report['trace_sha256']
    assert fidelity.sha256(OUT / 'level3-handoff.jsonl.gz') == audit['native_stream_sha256']
    assert fidelity.sha256(OUT / 'new-suffix-ds.bin.gz') == audit['raw_suffix_sha256']
    wanted, screens, rgb, decoded = {}, {}, bytes(192000), 0
    with gzip.open(OUT / 'level3-handoff.jsonl.gz', 'rt') as stream:
        header = fidelity.strict_json(next(stream))
        for line in stream:
            row = fidelity.strict_json(line)
            if row['kind'] == 'complete':
                assert row['frames'] == FRAMES and decoded == FRAMES and not stream.read()
                break
            rgb = original.decode_frame(row['rgb_delta_zlib_hex'], rgb, row['rgb_sha256'])
            decoded += 1
            tick = row['cpp_tick']
            if tick in (8420,8578,8581,8692,8709,8905):
                screens[tick] = rgb
            if tick < FORK:
                continue
            for pi, field, phase in ((1,'rendered','present'),(2,'post','post_update')):
                state = row[field]
                wanted[tick,phase] = dict(mapped=campaign.native_boundary(state,row['dac'][pi],header['atlas']),
                    lifecycle=returned.native_lifecycle(state), monsters=projection.native_monsters(state),
                    markers=native_markers(state), rgb_sha256=row['rgb_sha256'] if pi == 1 else None)
    journal = fidelity.strict_json((OUT / 'new-suffix-ds-journal.json').read_text())
    assert journal['complete'] and len(journal['records']) == (TICKS-FORK)*3
    with gzip.open(OUT / 'new-suffix-ds.bin.gz','rb') as stream:
        for index,entry in enumerate(journal['records']):
            raw = stream.read(65536)
            assert len(raw) == 65536 and hashlib.sha256(raw).hexdigest() == entry['sha256']
            if index%3:
                key = FORK+1+index//3, ('pre','present','post_update')[index%3]
                wanted[key]['terrain'] = projection.native_terrain(raw)
        assert not stream.read(1)
    preview = DURABLE / 'paired-previews-v2'
    assert not preview.exists()
    preview.mkdir()
    seen, frames, markers, pairs, mutation_seed = set(),0,0,{},None
    with (CPP / 'trace.jsonl').open() as stream:
        cpp_header = fidelity.strict_json(next(stream))
        assert cpp_header['candidate_only'] and cpp_header['capture_from_tick'] == FORK and cpp_header['ticks'] == 9300
        for line in stream:
            row = fidelity.strict_json(line)
            if row['kind'] == 'complete':
                assert row['ticks'] == 9300 and not stream.read()
                break
            key = row['tick'],row['phase']
            if key not in wanted:
                continue
            assert key not in seen
            state, expected = row['state'],wanted[key]
            fidelity.validate_state(state)
            actual = dict(mapped=campaign.cpp_boundary(state,True), lifecycle=returned.cpp_lifecycle(state),
                monsters=projection.cpp_monsters(state), markers=cpp_markers(state))
            if 'terrain' in expected:
                actual['terrain'] = projection.cpp_terrain(state)
            for label,value in actual.items():
                difference = fidelity.first_difference(expected[label],value)
                assert difference is None, (key,label,difference)
            markers += len(expected['markers'])
            if key[1] == 'present':
                pixels = fidelity.read_ppm(CPP / row['frame'])
                assert fidelity.fnv1a64(pixels) == row['rgb_fnv1a64']
                assert hashlib.sha256(pixels).hexdigest() == expected['rgb_sha256'], (key,'RGB')
                frames += 1
                if key[0] in screens:
                    assert pixels == screens[key[0]]
                    for label in ('original','cpp'):
                        target = preview / f'{label}_{key[0]}.png'
                        Image.frombytes('RGB',(320,200),pixels).save(target)
                        assert Image.open(target).convert('RGB').tobytes() == pixels
                    pairs[str(key[0])] = dict(differing_pixels=0,rgb_sha256=expected['rgb_sha256'])
            if key == (TICKS,'post_update'):
                mutation_seed = state,expected
            seen.add(key)
    assert seen == set(wanted) and frames == TICKS-FORK+1 and len(seen) == frames*2
    assert mutation_seed is not None
    baseline, expected = mutation_seed
    rejected = 0
    for field,index in (('inventory',1),('inventory',2),('health',0)):
        changed = copy.deepcopy(baseline)
        changed['players'][0][field][index] += 1
        assert fidelity.first_difference(expected['mapped'],campaign.cpp_boundary(changed,True)) is not None
        rejected += 1
    for field in ('random_seed',):
        changed = copy.deepcopy(baseline)
        changed[field] ^= 1
        assert fidelity.first_difference(expected['mapped'],campaign.cpp_boundary(changed,True)) is not None
        rejected += 1
    changed = copy.deepcopy(baseline)
    changed['players'][0]['x'] += 1
    assert fidelity.first_difference(expected['mapped'],campaign.cpp_boundary(changed,True)) is not None
    rejected += 1
    changed = copy.deepcopy(baseline)
    changed['progress'][1] += 1
    assert fidelity.first_difference(expected['mapped'],campaign.cpp_boundary(changed,True)) is not None
    rejected += 1
    for field in ('tiles_hex','words_hex'):
        changed = copy.deepcopy(baseline)
        raw = bytearray.fromhex(changed[field])
        raw[0] ^= 1
        changed[field] = raw.hex()
        assert fidelity.first_difference(expected['mapped'],campaign.cpp_boundary(changed,True)) is not None
        rejected += 1
    result = dict(status='double_medium_suffix_through_original_completion_gate_matches',compared_frames=frames,
        compared_boundaries=len(seen),raw_ds_boundaries=(TICKS-FORK)*3,
        bounded_score_marker_observations=markers,rejected_projection_mutations=rejected,paired_previews=pairs,
        final_mapped=wanted[TICKS,'post_update']['mapped'],native_capture_sha256=audit['native_stream_sha256'],
        raw_ds_sha256=audit['raw_suffix_sha256'],cpp_trace_sha256=report['trace_sha256'],
        route_sha256=fidelity.sha256(ROUTE),cpp_longer_route_sha256=report['route_sha256'],reader_sha256=fidelity.sha256(Path(__file__)),
        projection_reader_sha256=fidelity.sha256(PROJECTION),audio='dummy',
        full_prefix_cpp_comparison_claim=False,all_actor_fields_compared=False,new_gameplay_state_injections=False,
        original_empty_collapse_gate_verified=True,original_results_and_level4_handoff_compared=False,
        natural_level3_completion_claim=False,whole_game_complete=False,original_fidelity_claim=False)
    save('comparison-proof.json',result)
    protected()
    print(json.dumps({key:result[key] for key in ('status','compared_frames','compared_boundaries','raw_ds_boundaries',
        'rejected_projection_mutations','final_mapped')}),flush=True)

if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        save('comparison-v2-failure.json',dict(error=str(error),reader_sha256=fidelity.sha256(Path(__file__)),
            whole_game_complete=False,original_capture_changed=False))
        raise
