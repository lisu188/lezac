"""Recover the already retained C++ scout for an independent native comparison."""
from common import *
import hashlib
import json
import tarfile
from pathlib import PurePosixPath

protected()
protocol.owner()
producer('extract-cpp.py')
assert load('capture-terminal-receipt.json')['terminal']
reserve(512 * 1024**2)
target = WORK / 'cpp-settle-readback'
assert not target.exists()
retained_control = ROOT / 'build-codex-tmp/level3-double-medium-settle-retention-work-20261006'
retained_work = Path('/dev/shm/lezac-level3-frontier-double-medium-settle-retention-20261006-t1')
name = 'post-overlap-double-medium-settle-20261006-cpp-raw-and-controls'
retained = fidelity.strict_json((retained_control / 'double-medium-settle-retention-complete.json').read_text())['retention']
proof = fidelity.strict_json((retained_control / (name + '-archive-proof.json')).read_text())
archive = retained_work / ('pr281-readback-' + name + '.tar.gz')
transport = protocol.transport_module()
for row in [retained] + retained['chunks']:
    assert transport.git(ROOT,'ls-remote','origin',row['ref']).split() == [row['notes_commit'],row['ref']]
assert transport.verify_archive(archive,proof['inventory'])['archive_sha256'] == retained['archive_sha256']
expected = {key[len('cpp-only/'):]: value for key,value in proof['inventory'].items() if key.startswith('cpp-only/')}
assert expected and sum(value['bytes'] for value in expected.values()) < 512 * 1024**2
target.mkdir()
seen = set()
with tarfile.open(archive,'r:gz') as bundle:
    for member in bundle:
        if not member.name.startswith('cpp-only/'):
            continue
        relative = member.name[len('cpp-only/'):]
        path = PurePosixPath(relative)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts
        assert relative in expected and relative not in seen
        destination = target / relative
        assert destination.is_relative_to(target) and not destination.exists()
        destination.parent.mkdir(parents=True,exist_ok=True)
        digest, count = hashlib.sha256(), 0
        with bundle.extractfile(member) as source, destination.open('xb') as output:
            while block := source.read(1024 * 1024):
                output.write(block)
                digest.update(block)
                count += len(block)
        assert dict(bytes=count,sha256=digest.hexdigest()) == expected[relative]
        seen.add(relative)
assert seen == set(expected)
save('cpp-extraction-proof.json',dict(status='retained_cpp_scout_recovered_byte_exact',members=len(seen),
    output=str(target),source_retention=retained,trace_sha256=fidelity.sha256(target / 'trace.jsonl'),
    producer_sha256=fidelity.sha256(Path(__file__)),whole_game_complete=False))
print('Retained C++ scout recovered with every member verified',flush=True)
