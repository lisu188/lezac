"""Bind an owned keeper and prove the exact native-prefix route before capture."""
from common import *
import json

def prepare(session):
    protected()
    capacity = reserve(2 * 1024 ** 3)
    assert not WORK.exists() and not OUT.exists()
    owners = []
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            identity = protocol.identity(int(proc.name))
            if identity['argv'] == protocol.MARKER:
                assert identity['exe'] == '/usr/bin/sleep'
                owners.append(identity)
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            pass
    assert len(owners) == 1
    report = fidelity.strict_json((SCOUT_CONTROL / 'scout-proof.json').read_text())
    assert report['status'] == 'double_medium_natural_settling_cpp_only_inspected'
    assert report['endpoint']['progress'] == [9,167] and not report['original_suffix_compared']
    assert report['first_outro']['endpoint']['tick'] == TICKS
    retained_control = ROOT / 'build-codex-tmp/level3-double-medium-settle-retention-work-20261006'
    assert fidelity.strict_json((retained_control / 'terminal-receipt.json').read_text())['exit_code'] == 0
    archive_proof = fidelity.strict_json((retained_control / 'post-overlap-double-medium-settle-20261006-cpp-raw-and-controls-archive-proof.json').read_text())
    assert archive_proof['inventory']['cpp-only/trace.jsonl']['sha256'] == report['trace_sha256']
    native = fidelity.strict_json((OLD_CONTROL / 'native-audit.json').read_text())
    assert native['status'] == 'original_medium_large_prefix_and_raw_suffix_verified'
    assert native['native_stream_sha256'] == NATIVE_SHA and native['ticks'] == FORK
    WORK.mkdir()
    settings, events = fidelity.read_route(ROUTE_SOURCE)
    lines = ['LEZAC_LEVEL1_ROUTE_V1', f'seed {settings["seed"]}', f'ticks {TICKS}', f'step_us {settings["step_us"]}']
    for tick, rows in sorted(events.items()):
        if tick <= TICKS:
            lines.extend(f'event {tick} {row["action"]} {row["key"]}' for row in rows)
    ROUTE.write_text('\n'.join([*lines,'end'])+'\n',encoding='ascii')
    route_bytes()
    hashes = {name: fidelity.sha256(DURABLE / name) for name in
        ('common.py', 'capture.py', 'prepare.py', 'private-capture.py', 'retain-and-close.py', 'compare.py', 'extract-cpp.py')}
    dependencies = (
        fidelity.strict_json((OLD_CONTROL / 'raw-retention-complete.json').read_text())['retention'],
        fidelity.strict_json((CPP_CONTROL / 'raw-retention-complete.json').read_text())['retention'],
        fidelity.strict_json((OLD_CONTROL / 'closed-controls-retention-complete.json').read_text())['retention'],
    )
    transport = protocol.transport_module()
    for retained in dependencies:
        for row in [retained] + retained['chunks']:
            assert transport.git(ROOT, 'ls-remote', 'origin', row['ref']).split() == [row['notes_commit'], row['ref']]
    save('preparation-proof.json', dict(status='double_medium_native_gate_extension_prepared', capacity=capacity,
        keeper=dict(identity=owners[0], tool_session=session), source_head=protocol.HEAD,
        executable_sha256=protocol.EXE_SHA, producer_hashes=hashes, route_sha256=fidelity.sha256(ROUTE),
        unchanged_prefix_frames=PREFIX_FRAMES, unchanged_prefix_tick=FORK, native_stream_sha256=NATIVE_SHA,
        candidate_report=report, independently_retained_dependencies=dependencies,
        audio='dummy', new_gameplay_state_injections=False, whole_game_complete=False))
    protocol.owner()
    print('Exact candidate prefix, owned keeper and two-GiB capture reserve verified', flush=True)

if __name__ == '__main__':
    prepare(int(sys.argv[1]))
