"""Repeat the verified gate, then observe native reels and a real Level 4 entry."""
from common import *
import gzip
import hashlib
import json
import struct

protected()
protocol.owner()
producer('common.py')
producer('capture.py')
save('native-capacity.json', reserve(2 * 1024**3))
assert not OUT.exists()
route_bytes()
spec = importlib.util.spec_from_file_location('results_preserved_native_parent', PARENT)
parent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parent)
parent.WORK, parent.OUT, parent.ROUTE, parent.FRAMES = WORK, OUT, ROUTE, FRAMES
parent.route_bytes = route_bytes
inherited_loader = parent.load_observer

def configured_loader():
    observer = inherited_loader()
    factory = observer.session_class

    def session_class(base):
        inherited = factory(base)

        class ResultsSession(inherited):
            def __init__(self, *args):
                self.raw_records, self.raw_stream, self.level4_complete = [], None, False
                super().__init__(*args)
                self.raw_stream = gzip.GzipFile(filename=str(self.output / 'results-handoff-ds.bin.gz'), mode='wb', mtime=0)
                shutil.copyfile(Path(__file__), self.output / 'capture.py')
                (self.output / 'results-runtime-configuration.json').write_bytes(original.json_bytes(dict(
                    source_sha256=fidelity.sha256(Path(__file__)), parent_sha256=PARENT_SHA,
                    route_sha256=ROUTE_SHA, prior_native_stream_sha256=NATIVE_SHA,
                    repeated_level3_frames=FRAMES, gate_tick=GATE, gate_native_frame=7798,
                    result_slot=observer.RESULTS_SLOT, ack_slot=observer.ACK_SLOT,
                    intro_slot=0x480, level4_first_cpp_tick=LEVEL4_FIRST, level4_frames=LEVEL4_FRAMES,
                    audio='dummy', normalized_gameplay_input_prefix_unchanged=True,
                    new_gameplay_state_injections=False, whole_game_complete=False)))

            def world(self):
                data = self.read(self.ds, 65536)
                width, scroll, level = original.word(data, 0xc204), original.word(data, 0x2096), data[0x79b7]
                assert scroll % 8 == 0 and 1 <= level <= 7
                dimensions = [width, scroll // 8 + 21]
                state = original.OriginalSession.state(self)
                for key, pointer, size in (('tiles', 0xc1e0, width * dimensions[1]),
                                           ('words', 0x6612, width * dimensions[1] * 2)):
                    offset, segment = struct.unpack_from('<HH', data, pointer)
                    assert 0 < segment < 0xa000 and offset + size <= 65536
                    state[key] = self.read(self.base + (segment << 4) + offset, size).hex()
                observer.validate_dynamic(state, dimensions, level)
                return state, dimensions

            def dynamic_state(self):
                return self.world()[0]

            def next_state(self):
                return self.world()

            def raw(self, role, state, dimensions, tick=None):
                data = self.read(self.ds, 65536)
                scratch = struct.unpack('<8HI', self.read(self.resident + original.SCRATCH, 20))
                assert scratch[8] == self.sequence and scratch[7] == 0
                if self.raw_records:
                    assert self.sequence == self.raw_records[-1]['sequence'] + 1
                assert original.word(data, 0x78c2) == state['frame'] and data[0x79b7] == dimensions[2]
                assert struct.unpack_from('<I', data, 0x1afe)[0] == state['rng']
                for key, offset, length in (('actors', 0x1bd4, state['actor_count'] * 38),
                        ('visuals', 0xc21e, data[0xc496] * 8), ('inventory', 0x1b6c, 12), ('scores', 0x785a, 92),
                        ('destruction', 0x78c6, 4), ('progress', 0x2076, 36), ('spawners', 0x74c6, data[0x79a6] * 30)):
                    assert data[offset:offset + length].hex() == state[key], (role, key)
                self.raw_stream.write(data)
                self.raw_records.append(dict(index=len(self.raw_records), role=role, cpp_tick=tick,
                    stage=scratch[0], sequence=self.sequence, native_frame=state['frame'], level=dimensions[2],
                    dimensions=dimensions[:2], sha256=hashlib.sha256(data).hexdigest()))

            def observe_results(self, baseline, atlas, route_sha):
                super().observe_results(baseline, atlas, route_sha)
                gate, dimensions = self.world()
                assert dimensions == [150, 60] and gate['frame'] == 7798
                segment = self.read(self.ds, 65536)
                assert segment[0x79c5:0x79c7] == b'\1\1' and original.word(segment, 0x2080) == 0
                assert original.word(segment, 0x78c8) == 167 and original.word(segment, 0x2088) == 9
                self.raw('gate_post', gate, [*dimensions, 3], GATE)
                # The parent's ordinary-control journal ends at the gate; Level 4 has no gameplay-key events.
                self.objective_sample = -1
                self.observe_level3_reels(gate, dimensions, original.word(segment, 0x2070))

            def observe_level3_reels(self, baseline, dimensions, atlas):
                producer, reels = base.producer, base.reels
                code = producer.palette_trampoline(reels.result_trampoline())
                ack_code = observer.ack_trampoline(self.native)
                with self.stopped():
                    assert self.read(self.cs + producer.ENTRY, 5) == original.far_call(observer.ACK_SLOT, self.resident_segment)
                    assert self.read(self.resident + observer.ACK_SLOT, len(ack_code)) == ack_code
                    assert self.read(self.resident + observer.RESULTS_SLOT, len(code)) == code
                    assert self.read(self.cs + reels.ENTRY, 5).hex() == reels.SIGNATURE
                    self.write(self.cs + producer.ENTRY, self.native)
                    for stage, (entry, signature) in enumerate(original.HOOKS, 1):
                        expected = bytes.fromhex(signature) if stage == 1 else original.far_call(
                            original.TRAMPOLINES + (stage - 1) * 0x80, self.resident_segment)
                        assert self.read(self.cs + entry, len(expected)) == expected
                        self.write(self.cs + entry, bytes.fromhex(signature))
                    self.write(self.cs + reels.ENTRY, original.far_call(observer.RESULTS_SLOT, self.resident_segment))
                self.release(4)
                previous, previous_rng, summary = bytes(192000), None, []
                with original.compressed_writer(self.output / 'level3-results.jsonl.gz') as emit:
                    emit(dict(kind='header', schema='lezac-private-level3-results-v1', baseline=baseline,
                        dimensions=dimensions, atlas=atlas, route_sha256=ROUTE_SHA, entry=reels.ENTRY,
                        signature=reels.SIGNATURE, audio='dummy', new_gameplay_state_injections=False,
                        original_fidelity_claim=False, whole_game_complete=False))
                    for index in range(100):
                        registers = self.wait(reels.STAGE)
                        active_player = original.word(self.read(self.base + (registers[3] << 4) + registers[5] - 4, 2), 0)
                        assert active_player == 1
                        state, current_dimensions = self.world()
                        assert current_dimensions == dimensions and all(state[key] == baseline[key] for key in reels.FROZEN)
                        if previous_rng is not None:
                            assert state['rng'] == (previous_rng * 0x08088405 + 1) & 0xffffffff
                        pixels = self.png(f'original_level3_results_{index:02d}')
                        self.raw('result', state, [*dimensions, 3])
                        phase = bytes.fromhex(state['scores'])[44]
                        emit(dict(kind='sample', sample=index, player=active_player, sequence=self.sequence,
                            registers=registers, state=state, dac=self.dac(),
                            rgb_delta_zlib_hex=original.encode_frame(pixels, previous),
                            rgb_sha256=hashlib.sha256(pixels).hexdigest()))
                        summary.append(dict(sample=index, phase=phase, rng=state['rng'],
                            score=int.from_bytes(bytes.fromhex(state['scores'])[:4], 'little')))
                        print(f'level3_results={index} phase={phase} score={summary[-1]["score"]}', flush=True)
                        previous, previous_rng = pixels, state['rng']
                        if phase == 2:
                            break
                        self.release(reels.STAGE)
                    else:
                        raise fidelity.EvidenceError('native Level 3 results did not settle')
                    emit(dict(kind='complete', samples=len(summary), gameplay_frozen=True,
                              original_fidelity_claim=False, whole_game_complete=False))
                self.level3_results_summary = summary
                settled = state
                with self.stopped():
                    assert self.read(self.cs + reels.ENTRY, 5) == original.far_call(observer.RESULTS_SLOT, self.resident_segment)
                    self.write(self.cs + reels.ENTRY, bytes.fromhex(reels.SIGNATURE))
                    assert self.read(self.resident + observer.ACK_SLOT, len(ack_code)) == ack_code
                    assert self.read(self.cs + producer.ENTRY, 5) == self.native
                    self.write(self.cs + producer.ENTRY, original.far_call(observer.ACK_SLOT, self.resident_segment))
                self.release(reels.STAGE)
                ack_regs = self.wait(observer.ACK_STAGE)
                ack, ack_dimensions = self.world()
                assert ack_dimensions == dimensions and all(ack[k] == settled[k] for k in reels.FROZEN + ('scores', 'rng'))
                ack_dac, ack_pixels, ack_sequence = self.dac(), self.png('original_level3_results_before_ack'), self.sequence
                self.raw('ack', ack, [*dimensions, 3], 9301)
                with self.stopped():
                    intro_code = producer.intro_trampoline(self.intro_native)
                    assert self.read(self.resident + 0x480, len(intro_code)) == intro_code
                    assert self.read(self.cs + producer.INTRO_ENTRY, 5) == original.far_call(0x480, self.resident_segment)
                    for stage, (entry, signature) in enumerate(original.HOOKS, 1):
                        assert self.read(self.cs + entry, len(signature) // 2).hex() == signature
                        if stage != 1:
                            owned = producer.palette_trampoline(original.trampoline(stage, self.image))
                            slot = original.TRAMPOLINES + (stage - 1) * 0x80
                            assert self.read(self.resident + slot, len(owned)) == owned
                            self.write(self.cs + entry, original.far_call(slot, self.resident_segment))
                ack_return = self.queue_return()
                self.release(observer.ACK_STAGE)
                intro_regs = self.wait(6)
                intro, next_dimensions = self.world()
                assert bytes.fromhex(intro['globals'])[0x17] == 4 and intro['frame'] == baseline['frame']
                intro_dac, intro_pixels, intro_sequence = self.dac(), self.png('original_level4_intro'), self.sequence
                self.raw('intro', intro, [*next_dimensions, 4], LEVEL4_FIRST - 1)
                intro_return = self.queue_return()
                next_atlas = original.word(self.read(self.ds + 0x2070, 2), 0)
                with original.compressed_writer(self.output / 'level4-handoff.jsonl.gz') as emit:
                    emit(dict(kind='header', schema='lezac-private-level3-level4-handoff-v1',
                        frames=LEVEL4_FRAMES, first_cpp_tick=LEVEL4_FIRST, dimensions=next_dimensions,
                        atlas=next_atlas, route_sha256=ROUTE_SHA, baseline=ack, baseline_dac=ack_dac,
                        ack_sequence=ack_sequence, ack_registers=ack_regs, ack=ack_return,
                        ack_rgb_sha256=hashlib.sha256(ack_pixels).hexdigest(), intro=intro,
                        intro_dac=intro_dac, intro_sequence=intro_sequence, intro_registers=intro_regs,
                        intro_ack=intro_return, intro_rgb_sha256=hashlib.sha256(intro_pixels).hexdigest(),
                        audio='dummy', new_gameplay_state_injections=False, original_fidelity_claim=False,
                        whole_game_complete=False))
                    self.release(6)
                    previous = bytes(192000)
                    for index in range(LEVEL4_FRAMES):
                        states, registers, palettes, sequences = [], [], [], []
                        pixels = None
                        for stage, role in ((2, 'pre'), (3, 'present'), (4, 'post_update')):
                            regs = self.wait(stage)
                            state, observed_dimensions = self.world()
                            assert observed_dimensions == next_dimensions and state['frame'] == 7799 + index
                            states.append(state)
                            registers.append(regs)
                            palettes.append(self.dac())
                            sequences.append(self.sequence)
                            self.raw(role, state, [*next_dimensions, 4], LEVEL4_FIRST + index)
                            if stage == 3:
                                pixels = self.png(f'original_level4_{index:02d}')
                            if stage != 4 or index + 1 < LEVEL4_FRAMES:
                                self.release(stage)
                        assert pixels is not None
                        emit(dict(kind='sample', sample=index, cpp_tick=LEVEL4_FIRST + index,
                            pre=states[0], rendered=states[1], post=states[2], registers=registers,
                            sequences=sequences, dac=palettes, rgb_sha256=hashlib.sha256(pixels).hexdigest(),
                            rgb_delta_zlib_hex=original.encode_frame(pixels, previous)))
                        previous = pixels
                        print(f'original_level4_sample={index + 1}/{LEVEL4_FRAMES} frame={state["frame"]}', flush=True)
                    emit(dict(kind='complete', frames=LEVEL4_FRAMES, native_level4_entry_observed=True,
                              original_fidelity_claim=False, whole_game_complete=False))
                self.level4_complete = True

            def close(self):
                try:
                    super().close()
                finally:
                    if self.raw_stream is not None:
                        self.raw_stream.close()
                    if self.output.is_dir():
                        (self.output / 'results-handoff-ds-journal.json').write_bytes(original.json_bytes(dict(
                            complete=self.level4_complete, records=self.raw_records, snapshot_bytes=65536,
                            new_gameplay_state_injections=False, raw_clock_sound_byte_parity=False)))
        return ResultsSession
    observer.session_class = session_class
    return observer

parent.load_observer = configured_loader

def validate():
    outcome = fidelity.strict_json((OUT / 'outcome-manifest.json').read_text())
    assert outcome['status'] == 'captured' and outcome['patches_restored'] and outcome['result_samples'] == 34
    assert not (OUT / 'failure.json').exists() and not (OUT / 'objective-observer-failure.json').exists()
    for name, digest in outcome['files'].items():
        assert fidelity.sha256(fidelity.safe_file(OUT, name)) == digest
    assert outcome['assets'] == {name: fidelity.sha256(ROOT / name) for name in fidelity.ASSETS}
    assert original.fingerprint(OUT) == handoff.PREFIX_SHA256
    old, new = handoff.load(NATIVE), handoff.load(OUT / 'level3-handoff.jsonl.gz')
    assert len(new) == len(old) == FRAMES + 2
    for prior, current in zip(old[1:-1], new[1:-1]):
        assert current['cpp_tick'] == prior['cpp_tick'] and current['rgb_sha256'] == prior['rgb_sha256']
        for index, phase in enumerate(('pre', 'rendered', 'post')):
            assert handoff.native_boundary(current[phase], current['dac'][index], new[0]['atlas']) == \
                handoff.native_boundary(prior[phase], prior['dac'][index], old[0]['atlas'])
    journal = fidelity.strict_json((OUT / 'objective-input-journal.json').read_text())
    assert journal['complete'] and len(journal['samples']) == FRAMES
    _, events = fidelity.read_route(ROUTE)
    for index, entry in enumerate(journal['samples']):
        assert entry['sample'] == index and entry['cpp_tick'] == 3777 + index
        assert entry['events'] == (events.get(3776 + index, []) if index >= 12 else [])
        before, after = bytes.fromhex(entry['before_bank_hex']), bytes.fromhex(entry['after_bank_hex'])
        expected = bytearray(before)
        for event in entry['events']:
            expected[original.BANK[event['key']] - 0x1b78] = event['action'] != 'up'
        assert len(before) == len(after) == 10 and bytes(expected) == after
    raw_journal = fidelity.strict_json((OUT / 'results-handoff-ds-journal.json').read_text())
    assert raw_journal['complete'] and raw_journal['snapshot_bytes'] == 65536
    with gzip.open(OUT / 'results-handoff-ds.bin.gz', 'rb') as stream:
        for index, entry in enumerate(raw_journal['records']):
            data = stream.read(65536)
            assert entry['index'] == index and len(data) == 65536 and hashlib.sha256(data).hexdigest() == entry['sha256']
            assert original.word(data, 0x78c2) == entry['native_frame'] and data[0x79b7] == entry['level']
        assert not stream.read(1)
    reels, next_level = handoff.load(OUT / 'level3-results.jsonl.gz'), handoff.load(OUT / 'level4-handoff.jsonl.gz')
    assert reels[-1]['gameplay_frozen'] and next_level[-1]['native_level4_entry_observed']
    assert len(next_level) == LEVEL4_FRAMES + 2 and len(raw_journal['records']) == len(reels[1:-1]) + 90
    assert next_level[0]['ack_sequence'] + 1 == next_level[0]['intro_sequence']
    for name in ('ack', 'intro_ack'):
        queued = next_level[0][name]
        before, after = bytes.fromhex(queued['before_bda_hex']), bytes.fromhex(queued['bda_hex'])
        assert len(before) == len(after) == 64 and original.word(before, 0x1a) == original.word(before, 0x1c)
        assert original.word(after, queued['head']) == queued['key_word'] == 0x1c0d
    final = next_level[-2]['post']
    mapped = campaign.native_boundary(final, next_level[-2]['dac'][2], next_level[0]['atlas'])
    save('native-audit.json', dict(status='original_level3_gate_reels_and_level4_entry_observed',
        repeated_original_level3_frames=FRAMES, repeated_original_level3_boundaries=FRAMES * 3,
        prior_native_stream_sha256=NATIVE_SHA, native_gate_stream_sha256=fidelity.sha256(OUT / 'level3-handoff.jsonl.gz'),
        native_results_sha256=fidelity.sha256(OUT / 'level3-results.jsonl.gz'), results_samples=len(reels[1:-1]),
        native_level4_stream_sha256=fidelity.sha256(OUT / 'level4-handoff.jsonl.gz'), level4_frames=LEVEL4_FRAMES,
        raw_ds_boundaries=len(raw_journal['records']), raw_ds_sha256=fidelity.sha256(OUT / 'results-handoff-ds.bin.gz'),
        raw_ds_journal_sha256=fidelity.sha256(OUT / 'results-handoff-ds-journal.json'), patches_restored=True,
        source_sha256=fidelity.sha256(Path(__file__)), route_sha256=ROUTE_SHA, final_mapped=mapped,
        audio='dummy', new_gameplay_state_injections=False, cpp_compared=False,
        original_results_and_level4_handoff_compared=False, full_actor_clock_sound_byte_parity=False,
        whole_game_complete=False))
    protected()
    print(json.dumps({k: v for k, v in load('native-audit.json').items() if k != 'final_mapped'}), flush=True)

parent.validate_capture = validate
parent.main()
