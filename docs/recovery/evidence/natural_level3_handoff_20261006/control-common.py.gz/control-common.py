"""Bind the unchanged natural route and an owned silent original observer."""
import importlib.util
import os
from pathlib import Path
import shutil
import sys

ROOT = Path('/mnt/c/Users/andrz/git/LEZAC')
DURABLE = Path(__file__).parent
WORK = Path('/dev/shm/lezac-level3-results-handoff-original-20261006-t1')
OUT = Path('/dev/shm/lezac-results-handoff-original-20261006-t1')
CPP_WORK = Path('/dev/shm/lezac-reward-pickup-phase-20261006-t1')
OLD_CONTROL = ROOT / 'build-codex-tmp/level3-double-medium-gate-original-work-20261006'
SCOUT_CONTROL = ROOT / 'build-codex-tmp/level3-double-medium-handoff-work-20261006'
sys.path.insert(0, str(ROOT / 'tools'))
import level1_fidelity as fidelity
import level1_original as original
import level1_handoff as handoff
import natural_campaign as campaign

SOURCE = ROOT / 'build-codex-tmp/level3-first-large-retime-work-20261006/probe-capture-version.py'
assert fidelity.sha256(SOURCE) == '626f4cb419ab7cb315bc7d56d7d80bf0fbfd93a62dbbc78967ef1aec3fc6e5a7'
spec = importlib.util.spec_from_file_location('results_owned_protocol', SOURCE)
reuse = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reuse)
protocol = reuse.protocol
protocol.DURABLE, protocol.WORK = DURABLE, WORK
protocol.SRC, protocol.EXE = CPP_WORK / 'src', CPP_WORK / 'build/lezac_cpp'
protocol.HEAD = protocol.BUILT_HEAD = 'e4a7f90872c3b9ea3d089b4aa652e9b16b33d6b8'
protocol.EXE_SHA = 'e1c95b811de11b1be1b0651448570a6f5736e3b6e39a5e34d2571aa14eee18d3'
protocol.MARKER = ['lezac-results-handoff-native-keepalive-20261006-t1', '86400']
save, reserve = protocol.save, protocol.reserve
GATE, LAST, FRAMES, LEVEL4_FIRST, LEVEL4_FRAMES = 8905, 9450, 5129, 9422, 29
NATIVE = Path('/dev/shm/lezac-double-medium-gate-original-20261006-t1/level3-handoff.jsonl.gz')
NATIVE_SHA = '481da8aae48e547d58dd912fdbd5e50d00dedcfb8c21d6ec88d3f66490a999d8'
PARENT = Path('/dev/shm/lezac-level3-east-support-20261006-t1/objective-observer-wrapper.py')
PARENT_SHA = '67fbad0106d75c06652708f8ec9667d2b607665947b26d5811d05e6c1c5206f7'
ROUTE = WORK / 'results-handoff-v1.route'
ROUTE_SOURCE = SCOUT_CONTROL / 'double-medium-handoff-v1.route'
ROUTE_SHA = 'f283afd6e746f43f972dc4721139dc18e1526dd801b99168b75704737771e09f'

def load(name):
    return fidelity.strict_json((DURABLE / name).read_text())

def protected():
    protocol.protected()
    assert fidelity.sha256(NATIVE) == NATIVE_SHA and fidelity.sha256(PARENT) == PARENT_SHA
    assert fidelity.sha256(ROUTE_SOURCE) == ROUTE_SHA

def producer(name):
    assert fidelity.sha256(DURABLE / name) == load('preparation-proof.json')['producer_hashes'][name]

def route_bytes():
    assert fidelity.sha256(ROUTE) == ROUTE_SHA
    settings, events = fidelity.read_route(ROUTE)
    prior_settings, prior = fidelity.read_route(Path('/dev/shm/lezac-level3-double-medium-gate-original-20261006-t1/double-medium-gate-v1.route'))
    assert settings['ticks'] == LAST and prior_settings['ticks'] == GATE
    assert all(settings[k] == prior_settings[k] for k in ('seed', 'step_us'))
    assert {tick: rows for tick, rows in events.items() if tick < GATE} == prior
    assert {tick: rows for tick, rows in events.items() if tick >= GATE} == {
        9301: [dict(action='down', key='return')], 9302: [dict(action='up', key='return')],
        9421: [dict(action='down', key='return')], 9422: [dict(action='up', key='return')]}
    return ROUTE.read_bytes()
