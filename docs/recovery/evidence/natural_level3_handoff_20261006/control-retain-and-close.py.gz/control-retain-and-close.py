"""Retain the complete native attempt before closing only its owned keeper."""
from common import *
import json
import select
import signal

def seal(name,members):
    transport = protocol.transport_module()
    reserve(512*1024**2)
    archive,proof = transport.archive(name,members)
    reserve(max(512*1024**2,6*proof['archive_bytes']+32*1024**2))
    retained = transport.publish(name,archive,proof)
    bare = WORK / ('pr281-readback-'+name+'.git')
    for row in [dict(ref=retained['ref'],blob=retained['manifest_blob'],notes_commit=retained['notes_commit'])]+retained['chunks']:
        assert transport.git(ROOT,'ls-remote','origin',row['ref']).split() == [row['notes_commit'],row['ref']]
        tree = transport.git(bare,'ls-tree','-r','--full-tree',row['ref']).splitlines()
        assert len(tree) == 1
        meta,anchor = tree[0].split('\t')
        assert meta.split() == ['100644','blob',row['blob']] and anchor.replace('/','') == protocol.HEAD
    retained['all_notes_tree_anchors_verified'] = True
    for suffix in ('-archive-proof.json','-transport-manifest.json'):
        source,target = WORK / (name+suffix),DURABLE / (name+suffix)
        assert not target.exists()
        shutil.copyfile(source,target)
        transport.same(source,target)
    return retained

def raw():
    protected()
    protocol.owner()
    producer('retain-and-close.py')
    receipt = load('capture-terminal-receipt.json')
    assert receipt['terminal']
    if receipt['exit_code'] == 0:
        assert load('native-audit.json')['status'] == 'original_level3_gate_reels_and_level4_entry_observed'
    transport = protocol.transport_module()
    members = {'controls/'+name:path for name,path in transport.files(DURABLE).items()}
    members.update({'original/'+name:path for name,path in transport.files(OUT).items()})
    members['route/results-handoff-v1.route'] = ROUTE
    members['source/pinned-native-parent.py'] = PARENT
    members['source/pinned-native-scout-protocol.py'] = SOURCE
    members['compiled/lezac_cpp'] = protocol.EXE
    retained = seal('level3-results-handoff-original-20261006-raw',members)
    save('raw-retention-complete.json',dict(status='native_attempt_independently_retained',retention=retained,
        actual_capture_exit_code=receipt['exit_code'],original_prefix_dependency=load('preparation-proof.json')['independently_retained_dependencies'][0],
        unique_raw_bytes_deleted=False,whole_game_complete=False))

def close():
    protected()
    expected = protocol.owner()
    assert load('capture-terminal-receipt.json')['terminal']
    retained = load('raw-retention-complete.json')['retention']
    transport = protocol.transport_module()
    for row in [retained]+retained['chunks']:
        assert transport.git(ROOT,'ls-remote','origin',row['ref']).split() == [row['notes_commit'],row['ref']]
    fd = os.pidfd_open(expected['identity']['pid'])
    try:
        assert protocol.identity(expected['identity']['pid']) == expected['identity']
        signal.pidfd_send_signal(fd,signal.SIGTERM)
        ready,_,_ = select.select([fd],[],[],15)
        assert ready
    finally:
        os.close(fd)
    save('keeper-closure-proof.json',dict(keeper=expected,pidfd_exit_verified=True,
        actual_tool_terminal_receipt_pending=True,original_capture_retained=True,whole_game_complete=False))
    print('Only the recorded owned keeper was closed after immutable raw retention',flush=True)

def finish():
    protected()
    expected = load('preparation-proof.json')['keeper']
    receipt = load('keeper-terminal-receipt.json')
    assert receipt['terminal'] and receipt['exit_code'] == 1 and receipt['session_id'] == expected['tool_session']
    assert load('keeper-closure-proof.json')['keeper'] == expected
    assert not Path('/proc/'+str(expected['identity']['pid'])).exists()
    members = {'controls/'+name:path for name,path in protocol.transport_module().files(DURABLE).items()}
    retained = seal('level3-results-handoff-original-20261006-closed-controls',members)
    save('closed-controls-retention-complete.json',dict(status='native_raw_and_actual_terminal_controls_retained',
        retention=retained,raw_dependency=load('raw-retention-complete.json')['retention'],
        unique_raw_bytes_deleted=False,whole_game_complete=False))
    print('Native raw bytes and actual closed controls independently retained',flush=True)

if __name__ == '__main__':
    {'raw':raw,'close':close,'finish':finish}[sys.argv[1]]()
