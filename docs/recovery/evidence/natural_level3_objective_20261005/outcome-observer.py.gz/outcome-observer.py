"""Private V18 observer with distinct gameplay and results-loop boundaries."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import os
from pathlib import Path
import shutil
import struct
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import capture_original_level1_handoff as producer
import capture_original_level1_results as reels
import capture_original_level1_typing as typing
import frame_compare
import level1_fidelity as fidelity
import level1_handoff as handoff
import level1_original as original

LIMIT = 2400
FIRST_TICK = handoff.FIRST_TICK + handoff.FRAMES
EVENT_PATH = ROOT / "build-codex-tmp/level2-three-objective-destruction-events-20261001-v18.json"
BASE_PATH = ROOT / "build-codex-tmp/capture-natural-level2-extension-20261001.py"
PINS = {
    EVENT_PATH: "537a4c1be31b176cc0390677607e43ddecd2e8e928faebebbaa1824f17ae5cd3",
    BASE_PATH: "acb311ed85fb594afc1d92d6774036a742388339b920bcc0f81206cabfb30dec",
    ROOT / "tools/capture_original_level1_results.py": "082e5c9f7f5c1fb34675aee8d4d7bb9a69bb78f382e79b98b860a723345fc093",
    ROOT / "tools/level1_handoff.py": "ecde70f0646331168a62424769a508968ac8f1cc53a974e441e42d918ba0e2a8",
    ROOT / "tools/level1_fidelity.py": "86ee5f4e762e10d945f9fe7a7e9a480d87cd9c80366e1ddfdf82506be768c760",
}
CLAIMS = {**dict.fromkeys(handoff.CLAIMS, False), "port_functionally_complete": False,
          "level3_handoff_claim": False, "typing_timing_claim": False}


def setup():
    for path, digest in PINS.items():
        fidelity.require(fidelity.sha256(path) == digest, "outcome dependency changed: " + path.name)
    handoff.check_sources()
    events = fidelity.strict_json(EVENT_PATH.read_text())
    parsed = {}
    for key, items in events.items():
        fidelity.require(key.isdigit() and str(int(key)) == key and int(key) < LIMIT and
                         isinstance(items, list) and items, "invalid event index")
        for item in items:
            fidelity.require(isinstance(item, list) and len(item) == 2 and item[0] in ("up", "down") and
                             item[1] in original.BANK, "non-gameplay input")
        parsed[int(key)] = [tuple(item) for item in items]
    spec = importlib.util.spec_from_file_location("outcome_base", BASE_PATH)
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    base.FRAMES, base.EVENTS = LIMIT, parsed
    return base, parsed


def eligible(state):
    flags = bytes.fromhex(state["globals"])[0x25:0x27]
    collapse = original.word(bytes.fromhex(state["progress"]), 10)
    return flags == b"\x01\x01" and collapse == 0


class OutcomeSession(producer.HandoffSession):
    result_patched = False
    result_restored = False

    def extend(self, emit, events, route_sha):
        initial = self.dynamic_state()
        fidelity.require(initial["frame"] == 317 and not eligible(initial), "incorrect extension start")
        atlas = original.word(self.read(self.ds + 0x2070, 2), 0)
        emit({"kind": "header", "schema": "lezac-private-level2-outcome-gameplay-v1",
              "frame_limit": LIMIT, "first_tick": FIRST_TICK, "atlas": atlas,
              "initial": initial, "route_sha256": route_sha, "audio": "dummy", **CLAIMS})
        previous = bytes(192000)
        for index in range(LIMIT):
            self.release(4)
            pre_regs = self.wait(2)
            pre, sequence, pre_dac = self.dynamic_state(), self.sequence, self.dac()
            input_events = [{"action": action, "key": key} for action, key in events.get(index, [])]
            for event in input_events:
                self.write(self.ds + original.BANK[event["key"]], bytes([event["action"] != "up"]))
            self.release(2)
            render_regs = self.wait(3)
            rendered, rendered_dac = self.dynamic_state(), self.dac()
            pixels = self.screenshot()
            self.release(3)
            post_regs = self.wait(4)
            post, post_dac = self.dynamic_state(), self.dac()
            fidelity.require(pre["frame"] == rendered["frame"] == post["frame"] == 318 + index,
                             "outcome observer skipped a native gameplay frame")
            gate = eligible(post)
            emit({"kind": "sample", "sample": index, "cpp_tick": FIRST_TICK + index,
                  "events": input_events, "registers": [pre_regs, render_regs, post_regs],
                  "sequences": [sequence, sequence + 1, sequence + 2],
                  "pre": pre, "rendered": rendered, "post": post,
                  "dac": [pre_dac, rendered_dac, post_dac], "gate_eligible": gate,
                  "rgb_delta_zlib_hex": original.encode_frame(pixels, previous),
                  "rgb_sha256": hashlib.sha256(pixels).hexdigest()})
            if index in (0, 1935, 2039, 2249, 2289, 2349) or gate:
                from PIL import Image
                Image.frombytes("RGB", (320, 200), pixels).save(self.output / f"original_gameplay_{index:04d}.png")
            previous = pixels
            if index % 20 == 0 or gate:
                progress = bytes.fromhex(post["progress"])
                print(f"level2_gameplay={index+1}/{LIMIT} frame={post['frame']} "
                      f"destroyed={original.word(bytes.fromhex(post['destruction']),2)} collapse={original.word(progress,10)} "
                      f"gate={gate}", flush=True)
            if gate:
                self.gameplay_count, self.gate = index + 1, post
                self.gate_tick = FIRST_TICK + index
                self.observe_results(post, atlas, route_sha)
                return
        raise fidelity.EvidenceError("ordinary route did not reach the native Level 2 completion gate")

    def observe_results(self, baseline, atlas, route_sha):
        # Reuse the owned ACK slot, never the adjacent intro or DAC storage.
        at = original.TRAMPOLINES + 4 * 0x80
        old = producer.palette_trampoline(typing.trampoline(self.native))
        code = producer.palette_trampoline(reels.result_trampoline())
        with self.stopped():
            fidelity.require(self.read(self.cs + producer.ENTRY, 5) == original.far_call(at, self.resident_segment),
                             "owned ACK entry changed before slot reuse")
            fidelity.require(self.read(self.resident + at, len(old)) == old, "owned ACK trampoline changed")
            fidelity.require(self.read(self.cs + reels.ENTRY, 5).hex() == reels.SIGNATURE, "results signature changed")
            self.write(self.cs + producer.ENTRY, self.native)
            for entry, signature in original.HOOKS:
                self.write(self.cs + entry, bytes.fromhex(signature))
            self.write(self.resident + at, code)
            self.result_patched = True
            self.write(self.cs + reels.ENTRY, original.far_call(at, self.resident_segment))
        self.release(4)
        previous, previous_rng, samples = bytes(192000), None, []
        with original.compressed_writer(self.output / "results.jsonl.gz") as emit:
            emit({"kind": "header", "schema": "lezac-private-level2-result-reels-v1",
                  "baseline": baseline, "atlas": atlas, "route_sha256": route_sha,
                  "entry": reels.ENTRY, "signature": reels.SIGNATURE,
                  "boundary": "native-loop-before-phase-test", **CLAIMS})
            for index in range(100):
                registers = self.wait(reels.STAGE)
                player = original.word(self.read(self.base + (registers[3] << 4) + registers[5] - 4, 2), 0)
                fidelity.require(player == 1, "unexpected results player")
                state = self.dynamic_state()
                changed = [key for key in reels.FROZEN if state[key] != baseline[key]]
                fidelity.require(not changed, "native results advanced gameplay: " + str(changed))
                if previous_rng is not None:
                    fidelity.require(state["rng"] == (previous_rng * 0x08088405 + 1) & 0xFFFFFFFF,
                                     "results loop did not make exactly one RNG draw")
                pixels = self.screenshot()
                phase = bytes.fromhex(state["scores"])[44]
                emit({"kind": "sample", "sample": index, "player": player,
                      "registers": registers, "sequence": self.sequence, "state": state, "dac": self.dac(),
                      "rgb_delta_zlib_hex": original.encode_frame(pixels, previous),
                      "rgb_sha256": hashlib.sha256(pixels).hexdigest()})
                samples.append({"sample": index, "phase": phase, "rng": state["rng"],
                                "score": int.from_bytes(bytes.fromhex(state["scores"])[:4], "little")})
                if index in (0, 1, 20) or phase == 2:
                    from PIL import Image
                    Image.frombytes("RGB", (320, 200), pixels).save(self.output / f"original_results_{index:02d}.png")
                    print(f"level2_results={index} phase={phase} score={samples[-1]['score']}", flush=True)
                previous, previous_rng = pixels, state["rng"]
                if phase == 2:
                    break
                self.release(reels.STAGE)
            else:
                raise fidelity.EvidenceError("native Level 2 reels did not settle")
            self.result_count = len(samples)
            self.result_summary = samples
            emit({"kind": "complete", "samples": len(samples), "steps": len(samples) - 1,
                  "gameplay_frozen": True, **CLAIMS})

    def close(self):
        try:
            if self.result_patched and self.child is not None and self.child.poll() is None:
                with self.stopped():
                    self.write(self.cs + reels.ENTRY, bytes.fromhex(reels.SIGNATURE))
                    self.result_restored = self.read(self.cs + reels.ENTRY, 5).hex() == reels.SIGNATURE
                    fidelity.require(self.result_restored, "results hook restoration failed")
        finally:
            super().close()


def capture(out, base, events):
    fidelity.require(os.environ.get("DISPLAY"), "private display required")
    fidelity.require(out.parent == Path("/dev/shm") and not out.exists(), "fresh RAM capture required")
    base.reserve(64 * 1024 * 1024)
    image = original.check_executable(ROOT / "LEZAC.EXE")
    fidelity.require(image[reels.ENTRY:reels.ENTRY+5].hex() == reels.SIGNATURE, "native results loop changed")
    os.environ["SDL_AUDIODRIVER"] = "dummy"
    os.environ.pop("SDL_VIDEODRIVER", None)
    out.mkdir()
    assets = {name: fidelity.sha256(ROOT / name) for name in fidelity.ASSETS}
    for path, name in ((Path(__file__), "outcome-observer.py"), (BASE_PATH, "extension-observer.py"),
                       (EVENT_PATH, "events.json"), (ROOT / "tools/capture_original_level1_handoff.py", "observer.py"),
                       (ROOT / "tools/capture_original_level1_results.py", "results-observer.py"),
                       (producer.PREFIX / "route.txt", "route.txt")):
        shutil.copyfile(path, out / name)
    route = base.route_bytes()
    (out / "extension-route.txt").write_bytes(route)
    route_sha = hashlib.sha256(route).hexdigest()
    args = argparse.Namespace(route=producer.PREFIX / "route.txt", startup_seconds=10, intro_seconds=3)
    try:
        with tempfile.TemporaryDirectory(prefix="lezac-level2-outcome-", dir="/dev/shm") as temporary:
            run = Path(temporary)
            for path in ROOT.iterdir():
                if path.suffix.upper() in {".EXE", ".DAT", ".SPR", ".PAL", ".SCH", ".SON", ".MST", ".CAR", ".ZBG", ".DOC"}:
                    shutil.copyfile(path, run / path.name)
            session = OutcomeSession(args, run, out)
            with original.compressed_writer(out / "reference.jsonl.gz") as prefix_emit, \
                    original.compressed_writer(out / "handoff.jsonl.gz") as handoff_emit, \
                    original.compressed_writer(out / "gameplay.jsonl.gz") as emit:
                session.handoff_emit = handoff_emit
                try:
                    count = session.capture(prefix_emit)
                    session.extend(emit, events, route_sha)
                finally:
                    session.close()
                fidelity.require(session.restored and session.ack_restored and session.intro_restored and
                                 session.result_restored, "not all observer hooks restored")
                prefix_emit({"kind": "complete", "samples": count, "frames": count,
                             "patches_restored": True, "original_fidelity_claim": False})
                handoff_emit({"kind": "complete", "frames": producer.FRAMES, "patches_restored": True,
                              "manual_input_claim": False, "wall_clock_claim": False, "original_fidelity_claim": False})
                emit({"kind": "complete", "frames": session.gameplay_count, "frame_limit": LIMIT,
                      "gate_cpp_tick": session.gate_tick, "gate_native_frame": session.gate["frame"],
                      "gate_eligible": True, "patches_restored": True, **CLAIMS})
        fidelity.require(assets == {name: fidelity.sha256(ROOT / name) for name in fidelity.ASSETS}, "assets changed")
        files = {name: fidelity.sha256(out / name) for name in
                 ("reference.jsonl.gz", "route.txt", "initial-ds.bin", "backdrop.bin", "dosbox.conf", "L1ORACLE.COM")}
        (out / "manifest.json").write_bytes(original.json_bytes({"schema": original.SCHEMA, "status": "captured",
            "assets": assets, "files": files, "original_fidelity_claim": False}))
        canonical = original.fingerprint(out)
        fidelity.require(canonical == handoff.PREFIX_SHA256, "natural prefix changed")
        handoff.validate(handoff.load(out / "handoff.jsonl.gz"))
        report = {"schema": "lezac-private-level2-outcome-manifest-v1", "status": "captured",
                  "frame_limit": LIMIT, "gameplay_frames": session.gameplay_count, "result_samples": session.result_count,
                  "gate_cpp_tick": session.gate_tick, "gate_native_frame": session.gate["frame"],
                  "prefix_canonical_sha256": canonical, "assets": assets, "patches_restored": True,
                  "files": {p.name: fidelity.sha256(p) for p in out.iterdir() if p.is_file()},
                  "producer_pins": {str(p.relative_to(ROOT)): sha for p, sha in PINS.items()},
                  "result_summary": session.result_summary, **CLAIMS}
        (out / "outcome-manifest.json").write_bytes(original.json_bytes(report))
        print(original.json_bytes({k: v for k, v in report.items() if k not in ("files", "result_summary", "assets")}).decode("ascii"), flush=True)
    except BaseException as error:
        (out / "failure.json").write_bytes(original.json_bytes({"status": "incomplete", "error": str(error), **CLAIMS}))
        raise


def validate_gameplay(rows, events):
    fidelity.require(len(rows) >= 3 and rows[0]["kind"] == "header" and
                     rows[0]["schema"] == "lezac-private-level2-outcome-gameplay-v1" and
                     rows[0]["frame_limit"] == LIMIT and rows[0]["first_tick"] == FIRST_TICK and
                     rows[0]["audio"] == "dummy", "invalid gameplay header")
    footer, samples = rows[-1], rows[1:-1]
    fidelity.require(footer["kind"] == "complete" and footer["frames"] == len(samples) and
                     1 <= len(samples) <= LIMIT and footer["frame_limit"] == LIMIT and
                     footer["gate_eligible"] is True and footer["patches_restored"] is True,
                     "invalid gameplay completion footer")
    previous, sequence = bytes(192000), None
    for index, row in enumerate(samples):
        fidelity.require(row["kind"] == "sample" and type(row["sample"]) is int and row["sample"] == index and
                         row["cpp_tick"] == FIRST_TICK + index and row["events"] ==
                         [{"action": action, "key": key} for action, key in events.get(index, [])],
                         "incorrect route alignment")
        fidelity.require(row["sequences"] == list(range(row["sequences"][0], row["sequences"][0]+3)) and
                         (sequence is None or row["sequences"][0] == sequence+3), "skipped gameplay handshake")
        sequence = row["sequences"][0]
        for field in ("pre", "rendered", "post"):
            state = row[field]
            fidelity.require(state["frame"] == 318 + index and
                             bytes.fromhex(state["globals"])[0x17] == 2 and
                             len(bytes.fromhex(state["tiles"])) == 5300 and
                             len(bytes.fromhex(state["words"])) == 10600, "invalid native gameplay boundary")
        fidelity.require(row["gate_eligible"] is eligible(row["post"]) and
                         row["gate_eligible"] == (index == len(samples)-1), "early or missing native gate")
        for value in row["dac"]:
            handoff.dac(value)
        previous = original.decode_frame(row["rgb_delta_zlib_hex"], previous, row["rgb_sha256"])
    fidelity.require(footer["gate_cpp_tick"] == samples[-1]["cpp_tick"] and
                     footer["gate_native_frame"] == samples[-1]["post"]["frame"], "wrong recorded gate")
    return samples


def validate_results(rows, baseline, atlas):
    fidelity.require(len(rows) >= 3 and rows[0]["kind"] == "header" and
                     rows[0]["schema"] == "lezac-private-level2-result-reels-v1" and
                     rows[0]["baseline"] == baseline and rows[0]["atlas"] == atlas and
                     rows[0]["entry"] == reels.ENTRY and rows[0]["signature"] == reels.SIGNATURE,
                     "invalid results header or baseline")
    footer, samples = rows[-1], rows[1:-1]
    fidelity.require(footer["kind"] == "complete" and footer["samples"] == len(samples) and
                     footer["steps"] == len(samples)-1 and footer["gameplay_frozen"] is True and
                     1 <= len(samples) <= 100, "incomplete results footer")
    raw = bytes.fromhex(baseline["scores"])
    initial_score = int.from_bytes(raw[:4], "little")
    inventory = bytes.fromhex(baseline["inventory"])
    award = original.word(bytes.fromhex(baseline["destruction"]), 2)*10 + inventory[1]*100 + inventory[2]*500 + inventory[3]*2000
    current = [((original.word(raw, offset)-atlas)&65535) for offset in range(4,22,2)]
    target = [((original.word(raw, offset)-atlas)&65535) for offset in range(24,42,2)]
    remaining, digit = initial_score+award, 0
    while True:
        target[digit] = remaining%10*64
        remaining //= 10
        digit += 1
        if not remaining or digit == 8:
            break
    phase, rng, sequence, previous = 1, baseline["rng"], None, bytes(192000)
    for index, row in enumerate(samples):
        fidelity.require(row["kind"] == "sample" and type(row["sample"]) is int and row["sample"] == index and
                         row["player"] == 1 and (sequence is None or row["sequence"] == sequence+1),
                         "incorrect results handshake alignment")
        sequence = row["sequence"]
        state = row["state"]
        fidelity.require(all(state[key] == baseline[key] for key in reels.FROZEN), "results advanced gameplay")
        if index:
            changed = any(a != b for a, b in zip(current,target))
            current = [(a+(16 if d%2 == 0 else 8))%640 if a != b else a for d,(a,b) in enumerate(zip(current,target))]
            if not changed:
                phase = 2
            rng = (rng*0x08088405+1)&0xFFFFFFFF
        projected = original.project_original(state, 1, atlas)
        fidelity.require(projected["players"][0]["reel"] == [initial_score+award, phase, *current, *target] and
                         state["rng"] == rng and phase == (2 if index == len(samples)-1 else 1),
                         "results score award, reel phase or RNG differs")
        handoff.dac(row["dac"])
        previous = original.decode_frame(row["rgb_delta_zlib_hex"], previous, row["rgb_sha256"])
    return samples


def compare(native, cpp, out, base, events):
    base.reserve(64 * 1024 * 1024)
    fidelity.require(not (native / "failure.json").exists(), "incomplete native outcome")
    report_native = fidelity.strict_json((native / "outcome-manifest.json").read_text())
    fidelity.require(report_native["status"] == "captured" and report_native["patches_restored"] is True and
                     report_native["prefix_canonical_sha256"] == handoff.PREFIX_SHA256, "invalid outcome provenance")
    for name, digest in report_native["files"].items():
        fidelity.require(fidelity.sha256(fidelity.safe_file(native, name)) == digest, "outcome file changed")
    fidelity.require((cpp / "route.txt").read_bytes() == (native / "extension-route.txt").read_bytes() == base.route_bytes(),
                     "different full input routes")
    rows = handoff.load(native / "gameplay.jsonl.gz")
    samples = validate_gameplay(rows, events)
    fidelity.require(len(samples) == report_native["gameplay_frames"], "manifest gameplay count differs")
    native_results = validate_results(handoff.load(native / "results.jsonl.gz"), samples[-1]["post"], rows[0]["atlas"])
    fidelity.require(len(native_results) == report_native["result_samples"], "manifest result count differs")
    manifest = fidelity.load_manifest(cpp)
    fidelity.require(manifest["asset_sha256"] == report_native["assets"], "different assets")
    checkpoints = {}
    for row in fidelity.trace_rows(cpp, manifest):
        if row["kind"] == "checkpoint" and row["phase"] in ("present", "post_update"):
            key = row["tick"], row["phase"]
            fidelity.require(key not in checkpoints, "duplicate C++ boundary")
            checkpoints[key] = row
    fidelity.require(out.parent == Path("/dev/shm") and not out.exists(), "fresh RAM comparison required")
    out.mkdir()
    atlas, previous, first, changed = rows[0]["atlas"], bytes(192000), None, 0
    for index, row in enumerate(samples):
        rgb = original.decode_frame(row["rgb_delta_zlib_hex"], previous, row["rgb_sha256"])
        previous = rgb
        for field, phase, pi in (("rendered", "present", 1), ("post", "post_update", 2)):
            fidelity.require((row["cpp_tick"], phase) in checkpoints, "missing C++ gameplay boundary")
            state = checkpoints[row["cpp_tick"], phase]["state"]
            diff = fidelity.first_difference(handoff.native_boundary(row[field], row["dac"][pi], atlas),
                                             handoff.boundary(state, bytes.fromhex(state["palette_rgb_hex"])))
            if first is None and diff:
                first = {"sample": index, "tick": row["cpp_tick"], "phase": phase, **diff}
        pixels = fidelity.read_ppm(cpp / checkpoints[row["cpp_tick"], "present"]["frame"])
        differing = sum(rgb[i:i+3] != pixels[i:i+3] for i in range(0, 192000, 3))
        changed += differing
        if first is None and differing:
            first = {"sample": index, "tick": row["cpp_tick"], "path": "$.rgb", "differing_pixels": differing}
        if index in (1935, 2039, 2249, 2289, 2349, len(samples)-1) or (first and first["sample"] == index):
            from PIL import Image
            for label, data in (("original", rgb), ("cpp", pixels)):
                Image.frombytes("RGB", (320, 200), data).save(out / f"{label}_{index:04d}.png")
    report = {"schema": "lezac-private-level2-outcome-gameplay-comparison-v1",
              "status": "match" if first is None and changed == 0 else "diverged",
              "frame_limit": LIMIT, "frames": len(samples), "states": len(samples)*2,
              "pixels": len(samples)*64000, "differing_pixels": changed, "first_difference": first,
              "gate_cpp_tick": samples[-1]["cpp_tick"], "gate_native_frame": samples[-1]["post"]["frame"],
              "cpp_executable_sha256": manifest["executable_sha256"], "cpp_trace_sha256": manifest["trace_sha256"],
              "native_gameplay_sha256": fidelity.sha256(native / "gameplay.jsonl.gz"),
              "native_results_observed": True, "results_compared": False, "all_dac_entries_compared": False, **CLAIMS}
    (out / "comparison.json").write_bytes(original.json_bytes(report))
    print(original.json_bytes(report).decode("ascii"), flush=True)
    fidelity.require(report["status"] == "match", "gameplay comparison diverged")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("capture", "compare"))
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--native", type=Path)
    parser.add_argument("--cpp", type=Path)
    parser.add_argument("--approve-procmem", action="store_true")
    parser.add_argument("--approve-runtime-instrumentation", action="store_true")
    args = parser.parse_args()
    os.environ["SDL_AUDIODRIVER"] = "dummy"
    base, events = setup()
    if args.command == "capture":
        fidelity.require(args.approve_procmem and args.approve_runtime_instrumentation, "observer approvals required")
        capture(args.out.resolve(), base, events)
    else:
        compare(args.native.resolve(), args.cpp.resolve(), args.out.resolve(), base, events)


if __name__ == "__main__":
    main()
