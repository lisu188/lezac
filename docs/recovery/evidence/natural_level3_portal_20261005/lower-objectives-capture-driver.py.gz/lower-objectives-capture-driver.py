"""Observe an ordinary lower-room extension with the unchanged pinned oracle."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

ROOT = Path('/mnt/c/Users/andrz/git/LEZAC')
WORK = Path('/dev/shm/lezac-level3-lower-objectives-20261005')
PREVIOUS = WORK / 'previous-native4'
PARENT = PREVIOUS / 'objective-observer-wrapper.py'
PARENT_SHA = '67fbad0106d75c06652708f8ec9667d2b607665947b26d5811d05e6c1c5206f7'
PRIOR_SHA = '24eca91a2bedbbc35aff0cfe9e782e041e802ef666db78e4f0c4ebc4cc09476e'
sys.path.insert(0, str(ROOT / 'tools'))
import level1_fidelity as fidelity
import level1_handoff as handoff
import level1_original as original

trial = int(sys.argv[sys.argv.index('--trial') + 1])
sys.argv.remove('--trial')
sys.argv.remove(str(trial))
assert trial == 3
REPORT = WORK / f'lower-objectives-trial-{trial}-report.json'
ROUTE = WORK / f'lower-objectives-trial-{trial}.route'
OUT = Path(f'/dev/shm/lezac-lower-objectives-original-20261005-t{trial}')
report = fidelity.strict_json(REPORT.read_text())
assert report['status'] == 'cpp_only_trial' and report['prefix_comparison']['status'] == 'match'
TICKS = report['route_ticks']
FRAMES = TICKS - 3776
assert FRAMES == 2452 and TICKS == 6228

def route_bytes():
    settings, events = fidelity.read_route(ROUTE)
    prior_settings, prefix = fidelity.read_route(WORK / 'previous.route')
    assert report['route_sha256'] == fidelity.sha256(ROUTE) and settings['ticks'] == TICKS
    assert all(settings[key] == prior_settings[key] for key in ('seed', 'step_us'))
    assert {tick: items for tick, items in events.items() if tick < 5908} == prefix
    assert all(item['key'] in original.BANK and item['action'] in ('down', 'up')
               for tick, items in events.items() if tick >= 5908 for item in items)
    return ROUTE.read_bytes()

assert fidelity.sha256(PARENT) == PARENT_SHA and fidelity.sha256(PREVIOUS / 'level3-handoff.jsonl.gz') == PRIOR_SHA
audit = fidelity.strict_json((PREVIOUS / 'lower-native-audit.json').read_text())
assert audit['status'] == 'captured_and_mapped_prefix_verified' and audit['patches_restored'] is True
assert audit['native_stream_sha256'] == PRIOR_SHA and audit['level3_frames'] == 2132
assert not OUT.exists() and OUT.resolve() == OUT
assert shutil.disk_usage(WORK).free - 1024 ** 3 > shutil.disk_usage(WORK).total // 10
route_bytes()
os.environ['SDL_AUDIODRIVER'] = 'dummy'
spec = importlib.util.spec_from_file_location('pinned_lower_objective_parent', PARENT)
parent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parent)
assert parent.FRAMES == 662
parent.WORK, parent.OUT, parent.ROUTE, parent.FRAMES = WORK, OUT, ROUTE, FRAMES
parent.route_bytes = route_bytes
inherited_loader = parent.load_observer

def configured_loader():
    observer = inherited_loader()
    factory = observer.session_class
    def session_class(base):
        native_session = factory(base)
        class VariantSession(native_session):
            def __init__(self, *args):
                super().__init__(*args)
                shutil.copyfile(Path(__file__), self.output / 'lower-objectives-capture-driver.py')
                (self.output / 'lower-objectives-runtime-configuration.json').write_bytes(original.json_bytes({
                    'variant_source_sha256': fidelity.sha256(Path(__file__)), 'parent_sha256': PARENT_SHA,
                    'parent_default_frames': 662, 'runtime_frames': FRAMES, 'route_ticks': TICKS,
                    'route_sha256': fidelity.sha256(ROUTE), 'unchanged_verified_level3_prefix_frames': 2132,
                    'prior_native_stream_sha256': PRIOR_SHA, 'prior_native_frames': 2132,
                    'audio': 'dummy', 'private_display_launcher': 'xvfb-run -a', 'display': os.environ['DISPLAY'],
                    'input_boundary': 'after pre snapshot before releasing stage2',
                    'new_gameplay_state_injections': False, 'manual_input_claim': False,
                    'whole_game_parity_claim': False}))
        return VariantSession
    observer.session_class = session_class
    return observer

parent.load_observer = configured_loader

def validate():
    outcome = fidelity.strict_json((OUT / 'outcome-manifest.json').read_text())
    assert outcome['status'] == 'captured' and outcome['patches_restored'] is True
    assert outcome['gameplay_frames'] == 2352 and outcome['result_samples'] == 34 and outcome['gate_cpp_tick'] == 3094
    assert not (OUT / 'failure.json').exists() and not (OUT / 'objective-observer-failure.json').exists()
    for name, digest in outcome['files'].items():
        assert fidelity.sha256(fidelity.safe_file(OUT, name)) == digest
    assert outcome['assets'] == {name: fidelity.sha256(ROOT / name) for name in fidelity.ASSETS}
    assert original.fingerprint(OUT) == handoff.PREFIX_SHA256 and (OUT / 'level3-route.txt').read_bytes() == route_bytes()
    assert outcome['files']['lower-objectives-capture-driver.py'] == fidelity.sha256(Path(__file__))
    assert outcome['files']['objective-observer-wrapper.py'] == PARENT_SHA
    rows = handoff.load(OUT / 'level3-handoff.jsonl.gz')
    samples = parent.load_observer().validate_rows(rows)
    assert len(samples) == FRAMES and rows[0]['dimensions'] == [150, 60]
    journal = fidelity.strict_json((OUT / 'objective-input-journal.json').read_text())
    assert journal['complete'] is True and len(journal['samples']) == FRAMES and journal['new_gameplay_state_injections'] is False
    events = parent.extension_events()
    for index, entry in enumerate(journal['samples']):
        assert entry['sample'] == index and entry['cpp_tick'] == 3777 + index and entry['events'] == events.get(index, [])
        before, after = bytes.fromhex(entry['before_bank_hex']), bytes.fromhex(entry['after_bank_hex'])
        assert len(before) == len(after) == 10
        wanted = bytearray(before)
        for event in entry['events']:
            wanted[original.BANK[event['key']] - 0x1b78] = event['action'] != 'up'
        assert bytes(wanted) == after
    previous = handoff.load(PREVIOUS / 'level3-handoff.jsonl.gz')
    assert len(previous) == 2134
    for index, old in enumerate(previous[1:-1]):
        new = samples[index]
        for pi, phase in enumerate(('pre', 'rendered', 'post')):
            assert handoff.native_boundary(old[phase], old['dac'][pi], previous[0]['atlas']) == handoff.native_boundary(new[phase], new['dac'][pi], rows[0]['atlas'])
        assert old['rgb_sha256'] == new['rgb_sha256']
    config = fidelity.strict_json((OUT / 'lower-objectives-runtime-configuration.json').read_text())
    assert config['runtime_frames'] == FRAMES and config['route_ticks'] == TICKS and config['variant_source_sha256'] == fidelity.sha256(Path(__file__))
    result = {'status': 'captured_and_mapped_prefix_verified', 'level3_frames': FRAMES, 'route_ticks': TICKS,
              'unchanged_native_prefix_frames': 2132, 'unchanged_native_prefix_boundaries': 6396,
              'native_stream_sha256': fidelity.sha256(OUT / 'level3-handoff.jsonl.gz'),
              'route_sha256': fidelity.sha256(ROUTE), 'variant_source_sha256': fidelity.sha256(Path(__file__)),
              'variant_configuration_sha256': fidelity.sha256(OUT / 'lower-objectives-runtime-configuration.json'),
              'prior_native_stream_sha256': PRIOR_SHA, 'parent_sha256': PARENT_SHA, 'patches_restored': True,
              'audio': 'dummy', 'runtime_configuration_recorded': True, 'new_gameplay_state_injections': False,
              'cpp_compared': False, 'natural_level3_completion_claim': False, 'whole_game_parity_claim': False}
    (OUT / 'lower-objectives-native-audit.json').write_bytes(original.json_bytes(result))
    print(json.dumps(result), flush=True)
    return result

parent.validate_capture = validate
parent.main()
