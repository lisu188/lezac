"""Private natural Level 2 acknowledgment, Level 3 intro and twelve entry frames."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import os
from pathlib import Path
import shutil
import struct
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT / "tools"))
import capture_original_level1_handoff as producer
import capture_original_level1_typing as typing
import level1_fidelity as fidelity
import level1_handoff as handoff
import level1_original as original

BASE = ROOT / "build-codex-tmp/capture-natural-level2-outcome-20261001.py"
BASE_SHA256 = "33869f46e0afa16ef9d64d7a045ed6e9dfa3e2a4c7f54f3c88add4b1ebafe774"
PREFIX = ROOT / "build-codex-tmp/level2-natural-results-evidence-20261001-v19/cpp-archive-provenance"
PREFIX_TICKS, ACK_TICK, INTRO_GAP, FRAMES = 3642, 3643, 134, 12
FIRST_TICK = ACK_TICK+INTRO_GAP
ACK_SLOT, ACK_STAGE, RESULTS_SLOT = 0x200, 7, 0x400
CLAIMS = {**dict.fromkeys(handoff.CLAIMS,False),"typing_timing_claim":False,
          "all_dac_entries_compared":False,"port_functionally_complete":False}


def base_module():
    fidelity.require(fidelity.sha256(BASE) == BASE_SHA256,"tested outcome producer changed")
    spec = importlib.util.spec_from_file_location("level3_outcome_base",BASE)
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    return base


def route_bytes():
    manifest = fidelity.strict_json((PREFIX / "manifest.json").read_text())
    fidelity.require(fidelity.sha256(PREFIX / "route.txt") == manifest["route_sha256"] and
                     manifest["trace_sha256"] == "51aa06c0df31d0070aef3d678ee90f76cc49ac62fabe1a1d50385b256e25d41c",
                     "verified result prefix route changed")
    settings, events = fidelity.read_route(PREFIX / "route.txt")
    fidelity.require(settings["ticks"] == PREFIX_TICKS,"unexpected prefix length")
    additions = {ACK_TICK-1:[{"action":"down","key":"return"}],
                 ACK_TICK:[{"action":"up","key":"return"}],
                 FIRST_TICK-1:[{"action":"down","key":"return"}],
                 FIRST_TICK:[{"action":"up","key":"return"}]}
    fidelity.require(not set(events)&set(additions),"handoff input overlaps prefix")
    lines = ["LEZAC_LEVEL1_ROUTE_V1","seed "+str(settings["seed"]),
             "ticks "+str(FIRST_TICK+FRAMES-1),"step_us "+str(settings["step_us"])]
    for tick,items in sorted({**events,**additions}.items()):
        for item in items:
            lines.append(f"event {tick} {item['action']} {item['key']}")
    return ("\n".join(lines+["end",""])).encode("ascii")


def ack_trampoline(native):
    code = typing.trampoline(native)
    for old,new in ((b"\x2e\xc7\x06"+struct.pack("<HH",original.SCRATCH,typing.STAGE),
                    b"\x2e\xc7\x06"+struct.pack("<HH",original.SCRATCH,ACK_STAGE)),
                   (b"\x2e\x83\x3e"+struct.pack("<H",original.SCRATCH+14)+bytes((typing.STAGE,)),
                    b"\x2e\x83\x3e"+struct.pack("<H",original.SCRATCH+14)+bytes((ACK_STAGE,)))):
        fidelity.require(code.count(old) == 1,"ack handshake instruction changed")
        code = code.replace(old,new)
    code = producer.palette_trampoline(code)
    fidelity.require(ACK_SLOT == original.TRAMPOLINES and ACK_SLOT+len(code) <= ACK_SLOT+0x80 and
                     ACK_SLOT != RESULTS_SLOT and ACK_SLOT+len(code) <= RESULTS_SLOT,
                     "ack would overwrite active results trampoline")
    return code


def validate_dynamic(state, dimensions, level):
    width,height = dimensions
    fidelity.require(type(width) is type(height) is int and 1 <= width <= 200 and 21 <= height <= 200 and
                     1980 <= width*height <= 16384,"unsupported observed map dimensions")
    fidelity.require(len(bytes.fromhex(state["tiles"])) == width*height and
                     len(bytes.fromhex(state["words"])) == width*height*2 and
                     bytes.fromhex(state["globals"])[0x17] == level,"incorrect level or full map planes")
    original.validate_raw({**state,"tiles":state["tiles"][:3960],"words":state["words"][:7920]})


def session_class(base):
    class NextLevelSession(base.OutcomeSession):
        next_ack_patched = False

        def __init__(self,*args):
            super().__init__(*args)
            shutil.copyfile(Path(__file__),self.output / "level3-handoff-observer.py")
            (self.output / "level3-route.txt").write_bytes(route_bytes())
            (self.output / "level3-controller.json").write_bytes(original.json_bytes({
                "schema":"lezac-private-level3-handoff-controller-v1","base_sha256":BASE_SHA256,
                "producer_sha256":fidelity.sha256(Path(__file__)),"ack_slot":ACK_SLOT,"ack_stage":ACK_STAGE,
                "active_results_slot":RESULTS_SLOT,"cpp_ack_tick":ACK_TICK,"cpp_first_tick":FIRST_TICK,
                "frames":FRAMES,"normal_return_input_only":True,"state_injections":False,"audio":"dummy",**CLAIMS}))

        def next_state(self):
            data = self.read(self.ds,65536)
            width,scroll = original.word(data,0xC204),original.word(data,0x2096)
            fidelity.require(scroll%8 == 0,"native scroll extent is not tile aligned")
            dimensions = [width,scroll//8+21]
            fidelity.require(1980 <= width*dimensions[1] <= 16384,"native map size is outside observation bounds")
            state = original.OriginalSession.state(self)
            for key,pointer,size in (("tiles",0xC1E0,width*dimensions[1]),
                                     ("words",0x6612,width*dimensions[1]*2)):
                offset,segment = struct.unpack_from("<HH",data,pointer)
                fidelity.require(0 < segment < 0xA000 and offset+size <= 65536,"invalid next-level map pointer")
                state[key] = self.read(self.base+(segment<<4)+offset,size).hex()
            validate_dynamic(state,dimensions,3)
            return state,dimensions

        def png(self,name):
            from PIL import Image
            pixels = self.screenshot()
            Image.frombytes("RGB",(320,200),pixels).save(self.output / (name+".png"))
            return pixels

        def queue_return(self):
            before = self.read(self.base+0x400,0x40)
            head,tail = original.word(before,0x1A),original.word(before,0x1C)
            fidelity.require(0x1E <= head < 0x3E and head%2 == 0 and head == tail,"Return queue was not empty")
            self.xdo("key","--clearmodifiers","Return")
            deadline = time.monotonic()+3
            while time.monotonic() < deadline:
                bios = self.read(self.base+0x400,0x40)
                head,tail = original.word(bios,0x1A),original.word(bios,0x1C)
                if head != tail:
                    break
                time.sleep(.01)
            fidelity.require(0x1E <= head < 0x3E and head%2 == 0 and
                             tail == (head+2 if head < 0x3C else 0x1E) and
                             original.word(bios,head) == 0x1C0D,"fresh Return did not enter BIOS queue")
            return {"head":head,"tail":tail,"key_word":0x1C0D,"before_bda_hex":before.hex(),"bda_hex":bios.hex()}

        def observe_results(self,baseline,atlas,route_sha):
            super().observe_results(baseline,atlas,route_sha)
            final_reels = self.dynamic_state()
            fidelity.require(bytes.fromhex(final_reels["scores"])[44] == 2 and final_reels["frame"] == 2669,
                             "next-level handoff did not start after settled Level 2 reels")
            # The CPU is paused inside 0x400. Only the inactive seed slot is reused.
            with self.stopped():
                scratch = struct.unpack("<8HI",self.read(self.resident+original.SCRATCH,20))
                fidelity.require(scratch[0] == base.reels.STAGE and scratch[7] == 0 and scratch[8] == self.sequence,
                                 "not paused at the owned settled results boundary")
                active_code = producer.palette_trampoline(base.reels.result_trampoline())
                fidelity.require(self.read(self.resident+RESULTS_SLOT,len(active_code)) == active_code and
                                 self.read(self.cs+base.reels.ENTRY,5) == original.far_call(RESULTS_SLOT,self.resident_segment),
                                 "owned active result trampoline changed")
                old_seed = original.trampoline(1,self.image)
                fidelity.require(self.read(self.resident+ACK_SLOT,len(old_seed)) == old_seed and
                                 self.read(self.cs+producer.ENTRY,5) == self.native,
                                 "inactive seed slot or restored ACK entry changed")
                self.write(self.cs+base.reels.ENTRY,bytes.fromhex(base.reels.SIGNATURE))
                code = ack_trampoline(self.native)
                self.write(self.resident+ACK_SLOT,code)
                self.next_ack_patched = True
                self.write(self.cs+producer.ENTRY,original.far_call(ACK_SLOT,self.resident_segment))
                fidelity.require(self.read(self.resident+RESULTS_SLOT,len(active_code)) == active_code,
                                 "active results code was overwritten")
            self.release(base.reels.STAGE)
            ack_regs = self.wait(ACK_STAGE)
            ack_sequence = self.sequence
            ack_state = self.dynamic_state()
            fidelity.require(all(ack_state[k] == final_reels[k] for k in base.reels.FROZEN+("scores","rng")),
                             "results acknowledgment advanced gameplay or changed settled score/RNG")
            ack_dac = self.dac()
            ack_pixels = self.png("original_level2_results_before_ack")
            with self.stopped():
                intro_code = producer.intro_trampoline(self.intro_native)
                fidelity.require(self.read(self.resident+0x480,len(intro_code)) == intro_code and
                                 self.read(self.cs+producer.INTRO_ENTRY,5) == original.far_call(0x480,self.resident_segment),
                                 "owned intro hook changed")
                for stage,(entry,signature) in enumerate(original.HOOKS,1):
                    fidelity.require(self.read(self.cs+entry,len(signature)//2).hex() == signature,
                                     "gameplay hook was not restored before next-level setup")
                    if stage != 1:
                        code = producer.palette_trampoline(original.trampoline(stage,self.image))
                        fidelity.require(self.read(self.resident+original.TRAMPOLINES+(stage-1)*0x80,len(code)) == code,
                                         "owned gameplay trampoline changed")
                        self.write(self.cs+entry,original.far_call(original.TRAMPOLINES+(stage-1)*0x80,self.resident_segment))
            queued = self.queue_return()
            self.release(ACK_STAGE)
            intro_regs = self.wait(6)
            intro_sequence = self.sequence
            intro,dimensions = self.next_state()
            fidelity.require(intro["frame"] == final_reels["frame"],"next intro advanced gameplay counter")
            (self.output / "level3-intro-ds.bin").write_bytes(self.read(self.ds,65536))
            intro_dac = self.dac()
            intro_pixels = self.png("original_level3_intro")
            next_atlas = original.word(self.read(self.ds+0x2070,2),0)
            intro_queued = self.queue_return()
            with original.compressed_writer(self.output / "level3-handoff.jsonl.gz") as emit:
                emit({"kind":"header","schema":"lezac-private-level2-level3-handoff-v1",
                      "frames":FRAMES,"first_cpp_tick":FIRST_TICK,"gate_native_frame":2669,
                      "observer_sha256":fidelity.sha256(Path(__file__)),"base_sha256":BASE_SHA256,
                      "native_exe_sha256":original.EXE_SHA256,"dimensions":dimensions,"atlas":next_atlas,
                      "baseline":ack_state,"baseline_dac":ack_dac,"ack_registers":ack_regs,
                      "ack_sequence":ack_sequence,"ack":queued,"intro":intro,"intro_dac":intro_dac,
                      "intro_registers":intro_regs,"intro_sequence":intro_sequence,"intro_ack":intro_queued,
                      "ack_rgb_sha256":hashlib.sha256(ack_pixels).hexdigest(),
                      "intro_rgb_sha256":hashlib.sha256(intro_pixels).hexdigest(),
                      "route_sha256":fidelity.sha256(self.output / "level3-route.txt"),**CLAIMS})
                self.release(6)
                previous = bytes(192000)
                for index in range(FRAMES):
                    pre_regs = self.wait(2)
                    pre,pre_dimensions = self.next_state()
                    sequence,pre_dac = self.sequence,self.dac()
                    self.release(2)
                    render_regs = self.wait(3)
                    rendered,render_dimensions = self.next_state()
                    rendered_dac,pixels = self.dac(),self.png(f"original_level3_{index:02d}")
                    self.release(3)
                    post_regs = self.wait(4)
                    post,post_dimensions = self.next_state()
                    fidelity.require(pre_dimensions == render_dimensions == post_dimensions == dimensions and
                                     pre["frame"] == rendered["frame"] == post["frame"] == 2670+index,
                                     "next-level observer skipped a frame or changed map dimensions")
                    emit({"kind":"sample","sample":index,"cpp_tick":FIRST_TICK+index,
                          "registers":[pre_regs,render_regs,post_regs],"sequences":[sequence,sequence+1,sequence+2],
                          "pre":pre,"rendered":rendered,"post":post,"dac":[pre_dac,rendered_dac,self.dac()],
                          "rgb_delta_zlib_hex":original.encode_frame(pixels,previous),
                          "rgb_sha256":hashlib.sha256(pixels).hexdigest()})
                    previous = pixels
                    print(f"original_level3_sample={index+1}/{FRAMES} frame={post['frame']} "
                          f"dimensions={dimensions} xy={post['players'][0]['xy']} rng={post['rng']}",flush=True)
                    if index+1 != FRAMES:
                        self.release(4)
                emit({"kind":"complete","frames":FRAMES,"native_level3_entry_observed":True,**CLAIMS})
            self.next_dimensions = dimensions

    return NextLevelSession


def validate_rows(rows):
    fidelity.require(len(rows) == FRAMES+2 and rows[0]["kind"] == "header" and
                     rows[0]["schema"] == "lezac-private-level2-level3-handoff-v1" and
                     rows[0]["frames"] == FRAMES and rows[0]["first_cpp_tick"] == FIRST_TICK and
                     rows[-1]["kind"] == "complete" and rows[-1]["frames"] == FRAMES and
                     rows[-1]["native_level3_entry_observed"] is True,"incomplete native Level 3 handoff")
    header = rows[0]
    fidelity.require(header["ack_sequence"]+1 == header["intro_sequence"],"skipped acknowledgment/intro boundary")
    for name in ("ack","intro_ack"):
        queue = header[name]
        bios,before = bytes.fromhex(queue["bda_hex"]),bytes.fromhex(queue["before_bda_hex"])
        head,tail = queue["head"],queue["tail"]
        fidelity.require(len(bios) == len(before) == 64 and original.word(before,0x1A) == original.word(before,0x1C) and
                         0x1E <= head < 0x3E and head%2 == 0 and tail == (head+2 if head < 0x3C else 0x1E) and
                         original.word(bios,0x1A) == head and original.word(bios,0x1C) == tail and
                         original.word(bios,head) == queue["key_word"] == 0x1C0D,"not a fresh single BIOS Return")
    fidelity.require(header["baseline"]["frame"] == header["intro"]["frame"] == 2669 and
                     bytes.fromhex(header["baseline"]["globals"])[0x17] == 2,"invalid handoff baseline")
    validate_dynamic(header["intro"],header["dimensions"],3)
    for value in (header["baseline_dac"],header["intro_dac"]):
        handoff.dac(value)
    previous = bytes(192000)
    for index,row in enumerate(rows[1:-1]):
        fidelity.require(row["kind"] == "sample" and type(row["sample"]) is int and row["sample"] == index and
                         row["cpp_tick"] == FIRST_TICK+index and
                         row["sequences"] == [header["intro_sequence"]+1+index*3+i for i in range(3)],
                         "incorrect next-level phase alignment")
        for field in ("pre","rendered","post"):
            validate_dynamic(row[field],header["dimensions"],3)
            fidelity.require(row[field]["frame"] == 2670+index,"skipped next-level native frame")
        fidelity.require(len(row["dac"]) == 3,"missing phase palettes")
        for value in row["dac"]:
            handoff.dac(value)
        previous = original.decode_frame(row["rgb_delta_zlib_hex"],previous,row["rgb_sha256"])
    return rows[1:-1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out",type=Path,required=True)
    parser.add_argument("--approve-procmem",action="store_true")
    parser.add_argument("--approve-runtime-instrumentation",action="store_true")
    args = parser.parse_args()
    fidelity.require(args.approve_procmem and args.approve_runtime_instrumentation,"observer approvals required")
    os.environ["SDL_AUDIODRIVER"] = "dummy"
    base = base_module()
    route_base,events = base.setup()
    route_base.reserve(96*1024*1024)
    base.OutcomeSession = session_class(base)
    out = args.out.resolve()
    base.capture(out,route_base,events)
    rows = handoff.load(out / "level3-handoff.jsonl.gz")
    validate_rows(rows)
    outcome = fidelity.strict_json((out / "outcome-manifest.json").read_text())
    report = {"schema":"lezac-private-level3-handoff-manifest-v1","status":"captured",
              "frames":FRAMES,"first_cpp_tick":FIRST_TICK,"dimensions":rows[0]["dimensions"],
              "patches_restored":outcome["patches_restored"],"native_level3_entry_observed":True,
              "handoff_sha256":fidelity.sha256(out / "level3-handoff.jsonl.gz"),
              "outcome_manifest_sha256":fidelity.sha256(out / "outcome-manifest.json"),
              "route_sha256":fidelity.sha256(out / "level3-route.txt"),
              "producer_sha256":fidelity.sha256(Path(__file__)),"base_sha256":BASE_SHA256,**CLAIMS}
    (out / "level3-manifest.json").write_bytes(original.json_bytes(report))
    print(original.json_bytes(report).decode("ascii"),flush=True)


if __name__ == "__main__":
    main()
