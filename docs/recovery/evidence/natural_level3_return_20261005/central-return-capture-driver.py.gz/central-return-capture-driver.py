"""Observe the ordinary-key 93-tile return without modifying gameplay state."""
import importlib.util
import os
from pathlib import Path
import shutil
import sys

ROOT = Path('/mnt/c/Users/andrz/git/LEZAC')
WORK = Path('/dev/shm/lezac-level3-return-20261005')
PREVIOUS = WORK / 'native'
PARENT = PREVIOUS / 'objective-observer-wrapper.py'
PARENT_SHA = '67fbad0106d75c06652708f8ec9667d2b607665947b26d5811d05e6c1c5206f7'
PRIOR_SHA = '8627e8522450a2a73bd77ac7724ad5f33bb9e55b91a96767e0694df452f0ced5'
ROUTE_SHA = '5e73ea2c87aaa55a9efbc0ddd5af509668be318df94a7bd401627a0f86ce11fc'
TICKS, PREFIX_TICK, PREFIX_FRAMES, FRAMES, PRIOR_FRAMES = 7065, 6580, 2804, 3289, 2989
ROUTE = WORK / 'central-return-original-t1.route'
OUT = Path('/dev/shm/lezac-central-return-original-20261005-t1')
sys.path.insert(0, str(ROOT / 'tools'))
import level1_fidelity as fidelity
import level1_handoff as handoff
import level1_original as original

restored = fidelity.strict_json((WORK / 'restoration-proof.json').read_text())
assert restored['status'] == 'pinned_return_dependencies_restored' and restored['all_archive_members_verified'] == 8148
report = fidelity.strict_json((WORK / 'restored-qa/return-central-trial-1-report.json').read_text())
assert report['status'] == 'cpp_only_return_central_trial' and report['prefix_comparison']['status'] == 'match'
assert report['fork_tick'] == PREFIX_TICK and report['route_ticks'] == TICKS
assert not ROUTE.exists() and not OUT.exists() and OUT.resolve() == OUT
assert fidelity.sha256(WORK / 'restored-cpp/route.txt') == report['route_sha256'] == ROUTE_SHA
shutil.copyfile(WORK / 'restored-cpp/route.txt', ROUTE)

def route_bytes():
    configured, current = fidelity.read_route(ROUTE)
    baseline, prior = fidelity.read_route(PREVIOUS / 'level3-route.txt')
    assert fidelity.sha256(ROUTE) == ROUTE_SHA and configured['ticks'] == TICKS and baseline['ticks'] == 6765
    assert all(configured[key] == baseline[key] for key in ('seed', 'step_us'))
    assert {tick: items for tick, items in current.items() if tick < PREFIX_TICK} == {tick: items for tick, items in prior.items() if tick < PREFIX_TICK}
    assert all(event['key'] in ('x', 'z', 'n', 'm') and event['action'] in ('up', 'down')
               for tick, items in current.items() if tick >= PREFIX_TICK for event in items)
    return ROUTE.read_bytes()

assert fidelity.sha256(PARENT) == PARENT_SHA and fidelity.sha256(PREVIOUS / 'level3-handoff.jsonl.gz') == PRIOR_SHA
usage = shutil.disk_usage(WORK)
assert usage.free - 1024 ** 3 > usage.total // 10
route_bytes()
os.environ['SDL_AUDIODRIVER'] = 'dummy'
spec = importlib.util.spec_from_file_location('pinned_central_return_parent', PARENT)
parent = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parent)
assert parent.FRAMES == 662
parent.WORK, parent.OUT, parent.ROUTE, parent.FRAMES = WORK, OUT, ROUTE, FRAMES
parent.route_bytes = route_bytes
inherited_loader = parent.load_observer

def configured_loader():
    observer = inherited_loader()
    factory = observer.session_class
    def session_class(base):
        native_session = factory(base)
        class VariantSession(native_session):
            def __init__(self, *args):
                super().__init__(*args)
                shutil.copyfile(Path(__file__), self.output / 'central-return-capture-driver.py')
                (self.output / 'central-return-runtime-configuration.json').write_bytes(original.json_bytes({
                    'variant_source_sha256': fidelity.sha256(Path(__file__)), 'parent_sha256': PARENT_SHA,
                    'parent_default_frames': 662, 'runtime_frames': FRAMES, 'route_ticks': TICKS,
                    'route_sha256': fidelity.sha256(ROUTE), 'unchanged_verified_level3_prefix_frames': PREFIX_FRAMES,
                    'unchanged_verified_prefix_tick': PREFIX_TICK, 'prior_native_stream_sha256': PRIOR_SHA,
                    'prior_native_frames': PRIOR_FRAMES, 'audio': 'dummy', 'private_display_launcher': 'xvfb-run -a',
                    'display': os.environ['DISPLAY'], 'input_boundary': 'after pre snapshot before releasing stage2',
                    'new_gameplay_state_injections': False, 'manual_input_claim': False, 'whole_game_parity_claim': False}))
        return VariantSession
    observer.session_class = session_class
    return observer

parent.load_observer = configured_loader

def validate():
    outcome = fidelity.strict_json((OUT / 'outcome-manifest.json').read_text())
    assert outcome['status'] == 'captured' and outcome['patches_restored'] is True
    assert outcome['gameplay_frames'] == 2352 and outcome['result_samples'] == 34 and outcome['gate_cpp_tick'] == 3094 and outcome['gate_native_frame'] == 2669
    assert not (OUT / 'failure.json').exists() and not (OUT / 'objective-observer-failure.json').exists()
    for name, digest in outcome['files'].items():
        assert fidelity.sha256(fidelity.safe_file(OUT, name)) == digest
    assert outcome['assets'] == {name: fidelity.sha256(ROOT / name) for name in fidelity.ASSETS}
    assert original.fingerprint(OUT) == handoff.PREFIX_SHA256 and (OUT / 'level3-route.txt').read_bytes() == route_bytes()
    assert outcome['files']['central-return-capture-driver.py'] == fidelity.sha256(Path(__file__))
    assert outcome['files']['objective-observer-wrapper.py'] == PARENT_SHA
    rows = handoff.load(OUT / 'level3-handoff.jsonl.gz')
    samples = parent.load_observer().validate_rows(rows)
    assert len(samples) == FRAMES and rows[0]['dimensions'] == [150, 60]
    journal = fidelity.strict_json((OUT / 'objective-input-journal.json').read_text())
    assert journal['complete'] is True and len(journal['samples']) == FRAMES and journal['new_gameplay_state_injections'] is False
    current = parent.extension_events()
    for index, entry in enumerate(journal['samples']):
        assert entry['sample'] == index and entry['cpp_tick'] == 3777 + index and entry['events'] == current.get(index, [])
        before, after = bytes.fromhex(entry['before_bank_hex']), bytes.fromhex(entry['after_bank_hex'])
        assert len(before) == len(after) == 10
        wanted = bytearray(before)
        for event in entry['events']:
            wanted[original.BANK[event['key']] - 0x1b78] = event['action'] != 'up'
        assert bytes(wanted) == after
    previous = handoff.load(PREVIOUS / 'level3-handoff.jsonl.gz')
    assert len(previous) == PRIOR_FRAMES + 2
    for index, old in enumerate(previous[1:PREFIX_FRAMES + 1]):
        new = samples[index]
        for pi, phase in enumerate(('pre', 'rendered', 'post')):
            assert handoff.native_boundary(old[phase], old['dac'][pi], previous[0]['atlas']) == handoff.native_boundary(new[phase], new['dac'][pi], rows[0]['atlas'])
        assert old['rgb_sha256'] == new['rgb_sha256']
    result = {'status': 'captured_and_mapped_prefix_verified', 'level3_frames': FRAMES, 'route_ticks': TICKS,
        'unchanged_native_prefix_frames': PREFIX_FRAMES, 'unchanged_native_prefix_boundaries': PREFIX_FRAMES * 3,
        'unchanged_verified_prefix_tick': PREFIX_TICK, 'native_stream_sha256': fidelity.sha256(OUT / 'level3-handoff.jsonl.gz'),
        'route_sha256': fidelity.sha256(ROUTE), 'variant_source_sha256': fidelity.sha256(Path(__file__)),
        'variant_configuration_sha256': fidelity.sha256(OUT / 'central-return-runtime-configuration.json'),
        'prior_native_stream_sha256': PRIOR_SHA, 'parent_sha256': PARENT_SHA, 'patches_restored': True,
        'audio': 'dummy', 'runtime_configuration_recorded': True, 'new_gameplay_state_injections': False,
        'cpp_compared': False, 'natural_level3_completion_claim': False, 'whole_game_parity_claim': False}
    (OUT / 'central-return-native-audit.json').write_bytes(original.json_bytes(result))
    print(original.json_bytes(result).decode(), flush=True)
    return result

parent.validate_capture = validate
parent.main()
