"""Observe the longer route using the pinned observer and explicit runtime configuration."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

ROOT = Path('/mnt/c/Users/andrz/git/LEZAC')
WORK = Path('/dev/shm/lezac-level3-regression-20261005')
OUT = Path('/dev/shm/lezac-level3-ledge-original-20261005')
ROUTE = WORK / 'ledge-jump-candidate.route'
PARENT = WORK / 'level3-native/capture-level3-objective-original.py'
PARENT_SHA = '67fbad0106d75c06652708f8ec9667d2b607665947b26d5811d05e6c1c5206f7'
PREVIOUS = WORK / 'level3-native/fresh-original'
FRAMES, TICKS = 1462, 5238
sys.path.insert(0, str(ROOT / 'tools'))
import level1_fidelity as fidelity
import level1_handoff as handoff
import level1_original as original
import natural_level3_objective as objective
require = fidelity.require


def route_bytes():
    report = fidelity.strict_json((WORK / 'ledge-jump-candidate-report.json').read_text())
    require(report['status'] == 'cpp_only_candidate_recorded' and report['route_ticks'] == TICKS and
            report['route_sha256'] == fidelity.sha256(ROUTE), 'candidate route provenance differs')
    settings, events = fidelity.read_route(ROUTE)
    prefix_settings, prefix = fidelity.read_route(objective.FIXTURE / 'route.txt')
    require(settings['ticks'] == TICKS and prefix_settings['ticks'] == 4438 and
            all(settings[key] == prefix_settings[key] for key in ('seed', 'step_us')) and
            {tick: items for tick, items in events.items() if tick < 4438} == prefix,
            'longer route changed the verified prefix')
    require(all(item['key'] in original.BANK and item['action'] in ('down', 'up')
                for tick, items in events.items() if tick >= 4438 for item in items),
            'non-gameplay continuation input')
    return ROUTE.read_bytes()


def validate_capture(parent):
    outcome = fidelity.strict_json((OUT / 'outcome-manifest.json').read_text())
    require(outcome['status'] == 'captured' and outcome['patches_restored'] is True and
            outcome['gameplay_frames'] == 2352 and outcome['result_samples'] == 34 and
            outcome['gate_cpp_tick'] == 3094 and not (OUT / 'failure.json').exists(),
            'longer capture did not complete its ordinary prefix')
    for name, digest in outcome['files'].items():
        require(fidelity.sha256(fidelity.safe_file(OUT, name)) == digest, 'native file changed: ' + name)
    require(outcome['files']['ledge-capture-driver.py'] == fidelity.sha256(Path(__file__)) and
            outcome['files']['objective-observer-wrapper.py'] == PARENT_SHA and
            (OUT / 'level3-route.txt').read_bytes() == route_bytes() and
            original.fingerprint(OUT) == handoff.PREFIX_SHA256 and
            outcome['assets'] == {name: fidelity.sha256(ROOT / name) for name in fidelity.ASSETS},
            'driver/source/route/prefix/assets provenance differs')
    observer = parent.load_observer()
    rows = handoff.load(OUT / 'level3-handoff.jsonl.gz')
    samples = observer.validate_rows(rows)
    require(rows[0]['dimensions'] == [150, 60], 'longer Level 3 map extent differs')
    journal = fidelity.strict_json((OUT / 'objective-input-journal.json').read_text())
    require(journal['complete'] is True and len(journal['samples']) == FRAMES and
            journal['new_gameplay_state_injections'] is False, 'longer input journal incomplete')
    events = parent.extension_events()
    for index, entry in enumerate(journal['samples']):
        require(entry['sample'] == index and entry['cpp_tick'] == 3777 + index and
                entry['events'] == events.get(index, []), 'longer native input phase differs')
        before, after = bytes.fromhex(entry['before_bank_hex']), bytes.fromhex(entry['after_bank_hex'])
        require(len(before) == len(after) == 10, 'input bank size differs')
        wanted = bytearray(before)
        for event in entry['events']:
            wanted[original.BANK[event['key']] - 0x1b78] = event['action'] != 'up'
        require(bytes(wanted) == after, 'undeclared gameplay control write')
    require(fidelity.sha256(PREVIOUS / 'level3-handoff.jsonl.gz') == objective.NATIVE_SHA256,
            'verified native prefix stream changed')
    previous = handoff.load(PREVIOUS / 'level3-handoff.jsonl.gz')
    require(len(previous) == 664, 'verified native prefix extent differs')
    for index, old in enumerate(previous[1:-1]):
        new = samples[index]
        for pi, phase in enumerate(('pre', 'rendered', 'post')):
            left = handoff.native_boundary(old[phase], old['dac'][pi], previous[0]['atlas'])
            right = handoff.native_boundary(new[phase], new['dac'][pi], rows[0]['atlas'])
            require(left == right, f'longer route changed mapped prefix {index} {phase}')
        require(old['rgb_sha256'] == new['rgb_sha256'], 'longer route changed a prefix image')
    report = {'status': 'captured_and_mapped_prefix_verified', 'level3_frames': FRAMES, 'route_ticks': TICKS,
              'unchanged_native_prefix_frames': 662, 'unchanged_native_prefix_boundaries': 1986,
              'native_stream_sha256': fidelity.sha256(OUT / 'level3-handoff.jsonl.gz'),
              'route_sha256': fidelity.sha256(ROUTE), 'driver_sha256': fidelity.sha256(Path(__file__)),
              'parent_sha256': PARENT_SHA, 'patches_restored': True, 'audio': 'dummy',
              'runtime_configuration_recorded': True, 'new_gameplay_state_injections': False,
              'raw_clock_sound_actor_byte_equivalence_claim': False, 'cpp_compared': False,
              'natural_level3_completion_claim': False, 'whole_game_parity_claim': False,
              'final_player': samples[-1]['post']['players'][0],
              'final_progress_hex': samples[-1]['post']['progress'],
              'final_destruction_hex': samples[-1]['post']['destruction']}
    (OUT / 'ledge-native-audit.json').write_bytes(original.json_bytes(report))
    print(json.dumps({key: value for key, value in report.items() if key != 'final_player'}), flush=True)
    return report


def main():
    require(fidelity.sha256(PARENT) == PARENT_SHA, 'pinned observer parent changed')
    require(not OUT.exists() and OUT.resolve() == OUT, 'fresh literal native output required')
    usage = shutil.disk_usage('/dev/shm')
    require(usage.free - 512 * 1024 ** 2 > usage.total // 10, 'longer capture crosses RAM reserve')
    route_bytes()
    os.environ['SDL_AUDIODRIVER'] = 'dummy'
    spec = importlib.util.spec_from_file_location('pinned_objective_capture_parent', PARENT)
    parent = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(parent)
    require(parent.FRAMES == 662, 'parent default frame count changed')
    parent.WORK, parent.OUT, parent.ROUTE, parent.FRAMES = WORK, OUT, ROUTE, FRAMES
    parent.route_bytes = route_bytes
    inherited_loader = parent.load_observer

    def configured_loader():
        observer = inherited_loader()
        inherited_factory = observer.session_class

        def session_class(base):
            native_session = inherited_factory(base)

            class DriverSession(native_session):
                def __init__(self, *args):
                    super().__init__(*args)
                    shutil.copyfile(Path(__file__), self.output / 'ledge-capture-driver.py')
                    (self.output / 'ledge-runtime-configuration.json').write_bytes(original.json_bytes({
                        'driver_sha256': fidelity.sha256(Path(__file__)), 'parent_sha256': PARENT_SHA,
                        'parent_default_frames': 662, 'runtime_frames': FRAMES, 'route_ticks': TICKS,
                        'route_sha256': fidelity.sha256(ROUTE), 'unchanged_verified_level3_prefix_frames': 662,
                        'input_boundary': 'after native pre snapshot before releasing stage2',
                        'audio': 'dummy', 'new_gameplay_state_injections': False,
                        'manual_input_claim': False, 'whole_game_parity_claim': False}))

            return DriverSession

        observer.session_class = session_class
        return observer

    parent.load_observer = configured_loader
    parent.validate_capture = lambda: validate_capture(parent)
    parent.main()


if __name__ == '__main__':
    main()
