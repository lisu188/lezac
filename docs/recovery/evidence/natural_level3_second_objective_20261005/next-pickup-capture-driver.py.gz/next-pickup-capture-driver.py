"""Run the pinned native observer with an explicit, source-recorded 982-frame variant."""
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

ROOT = Path('/mnt/c/Users/andrz/git/LEZAC')
WORK = Path('/dev/shm/lezac-level3-regression-20261005')
OUT = Path('/dev/shm/lezac-level3-next-pickup-original-20261005')
ROUTE = WORK / 'vertical-pickup-candidate.route'
PARENT = WORK / 'level3-native/capture-level3-objective-original.py'
PARENT_SHA = '67fbad0106d75c06652708f8ec9667d2b607665947b26d5811d05e6c1c5206f7'
DRIVER = WORK / 'capture-ledge-original.py'
DRIVER_SHA = 'a05109d598dea2cd393eedc2788d222cd0b041f3e9a3b1b5555e55977a80e281'
FRAMES, TICKS = 982, 4758
sys.path.insert(0, str(ROOT / 'tools'))
import level1_fidelity as fidelity
import level1_original as original
import natural_level3_objective as objective

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def route_bytes():
    report = fidelity.strict_json((WORK / 'vertical-pickup-candidate-report.json').read_text())
    assert report['status'] == 'cpp_only_candidate_recorded' and report['route_ticks'] == TICKS
    assert report['route_sha256'] == fidelity.sha256(ROUTE)
    settings, events = fidelity.read_route(ROUTE)
    prefix_settings, prefix = fidelity.read_route(objective.FIXTURE / 'route.txt')
    assert settings['ticks'] == TICKS and all(settings[key] == prefix_settings[key] for key in ('seed', 'step_us'))
    assert {tick: items for tick, items in events.items() if tick < 4438} == prefix
    assert all(item['key'] in original.BANK and item['action'] in ('down', 'up')
               for tick, items in events.items() if tick >= 4438 for item in items)
    assert all(item['key'] != 'n' for tick, items in events.items() if tick >= 4438 for item in items)
    return ROUTE.read_bytes()

def main():
    assert fidelity.sha256(PARENT) == PARENT_SHA and fidelity.sha256(DRIVER) == DRIVER_SHA
    assert not OUT.exists() and OUT.resolve() == OUT
    usage = shutil.disk_usage('/dev/shm')
    assert usage.free - 512 * 1024 ** 2 > usage.total // 10
    route_bytes()
    os.environ['SDL_AUDIODRIVER'] = 'dummy'
    driver = load('pinned_longer_capture_auditor', DRIVER)
    driver.OUT, driver.ROUTE, driver.FRAMES, driver.TICKS = OUT, ROUTE, FRAMES, TICKS
    driver.route_bytes = route_bytes
    parent = load('pinned_objective_capture_variant', PARENT)
    parent.WORK, parent.OUT, parent.ROUTE, parent.FRAMES = WORK, OUT, ROUTE, FRAMES
    parent.route_bytes = route_bytes
    inherited_loader = parent.load_observer

    def configured_loader():
        observer = inherited_loader()
        inherited_factory = observer.session_class

        def session_class(base):
            native_session = inherited_factory(base)

            class VariantSession(native_session):
                def __init__(self, *args):
                    super().__init__(*args)
                    shutil.copyfile(DRIVER, self.output / 'ledge-capture-driver.py')
                    shutil.copyfile(Path(__file__), self.output / 'next-pickup-capture-driver.py')
                    (self.output / 'next-pickup-runtime-configuration.json').write_bytes(original.json_bytes({
                        'variant_source_sha256': fidelity.sha256(Path(__file__)), 'auditor_sha256': DRIVER_SHA,
                        'parent_sha256': PARENT_SHA, 'parent_default_frames': 662, 'runtime_frames': FRAMES,
                        'route_ticks': TICKS, 'route_sha256': fidelity.sha256(ROUTE),
                        'unchanged_verified_level3_prefix_frames': 662, 'audio': 'dummy',
                        'input_boundary': 'after native pre snapshot before releasing stage2',
                        'new_gameplay_state_injections': False, 'manual_input_claim': False,
                        'whole_game_parity_claim': False}))

            return VariantSession

        observer.session_class = session_class
        return observer

    parent.load_observer = configured_loader

    def validate():
        report = driver.validate_capture(parent)
        outcome = fidelity.strict_json((OUT / 'outcome-manifest.json').read_text())
        assert outcome['files']['next-pickup-capture-driver.py'] == fidelity.sha256(Path(__file__))
        config = fidelity.strict_json((OUT / 'next-pickup-runtime-configuration.json').read_text())
        assert config['runtime_frames'] == FRAMES and config['route_ticks'] == TICKS
        assert config['variant_source_sha256'] == fidelity.sha256(Path(__file__))
        report.update({'variant_source_sha256': config['variant_source_sha256'],
                       'variant_configuration_sha256': fidelity.sha256(OUT / 'next-pickup-runtime-configuration.json')})
        (OUT / 'next-pickup-native-audit.json').write_bytes(original.json_bytes(report))
        print(json.dumps({key: value for key, value in report.items() if key != 'final_player'}), flush=True)
        return report

    parent.validate_capture = validate
    parent.main()

if __name__ == '__main__':
    main()
