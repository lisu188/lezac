"""Observe a 662-frame Level 3 route after ordinary Level 1/2 completion."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

ROOT = Path('/mnt/c/Users/andrz/git/LEZAC')
WORK = Path('/dev/shm/lezac-campaign-regression-20261005')
OUT = Path('/dev/shm/lezac-level3-objective-original-20261005')
sys.path.insert(0, str(ROOT / 'tools'))
import level1_fidelity as fidelity
import level1_handoff as handoff
import level1_original as original
import natural_campaign as campaign

OBSERVER = ROOT / 'build-codex-tmp/capture-natural-level3-handoff-20261001.py'
OBSERVER_SHA = '98a98127128d7aededb97f92468bcdac790a2eb59a4c425e39ea333de8b5b282'
ROUTE = WORK / 'level3-objective-candidate.route'
PREVIOUS = ROOT / 'build-codex-tmp/level3-failed-handoff-evidence-20261001-v20/lezac-natural-level3-handoff-original-20261001-v20'
FRAMES = 662
require = fidelity.require


def route_bytes():
    settings, events = fidelity.read_route(ROUTE)
    prefix_settings, prefix = fidelity.read_route(campaign.FIXTURE / 'route.txt')
    require(settings['ticks'] == 4438 and prefix_settings['ticks'] == 3788 and
            all(settings[k] == prefix_settings[k] for k in ('seed', 'step_us')) and
            {tick: items for tick, items in events.items() if tick < 3788} == prefix,
            'candidate changed the complete immutable prefix')
    require(all(item['key'] in original.BANK and item['action'] in ('down', 'up')
                for tick, items in events.items() if tick >= 3788 for item in items),
            'extension contains non-gameplay inputs')
    return ROUTE.read_bytes()


def load_observer():
    require(fidelity.sha256(OBSERVER) == OBSERVER_SHA, 'handoff observer source changed')
    spec = importlib.util.spec_from_file_location('objective_handoff_observer', OBSERVER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    require(module.FRAMES == 12 and module.FIRST_TICK == 3777, 'observer boundary contract changed')
    module.FRAMES = FRAMES
    module.route_bytes = route_bytes
    return module


def extension_events():
    route_bytes()
    _, events = fidelity.read_route(ROUTE)
    return {tick - 3776: items for tick, items in events.items() if tick >= 3788}


def validate_capture():
    observer = load_observer()
    base = observer.base_module()
    _, level2_events = base.setup()
    outcome = fidelity.strict_json((OUT / 'outcome-manifest.json').read_text())
    require(outcome['status'] == 'captured' and outcome['patches_restored'] is True and
            not (OUT / 'failure.json').exists() and outcome['gate_cpp_tick'] == 3094 and
            outcome['gameplay_frames'] == 2352 and outcome['result_samples'] == 34,
            'native completion capture did not finish')
    for name, digest in outcome['files'].items():
        require(fidelity.sha256(fidelity.safe_file(OUT, name)) == digest, 'native file changed: ' + name)
    require(outcome['assets'] == {name: fidelity.sha256(ROOT / name) for name in fidelity.ASSETS} and
            original.fingerprint(OUT) == handoff.PREFIX_SHA256 and
            (OUT / 'level3-route.txt').read_bytes() == route_bytes(), 'native assets/prefix/route changed')
    rows = handoff.load(OUT / 'level3-handoff.jsonl.gz')
    samples = observer.validate_rows(rows)
    require(rows[0]['dimensions'] == [150, 60], 'Level 3 map extent changed')
    journal = fidelity.strict_json((OUT / 'objective-input-journal.json').read_text())
    require(journal['complete'] is True and len(journal['samples']) == FRAMES, 'input journal incomplete')
    events = extension_events()
    for index, entry in enumerate(journal['samples']):
        require(entry['sample'] == index and entry['cpp_tick'] == 3777 + index and
                entry['events'] == events.get(index, []), 'input boundary differs')
        before, after = bytes.fromhex(entry['before_bank_hex']), bytes.fromhex(entry['after_bank_hex'])
        require(len(before) == len(after) == 10, 'native input bank size differs')
        wanted = bytearray(before)
        for event in entry['events']:
            wanted[original.BANK[event['key']] - 0x1b78] = event['action'] != 'up'
        require(bytes(wanted) == after, 'undeclared control bank write')

    # Compare every mapped phase and frame, leaving raw clock/sound bytes unclaimed.
    campaign.check_capture(PREVIOUS)
    prefix_frames = prefix_boundaries = 0
    for name, count, validator in (
        ('gameplay.jsonl.gz', 2352, lambda r: base.validate_gameplay(r, level2_events)),
        ('level3-handoff.jsonl.gz', 12, lambda r: r[1:-1])):
        old_rows, new_rows = handoff.load(PREVIOUS / name), handoff.load(OUT / name)
        old_samples, new_samples = validator(old_rows), validator(new_rows)
        require(len(old_samples) == count and len(new_samples) >= count, 'native prefix coverage differs')
        for index, old in enumerate(old_samples):
            new = new_samples[index]
            for pi, phase in enumerate(('pre', 'rendered', 'post')):
                difference = fidelity.first_difference(
                    handoff.native_boundary(old[phase], old['dac'][pi], old_rows[0]['atlas']),
                    handoff.native_boundary(new[phase], new['dac'][pi], new_rows[0]['atlas']))
                require(difference is None, f'native prefix {name} {index} {phase} differs: {difference}')
                prefix_boundaries += 1
            require(old['rgb_sha256'] == new['rgb_sha256'], 'native prefix pixels differ')
            prefix_frames += 1
    old_results = handoff.load(PREVIOUS / 'results.jsonl.gz')
    new_results = handoff.load(OUT / 'results.jsonl.gz')
    checked_results = base.validate_results(new_results, new_results[0]['baseline'], new_results[0]['atlas'])
    require(len(checked_results) == len(old_results[1:-1]) == 34, 'results prefix count differs')
    for old, new in zip(old_results[1:-1], checked_results):
        require(handoff.native_boundary(old['state'], old['dac'], old_results[0]['atlas']) ==
                handoff.native_boundary(new['state'], new['dac'], new_results[0]['atlas']) and
                old['rgb_sha256'] == new['rgb_sha256'], 'native result mapped state/pixels differ')
    report = {'status': 'captured_and_projected_prefix_verified', 'frames': FRAMES, 'route_ticks': 4438,
              'unchanged_prefix_frames': prefix_frames + 34, 'unchanged_prefix_boundaries': prefix_boundaries + 34,
              'route_sha256': fidelity.sha256(ROUTE), 'wrapper_sha256': fidelity.sha256(Path(__file__)),
              'native_stream_sha256': fidelity.sha256(OUT / 'level3-handoff.jsonl.gz'),
              'patches_restored': True, 'audio': 'dummy', 'new_gameplay_state_injections': False,
              'raw_clock_sound_actor_byte_equivalence_claim': False, 'cpp_compared': False,
              'natural_level3_completion_claim': False, 'whole_game_parity_claim': False,
              'final_mapped': handoff.native_boundary(samples[-1]['post'], samples[-1]['dac'][2], rows[0]['atlas'])}
    (OUT / 'objective-native-audit.json').write_bytes(original.json_bytes(report))
    print(json.dumps({k: v for k, v in report.items() if k != 'final_mapped'}), flush=True)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--approve-procmem', action='store_true')
    parser.add_argument('--approve-runtime-instrumentation', action='store_true')
    args = parser.parse_args()
    require(args.approve_procmem and args.approve_runtime_instrumentation, 'observer approvals required')
    require(OUT.resolve() == OUT and not OUT.exists(), 'fresh literal RAM output required')
    usage = shutil.disk_usage('/dev/shm')
    require(usage.free - 256 * 1024 ** 2 > usage.total // 10, 'capture crosses RAM reserve')
    os.environ['SDL_AUDIODRIVER'] = 'dummy'
    observer = load_observer()
    base = observer.base_module()
    route_base, prefix_events = base.setup()
    parent = observer.session_class(base)
    events = extension_events()

    class ObjectiveSession(parent):
        def __init__(self, *session_args):
            self.objective_sample = -1
            self.objective_journal = []
            super().__init__(*session_args)
            shutil.copyfile(Path(__file__), self.output / 'objective-observer-wrapper.py')
            (self.output / 'objective-controller.json').write_bytes(original.json_bytes({
                'wrapper_sha256': fidelity.sha256(Path(__file__)), 'observer_sha256': OBSERVER_SHA,
                'frames': FRAMES, 'unchanged_level3_prefix_frames': 12, 'events': events,
                'input_boundary': 'after pre snapshot before releasing stage2',
                'normalized_control_bank_injection': True, 'manual_input_claim': False,
                'new_gameplay_state_injections': False, 'audio': 'dummy'}))

        def next_state(self):
            state, dimensions = super().next_state()
            self.objective_sample = state['frame'] - 2670
            return state, dimensions

        def release(self, stage):
            if stage == 2 and self.objective_sample >= 0:
                index = self.objective_sample
                require(index == len(self.objective_journal) and index < FRAMES, 'duplicate/skipped input boundary')
                before = self.read(self.ds + 0x1b78, 10)
                items = events.get(index, [])
                for event in items:
                    self.write(self.ds + original.BANK[event['key']], bytes([event['action'] != 'up']))
                self.objective_journal.append({'sample': index, 'cpp_tick': 3777 + index, 'events': items,
                    'before_bank_hex': before.hex(), 'after_bank_hex': self.read(self.ds + 0x1b78, 10).hex()})
            super().release(stage)

        def close(self):
            try:
                super().close()
            finally:
                (self.output / 'objective-input-journal.json').write_bytes(original.json_bytes({
                    'complete': len(self.objective_journal) == FRAMES, 'samples': self.objective_journal,
                    'manual_input_claim': False, 'new_gameplay_state_injections': False}))

    base.OutcomeSession = ObjectiveSession
    captured = False
    try:
        base.capture(OUT, route_base, prefix_events)
        captured = True
        validate_capture()
    except BaseException as error:
        if OUT.is_dir():
            (OUT / 'objective-observer-failure.json').write_bytes(original.json_bytes({
                'status': 'failed_validation' if captured else 'incomplete_capture', 'error': str(error),
                'native_capture_returned': captured, 'wrapper_sha256': fidelity.sha256(Path(__file__)),
                'whole_game_parity_claim': False}))
        raise


if __name__ == '__main__':
    main()
