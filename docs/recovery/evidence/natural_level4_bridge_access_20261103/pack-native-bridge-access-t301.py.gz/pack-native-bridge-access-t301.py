"""Pack original-only observations. This producer never reads C++ traces."""
import ast
import gzip
import hashlib
import json
from pathlib import Path
import struct
import sys
from PIL import Image

ROOT = Path('/mnt/c/Users/andrz/git/lezac-level4-completion-20261103')
PRIVATE = Path(__file__).parent
NATIVE = Path('/dev/shm/lezac-native-level4-t301-climb_after_small')
FIXTURE = ROOT / 'tests/fixtures/natural_level4_bridge_access'
EVIDENCE = ROOT / 'docs/recovery/evidence/natural_level4_bridge_access_20261103'
sys.path.insert(0, str(ROOT / 'tools'))
import natural_level4_outside_column as prior

sha = lambda data: hashlib.sha256(data).hexdigest()
for directory in (FIXTURE, EVIDENCE):
    directory.mkdir(parents=True, exist_ok=False)
metadata = prior.manifest()
capture = json.loads((NATIVE / 'report.json').read_bytes())
assert capture['status'] == 'original_continuation_observed'
assert all(capture[k] for k in ('base_hooks_restored', 'extra_hooks_restored',
    'owned_child_terminal', 'protected_inputs_preserved'))
binding = json.loads((NATIVE / 'host-binding.json').read_bytes())
assert binding['observer_sha256'] == sha((NATIVE / 'observer.py').read_bytes()) == capture['observer_sha256']
assert binding['host'] == prior.HOST_PIN
route = (NATIVE / 'route.txt').read_bytes()
assert sha(route) == capture['route_sha256'] == 'cfe40241abbb966d3f4a8ce2d47ca8c5a86f0908076f638f72ca8e4c430878a4'
(FIXTURE / 'route.txt').write_bytes(route)
decoder = gzip.decompress((prior.EVIDENCE / 'pack-outside-column-t300.py.gz').read_bytes())
assert sha(decoder) == metadata['producer_pins']['pack-outside-column-t300.py']
function = [n for n in ast.parse(decoder.decode()).body if isinstance(n, ast.FunctionDef) and n.name == 'state_from_ds']
assert len(function) == 1
namespace = dict(original=prior.original, struct=struct)
exec(compile(ast.Module(body=function, type_ignores=[]), 'frozen-original-ds-decoder', 'exec'), namespace)
header = dict(kind='header', schema='lezac-natural-level4-bridge-access-v1', first_tick=12100,
    last_tick=13040, frames=941, boundaries=1882, native_frame_offset=1623, dimensions=[100,58],
    assets={name: sha((ROOT/name).read_bytes()) for name in prior.fidelity.ASSETS},
    route_sha256=sha(route), expected_bytes_source='original_only', cpp_expectations_used=False,
    completed_levels=[1,2,3], entered_level=4, initial_rng_controlled=True,
    normalized_control_bank_inputs=True, gameplay_state_injections=False, audio='dummy',
    full_ds_snapshots_published=False, prior_anchor_manifest=prior.MANIFEST_SHA256, **prior.CLAIMS)
rows, audit = [header], []
for tick in range(12100,13041):
    for phase in ('present','post_update'):
        observed = json.loads((NATIVE / f'boundary-{tick}-{phase}.json').read_bytes())
        raw = (NATIVE / f'ds-{tick}-{phase}.bin').read_bytes()
        assert observed['original_observation'] is True and len(raw)==65536 and sha(raw)==observed['ds_sha256']
        state = namespace['state_from_ds'](raw)
        mapped = prior.original.project_original(state,1,prior.original.word(raw,0x2070))
        del mapped['tiles_hex'], mapped['words_hex']
        mapped.update(level=4, score=int.from_bytes(raw[0x785a:0x785e],'little'),
            p2_inventory=list(raw[0x1b70:0x1b74])+[raw[0x1b75]-1], red_phase=raw[0x79ad])
        projection = observed['projection']
        assert mapped == {k:v for k,v in projection['mapped'].items() if k not in ('tiles_hex','words_hex','palette')}
        recovered=prior.support.recovered
        independent=dict(lifecycle=recovered.returned.native_lifecycle(state),
            monsters=recovered.projection.native_monsters(state,recovered.PROFILES[4]),
            markers=recovered.projection.native_markers(state), terrain=recovered.projection.native_terrain(raw))
        assert independent == {k:v for k,v in projection.items() if k!='mapped'}
        rgb=None
        if phase=='present':
            pixels=Image.open(NATIVE/f'original-level4-t298-{tick}-present.png').convert('RGB').tobytes()
            assert len(pixels)==192000
            rgb=sha(pixels)
        row=dict(kind='boundary',section='level4',index=tick,phase=phase,projection=projection,rgb_sha256=rgb)
        rows.append(row)
        audit.append(dict(index=tick,phase=phase,native_sequence=observed['sequence'],ds_sha256=sha(raw),
            projection_sha256=sha(prior.original.json_bytes(projection)),rgb_sha256=rgb))
rows.append(dict(kind='complete',frames=941,boundaries=1882,patches_restored=True))
payload=b''.join(prior.original.json_bytes(row) for row in rows)
assert len(payload.splitlines())==1884 and all(payload.splitlines())
(FIXTURE/'reference.jsonl.gz').write_bytes(gzip.compress(payload,compresslevel=9,mtime=0))
audit_report=dict(schema='lezac-native-bridge-access-ds-audit-v1',boundaries=1882,records=audit,
    ds_redecode_differences=0,excluded_from_ds_redecode=['mapped.tiles_hex','mapped.words_hex','mapped.palette'],
    raw_ds_snapshots_published=False,full_guest_ram_exports=0)
pins={}
def retain(name,data,compressed=False):
    raw=gzip.compress(data,compresslevel=9,mtime=0) if compressed else data
    (EVIDENCE/name).write_bytes(raw)
    assert (EVIDENCE/name).read_bytes()==raw
    pins[name]=sha(raw)
retain('native-audit.json.gz',prior.original.json_bytes(audit_report),True)
for source,destination in (('report.json','capture-report.json.gz'),('host-binding.json','host-binding.json.gz')):
    retain(destination,(NATIVE/source).read_bytes(),True)
retain('dosbox.conf',(NATIVE/'dosbox.conf').read_bytes())
for tick in (12100,12560,13040):
    retain(f'original_{tick}.png',(NATIVE/f'original-level4-t298-{tick}-present.png').read_bytes())
producer_pins={}
sources=[NATIVE/'observer.py',PRIVATE/'capture-outside-column-host-bound-t300.py',
    PRIVATE/'capture-level4-continuation-t298.py',Path(__file__)]
active=['level1_original.py','level1_fidelity.py','capture_original_level1_handoff.py',
    'capture_original_level1_results.py','capture_original_level1_typing.py','natural_level4_support_column.py',
    'natural_level3_handoff.py','natural_level3_return.py','natural_level3_gate_projections.py','natural_campaign.py',
    'frame_compare.py','seed_original_level.py','original_debris_table.py','original_capture_contract.py',
    'natural_level4_outside_column.py']
sources += [ROOT/'tools'/name for name in active]
for source in sources:
    name='capture-level4-completion-t301.py' if source.name=='observer.py' else source.name
    data=source.read_bytes()
    retain(name+'.gz',data,True)
    producer_pins[name]=sha(data)
retain('frozen-ds-decoder.py.gz',decoder,True)
producer_pins['frozen-ds-decoder.py']=sha(decoder)
for label in ('report.json','byte-checks.json','call-6c5b.json'):
    retain('rea-'+label+'.gz',(Path('/dev/shm/lezac-level4-launch-rea-t301')/label).read_bytes(),True)
manifest=dict(schema='lezac-native-level4-bridge-access-evidence-v1',expected_bytes_source='original_only',
    reference_header=header,original_exe_sha256=prior.original.EXE_SHA256,original_exe_bytes=52384,
    source_capture=str(NATIVE),native_sessions_closed=True,raw_ds_snapshot_retention='RAM-only; not claimed durably retained',
    cpp_expectations_used=False,full_guest_ram_exports=0,core_dumps=0,reference_frames=941,reference_boundaries=1882,
    producer_pins=producer_pins,guard_producer_pins={},evidence_file_pins=pins,
    fixture_pins={name:sha((FIXTURE/name).read_bytes()) for name in ('route.txt','reference.jsonl.gz')})
(EVIDENCE/'manifest.json').write_bytes(prior.original.json_bytes(manifest))
print(json.dumps(dict(reference_rows=len(rows),original_boundaries=len(audit),reference_sha256=sha((FIXTURE/'reference.jsonl.gz').read_bytes()))))
