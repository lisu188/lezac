"""Observe ordinary controls after the original-verified bridge checkpoint."""
import ast
import hashlib
import os
from pathlib import Path
import resource
import shutil
import signal
import sys

PRIVATE = Path(__file__).parent
ROOT = Path('/mnt/c/Users/andrz/git/lezac-level4-final-demolition-20261103')
sys.path.insert(0, str(ROOT / 'tools'))
import natural_level4_bridge_access as reference

resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
name = sys.argv[1]
assert name and all(c.isalnum() or c == '_' for c in name)
route = Path('/dev/shm/lezac-level4-final-t302') / name / 'route.txt'
out = Path('/dev/shm') / ('lezac-native-level4-t302-' + name)
assert Path.cwd() == out.parent and not out.exists()
assert shutil.disk_usage('/dev/shm').used / shutil.disk_usage('/dev/shm').total < .75
assert os.environ.get('SDL_AUDIODRIVER') == 'dummy'
settings, events = reference.fidelity.read_route(route)
baseline_settings, baseline_events = reference.check_route(reference.FIXTURE / 'route.txt')
assert 13040 < settings['ticks'] <= 14000
assert settings == {**baseline_settings, 'ticks': settings['ticks']}
assert {t: rows for t, rows in events.items() if t <= 13040} == baseline_events
reference.fixture()
base = PRIVATE / 'capture-outside-column-host-bound-t300.py'
raw = base.read_bytes()
assert hashlib.sha256(raw).hexdigest() == reference.prior.manifest()['repeat_producer_pins'][base.name]
changes = {
    '/mnt/c/Users/andrz/git/lezac-level4-return-portal-20261103': str(ROOT),
    "Path('/dev/shm/lezac-outside-column-t300/original-repeat')": f'Path({str(out)!r})',
    "ROOT / 'tests/fixtures/natural_level4_outside_column/route.txt'": f'Path({str(route)!r})',
    "{(row['index'],row['phase']): row for row in support.fixture()[1:-1] if row['section']=='level4' and row['index']<=11300}":
        "{(row['index'],row['phase']): row for row in support.fixture()[1:-1] + "
        "__import__('natural_level4_bridge_access').fixture()[1:-1] "
        "if row['section']=='level4' and row['index']<=13040}",
    "tick == last or (level == 4 and (tick == 9422 or tick >= 11300))":
        "tick == last or (level == 4 and (tick == 9422 or tick >= 13040))",
    "assert {t:r for t,r in events.items() if t<11300} == {t:r for t,r in old_events.items() if t<11300}":
        "assert {t:r for t,r in events.items() if t<=13040} == "
        "__import__('natural_level4_bridge_access').check_route(ROOT / "
        "'tests/fixtures/natural_level4_bridge_access/route.txt')[1]",
    "report.update(base_observer_sha256=BASE_OBSERVER_SHA256, first_full_frame_tick=11300,last_full_frame_tick=settings['ticks'],full_frame_window_only=True)":
        "report.update(base_observer_sha256=BASE_OBSERVER_SHA256, first_full_frame_tick=13040,"
        "last_full_frame_tick=settings['ticks'],full_frame_window_only=True)",
}
counts = dict.fromkeys(changes, 0)

class Configure(ast.NodeTransformer):
    def visit_Constant(self, node):
        if isinstance(node.value, str) and node.value in changes:
            counts[node.value] += 1
            return ast.copy_location(ast.Constant(changes[node.value]), node)
        return node

tree = Configure().visit(ast.parse(raw.decode(), filename=str(base)))
assert set(counts.values()) == {1}, counts
ast.fix_missing_locations(tree)

def expired(*unused):
    raise TimeoutError('Original continuation exceeded its bounded capture deadline')

signal.signal(signal.SIGALRM, expired)
signal.alarm(1800)
try:
    exec(compile(tree, str(base), 'exec'), {'__name__': '__main__', '__file__': str(Path(__file__))})
finally:
    signal.alarm(0)
