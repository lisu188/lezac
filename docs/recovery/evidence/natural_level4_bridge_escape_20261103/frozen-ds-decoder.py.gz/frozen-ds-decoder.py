"""Pack original-only Level 4 projected expectations; never read a C++ output."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import struct
import sys

ROOT = Path('/mnt/c/Users/andrz/git/lezac-level4-return-portal-20261103')
PRIVATE = Path(__file__).parent
CAPTURE = Path('/dev/shm/lezac-native-level4-outside-pillar-t299')
FIXTURE = ROOT / 'tests/fixtures/natural_level4_outside_column'
EVIDENCE = ROOT / 'docs/recovery/evidence/natural_level4_outside_column_20261103'
sys.path.insert(0, str(ROOT / 'tools'))
import level1_fidelity as fidelity
import level1_original as original
import natural_level4_support_column as support
from PIL import Image

sha = lambda raw: hashlib.sha256(raw).hexdigest()
encode = original.json_bytes
FIRST, LAST, PLACEMENT = 11300, 12100, 11843
capture = fidelity.strict_json((CAPTURE / 'report.json').read_text())
assert capture['status'] == 'original_continuation_observed'
assert all(capture[key] for key in ('base_hooks_restored', 'extra_hooks_restored',
    'owned_child_terminal', 'protected_inputs_preserved', 'initial_rng_controlled',
    'normalized_control_bank_inputs', 'ordinary_gameplay_inputs_only'))
assert not any(capture[key] for key in ('gameplay_state_injections', 'full_guest_ram_exports',
    'core_dumps', 'manual_input_claim', 'wall_clock_claim', 'whole_game_fidelity_claim'))
assert capture['original_exe_sha256'] == original.EXE_SHA256
assert [(r['from_level'], r['to_level'], r['intro_frame'], r['intro_rng']) for r in capture['handoffs']] == [
    (1, 2, 305, 2497022769), (2, 3, 2669, 3666694644), (3, 4, 7798, 1603369198)]
route = (CAPTURE / 'route.txt').read_bytes()
assert sha(route) == capture['route_sha256'] == '5007fb684c11a1e8d3affeb94645275ef6d0b9fa832462ad73c96605ad3feead'
settings, events = fidelity.read_route(CAPTURE / 'route.txt')
_, previous_events = support.check_route(support.FIXTURE / 'route.txt')
assert {t: e for t, e in events.items() if t < FIRST} == {t: e for t, e in previous_events.items() if t < FIRST}
assert settings['ticks'] == LAST and events[FIRST] == [dict(action='up', key='c')]
assets = {name: fidelity.sha256(ROOT / name) for name in fidelity.ASSETS}
for name, digest in assets.items():
    assert {value for path, value in capture['protected_inputs_sha256'].items() if Path(path).name == name} == {digest}


def state_from_ds(raw):
    count, visuals = raw[0x208D], raw[0xC496]
    assert count <= 30 and visuals <= 32 and raw[0x79A6] <= 32
    players = []
    for index in (1, 2):
        actor = raw[0x1B62 + index * 38:0x1B62 + (index + 1) * 38]
        visual = raw[0xC21E + actor[1] * 8:0xC226 + actor[1] * 8]
        assert len(visual) == 8
        players.append(dict(raw=actor.hex(), visual=visual.hex(), xy=list(struct.unpack_from('<HH', visual)),
            v=list(struct.unpack_from('<hh', actor, 6)), f=[actor[10], actor[12]]))
    return dict(frame=original.word(raw, 0x78C2), rng=struct.unpack_from('<I', raw, 0x1AFE)[0],
        players=players, inventory=raw[0x1B6C:0x1B78].hex(), scores=raw[0x785A:0x78B6].hex(),
        destruction=raw[0x78C6:0x78CA].hex(), actor_count=count,
        actors=raw[0x1BD4:0x1BD4 + count * 38].hex(), visuals=raw[0xC21E:0xC21E + visuals * 8].hex(),
        globals=raw[0x79A0:0x79FA].hex(), progress=raw[0x2076:0x209A].hex(),
        spawners=raw[0x74C6:0x74C6 + raw[0x79A6] * 30].hex(), tiles='', words='')


records, audits, transitions = [], [], []
last_destroyed = None
for tick in range(FIRST, LAST + 1):
    for phase in ('present', 'post_update'):
        path = CAPTURE / f'boundary-{tick}-{phase}.json'
        observed = fidelity.strict_json(path.read_text())
        raw = (CAPTURE / f'ds-{tick}-{phase}.bin').read_bytes()
        assert len(raw) == 65536 and sha(raw) == observed['ds_sha256']
        assert observed['original_observation'] and (observed['tick'], observed['phase'], observed['level']) == (tick, phase, 4)
        assert raw[0x79B7] == 4 and original.word(raw, 0x78C2) == tick - 1623
        state = state_from_ds(raw)
        atlas = original.word(raw, 0x2070)
        mapped = original.project_original(state, 1, atlas)
        del mapped['tiles_hex'], mapped['words_hex']
        mapped.update(level=4, score=int.from_bytes(raw[0x785A:0x785E], 'little'),
            p2_inventory=list(raw[0x1B70:0x1B74]) + [raw[0x1B75] - 1], red_phase=raw[0x79AD])
        projection = observed['projection']
        assert mapped == {key: value for key, value in projection['mapped'].items()
                          if key not in ('tiles_hex', 'words_hex', 'palette')}, (tick, phase, 'DS mapped')
        independent = dict(lifecycle=support.recovered.returned.native_lifecycle(state),
            monsters=support.recovered.projection.native_monsters(state, support.recovered.PROFILES[4]),
            markers=support.recovered.projection.native_markers(state),
            terrain=support.recovered.projection.native_terrain(raw))
        assert independent == {key: value for key, value in projection.items() if key != 'mapped'}, (tick, phase, 'DS tables')
        rgb = None
        if phase == 'present':
            pixels = Image.open(CAPTURE / f'original-level4-t298-{tick}-present.png').convert('RGB').tobytes()
            assert len(pixels) == 192000
            rgb = sha(pixels)
        records.append(dict(kind='boundary', section='level4', index=tick, phase=phase,
                            projection=projection, rgb_sha256=rgb))
        audits.append(dict(index=tick, phase=phase, native_sequence=observed['sequence'],
            ds_sha256=sha(raw), projection_sha256=sha(encode(projection)), rgb_sha256=rgb))
        destroyed = projection['mapped']['progress'][1]
        if phase == 'post_update' and destroyed != last_destroyed:
            transitions.append(dict(tick=tick, destroyed=destroyed))
            last_destroyed = destroyed
assert len(records) == len(audits) == 1602
baseline = {row['phase']: row['projection'] for row in support.third.fixture()[1:-1]
            if row['section'] == 'level4' and row['index'] == FIRST}
assert all(row['projection'] == baseline[row['phase']] for row in records[:2])
assert records[-1]['projection']['mapped']['progress'] == [3, 261]

FIXTURE.mkdir(exist_ok=False)
EVIDENCE.mkdir(parents=True, exist_ok=False)
(FIXTURE / 'route.txt').write_bytes(route)
header = dict(kind='header', schema='lezac-natural-level4-outside-column-v1',
    first_tick=FIRST, last_tick=LAST, frames=801, boundaries=1602, dimensions=[100, 58],
    native_frame_offset=1623, placement_tick=PLACEMENT, route_sha256=sha(route), assets=assets,
    expected_bytes_source='original_only', cpp_expectations_used=False,
    completed_levels=[1, 2, 3], entered_level=4, level4_completion_claim=False,
    initial_rng_controlled=True, normalized_control_bank_inputs=True, gameplay_state_injections=False,
    original_fidelity_claim=False, whole_game_fidelity_claim=False, all_actor_fields_compared=False,
    manual_input_claim=False, wall_clock_claim=False, audio='dummy',
    prior_original_anchor=dict(manifest_sha256=support.third.MANIFEST_SHA256, tick=FIRST),
    retained_observation_scope='projected-boundaries-and-rgb-fingerprints',
    full_ds_snapshots_published=False, heap_planes_retained_as_sha256_only=True)
footer = dict(kind='complete', frames=801, boundaries=1602, patches_restored=True)
reference = b''.join(encode(row) for row in (header, *records, footer))
(FIXTURE / 'reference.jsonl.gz').write_bytes(gzip.compress(reference, mtime=0))
audit = dict(schema='lezac-native-outside-column-ds-audit-v1', boundaries=1602,
    ds_derived_mapped_and_actor_terrain_differences=0,
    excluded_from_ds_redecode=['mapped.tiles_hex', 'mapped.words_hex', 'mapped.palette'],
    rgb_source='original_full_320x200_png', raw_ds_snapshots_published=False,
    observation_method='owned_process_stopped_for_ds_and_heap_reads', records=audits)
(EVIDENCE / 'native-audit.json.gz').write_bytes(gzip.compress(encode(audit), mtime=0))
(EVIDENCE / 'capture-report.json.gz').write_bytes(gzip.compress((CAPTURE / 'report.json').read_bytes(), mtime=0))
producers = [PRIVATE / name for name in ('capture-level4-outside-pillar-t299.py',
    'capture-level4-preportal-t299.py', 'capture-level4-continuation-t298.py', Path(__file__).name)]
producers += [ROOT / 'tools' / name for name in ('level1_original.py', 'level1_fidelity.py',
    'capture_original_level1_handoff.py', 'capture_original_level1_results.py',
    'capture_original_level1_typing.py', 'seed_original_level.py', 'frame_compare.py',
    'natural_level3_handoff.py', 'natural_campaign.py', 'natural_level3_return.py',
    'natural_level3_gate_projections.py', 'original_debris_table.py')]
producer_pins = {}
for path in producers:
    data = path.read_bytes()
    (EVIDENCE / (path.name + '.gz')).write_bytes(gzip.compress(data, mtime=0))
    producer_pins[path.name] = sha(data)
for name in ('report.json', 'byte-checks.json', 'call-690c.json'):
    path = Path('/dev/shm/lezac-level4-portal-rea-t299') / name
    (EVIDENCE / ('rea-' + name + '.gz')).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
for tick in (11300, 12100):
    shutil.copyfile(CAPTURE / f'original-level4-t298-{tick}-present.png', EVIDENCE / f'original_{tick}.png')
manifest = dict(schema='lezac-native-level4-outside-column-evidence-v1', reference_header=header,
    fixture_pins={name: fidelity.sha256(FIXTURE / name) for name in ('route.txt', 'reference.jsonl.gz')},
    native_file_pins={path.name: fidelity.sha256(path) for path in sorted(EVIDENCE.iterdir()) if path.is_file()},
    producer_pins=producer_pins, expected_bytes_source='original_only',
    native_capture_report_sha256=fidelity.sha256(CAPTURE / 'report.json'),
    original_exe_sha256=original.EXE_SHA256, original_exe_bytes=(ROOT / 'LEZAC.EXE').stat().st_size,
    native_sessions_closed=True, original_snapshot_ds_redecode_boundaries=1602,
    raw_ds_snapshot_retention='RAM-only; not claimed durably retained',
    full_guest_ram_exports=0, core_dumps=0, destruction_transitions=transitions,
    source_scope='complete projected fields and full RGB fingerprints; not all original actor bytes')
(EVIDENCE / 'manifest.json').write_bytes(encode(manifest) + b'\n')
print(json.dumps(dict(manifest_sha256=fidelity.sha256(EVIDENCE / 'manifest.json'),
    reference_bytes=(FIXTURE / 'reference.jsonl.gz').stat().st_size,
    audit_bytes=(EVIDENCE / 'native-audit.json.gz').stat().st_size,
    transitions=transitions, producer_pins=len(producer_pins)), sort_keys=True))
