"""Retain C++ mutation stimuli separately; never write original expectations."""
import gzip
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path('/mnt/c/Users/andrz/git/lezac-level4-final-demolition-20261103')
sys.path.insert(0,str(ROOT/'tools'))
import natural_level4_bridge_escape as reader

fixture,evidence=reader.FIXTURE,reader.EVIDENCE
sha=lambda data:hashlib.sha256(data).hexdigest()
reference=(fixture/'reference.jsonl.gz').read_bytes()
rows=reader.handoff.load(fixture/'reference.jsonl.gz')
wanted={(r['index'],r['phase']):r for r in rows[1:-1]}
trace=Path('/dev/shm/lezac-level4-final-t302/floor_medium_escape_up/run/trace.jsonl')
inputs=[]
with trace.open() as stream:
    for row in map(json.loads,stream):
        if row.get('phase')=='post_update' and row.get('tick') in reader.INDICES:
            reader.support.recovered.check_cpp(row['state'],wanted[row['tick'],'post_update'])
            inputs.append(dict(kind='cpp_typed_mutation_stimulus_only',index=row['tick'],
                               phase='post_update',state=row['state']))
assert [r['index'] for r in inputs]==reader.INDICES
raw=b''.join(reader.original.json_bytes(row) for row in inputs)
(fixture/'guard-inputs.jsonl.gz').write_bytes(gzip.compress(raw,compresslevel=9,mtime=0))
source=Path(__file__).read_bytes()
(evidence/(Path(__file__).name+'.gz')).write_bytes(gzip.compress(source,compresslevel=9,mtime=0))
metadata=json.loads((evidence/'manifest.json').read_bytes())
metadata['guard_input_source']=dict(kind='cpp_typed_mutation_stimulus_only',expected_bytes_source=False,
    indices=reader.INDICES,phase='post_update',cpp_trace_sha256=sha(trace.read_bytes()),
    cpp_executable_sha256='68b889bb3e54fd5ec0b0e86539fa60967c57539ec59e4434df875b4d300b8a18')
metadata['guard_producer_pins']={Path(__file__).name:sha(source)}
metadata['evidence_file_pins'][Path(__file__).name+'.gz']=sha((evidence/(Path(__file__).name+'.gz')).read_bytes())
metadata['fixture_pins']['guard-inputs.jsonl.gz']=sha((fixture/'guard-inputs.jsonl.gz').read_bytes())
(evidence/'manifest.json').write_bytes(reader.original.json_bytes(metadata))
assert (fixture/'reference.jsonl.gz').read_bytes()==reference
print(json.dumps(dict(manifest_sha256=sha((evidence/'manifest.json').read_bytes()),
    reference_unchanged=True,stimuli=len(inputs))))

