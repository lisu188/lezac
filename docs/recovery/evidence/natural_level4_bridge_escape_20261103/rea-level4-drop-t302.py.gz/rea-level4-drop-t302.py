"""Verify original drop-through gating and local-Y adjustment instructions."""
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path('/mnt/c/Users/andrz/git/lezac-level4-final-demolition-20261103')
OUT=Path('/dev/shm/lezac-level4-drop-rea-t302')
PRIVATE=Path(__file__).parent
sys.path.insert(0,'/mnt/c/Users/andrz/git/lezac-post-render-recovery-20261025/tools')
import rea_prefix_audit as audit
assert hashlib.sha256(Path(audit.__file__).read_bytes()).hexdigest()=='acf74525b08220c0d976d10509c9d6592c772437628bc8990841356746924096'
scripts=list(Path('/dev/shm/lezac-rea-npm-t301/_npx').glob('*/node_modules/rea-agents/scripts/rea.mjs'))
assert len(scripts)==1
audit.INSTRUCTIONS=(0x6967,0x6970,0x697c,0x6986,0x698d,0x699a,0x69a1,0x69b6,
                    0x6a4a,0x6a61,0x6a68,0x6a6f,0x6a76)
audit.CALLS={}
audit.run(ROOT,OUT,scripts[0],Path('/mnt/c/Tools/ghidra_12.1.4_PUBLIC'),
          Path('/home/andrz/clion-2024.3.2/jbr'))
image=(ROOT/'LEZAC.EXE').read_bytes()
assert len(image)==52384
checked=[]
for offset in audit.INSTRUCTIONS:
    value=json.loads((OUT/f'instruction-{offset:04x}.json').read_bytes())['result']['structuredContent']
    decoded=value['normalized_result']
    code=bytes.fromhex(decoded['bytes'])
    assert code==image[0x770+offset:0x770+offset+len(code)]
    checked.append(dict(offset=offset,evidence_id=value['evidence_id'],decoded=decoded,bytes_equal=True))
(OUT/'byte-checks.json').write_text(json.dumps(checked,sort_keys=True,indent=2)+'\n')
for name in ('report.json','byte-checks.json'):
    data=(OUT/name).read_bytes()
    assert len(data)<=65536
    path=PRIVATE/('level4-t302-rea-drop-'+name)
    assert not path.exists()
    path.write_bytes(data)
print(json.dumps([dict(offset=hex(row['offset']),instruction=row['decoded']['raw_disassembly']) for row in checked]))
