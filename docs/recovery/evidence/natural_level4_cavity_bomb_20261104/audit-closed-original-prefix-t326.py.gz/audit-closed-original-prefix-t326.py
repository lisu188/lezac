"""Audit the complete retained prefix of a timed-out original capture, never C++ output."""
import ast
import copy
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
from PIL import Image

PRIVATE = Path(__file__).parent
ROOT = Path('C:/Users/andrz/git/lezac-level4-left-demolition-20261103')
NATIVE = PRIVATE / 'level4-t319-native-capture'
CAPTURE_RAM = PurePosixPath('/dev/shm/lezac-native-cavity-pickup-t319')
FIRST, LAST, REQUEST_LAST = 12500, 13107, 13300
ROUTE_SHA = '6705189731170c89d5a9f353db4609c2517eb6ebf6c5ec35ff7a74ca6b604a53'
BASE = PRIVATE / 'audit-original-upper-walk-t306.py'
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def check_member(row, packed, sealed):
    assert Path(row['path']).name == row['path'] and row['path'].endswith('.gz')
    assert (len(packed), sha(packed)) == (row['encoded_bytes'], row['encoded_sha256'])
    decoded = gzip.decompress(packed)
    assert (len(decoded), sha(decoded)) == (row['source_bytes'], row['source_sha256'])
    assert row['readback_equal'] is True
    assert sealed['complete_compressed_file_byte_equal'] is sealed['gzip_decode_valid'] is True
    assert (len(packed), sha(packed)) == (sealed['compressed_bytes'], sealed['compressed_sha256'])
    assert (len(decoded), sha(decoded)) == (sealed['decoded_bytes'], sealed['decoded_sha256'])
    return decoded

def self_tests():
    raw = bytes(range(256)) * 256
    packed = gzip.compress(raw, mtime=0)
    row = dict(path='ds-control.bin.gz', encoded_bytes=len(packed), encoded_sha256=sha(packed),
        source_bytes=len(raw), source_sha256=sha(raw), readback_equal=True)
    sealed = dict(complete_compressed_file_byte_equal=True, gzip_decode_valid=True,
        compressed_bytes=len(packed), compressed_sha256=sha(packed), decoded_bytes=len(raw), decoded_sha256=sha(raw))
    assert check_member(row, packed, sealed) == raw
    controls = [('record', 'encoded_bytes', len(packed) + 1), ('record', 'encoded_sha256', '0' * 64),
        ('record', 'source_bytes', len(raw) + 1), ('record', 'source_sha256', '0' * 64),
        ('record', 'readback_equal', False), ('record', 'path', '../ds-control.bin.gz'),
        ('seal', 'compressed_sha256', '0' * 64), ('seal', 'decoded_sha256', '0' * 64),
        ('seal', 'gzip_decode_valid', False)]
    rejected = []
    for owner, key, value in controls:
        left, right = copy.deepcopy(row), copy.deepcopy(sealed)
        (left if owner == 'record' else right)[key] = value
        try:
            check_member(left, packed, right)
        except AssertionError:
            rejected.append(owner + '.' + key)
        else:
            raise AssertionError('Accepted synthetic corrupt retention metadata: ' + key)
    assert len(rejected) == 9
    return rejected

controls = self_tests()
if sys.argv[1:] == ['--self-test']:
    print(json.dumps(dict(status='passed', negative_controls_rejected=controls, guest_launched=False)), flush=True)
    raise SystemExit(0)
assert not sys.argv[1:] and sys.platform == 'win32'
sys.path.insert(0, str(ROOT / 'tools'))
import natural_level4_portal as anchor
load = lambda path: anchor.fidelity.strict_json(path.read_text())
seal_path = PRIVATE / 'level4-t319-private-partial-retention.json'
assert sha(seal_path.read_bytes()) == 'ad76678dbd3073505df0f4046c0c8879ac818ee8b3b28725aec024ae4e98b7ea'
seal = load(seal_path)
assert seal['status'] == 'private_partial_capture_retained'
assert seal['complete_retained_prefix'] == [FIRST, LAST] and seal['complete_retained_frames'] == 608
assert seal['requested_window'] == [FIRST, REQUEST_LAST] and seal['requested_window_completed'] is False
assert seal['original_private_mismatches'] == seal['invalid_gzip_members_preserved'] == []
assert seal['recovered_missing_or_different_private_members'] == [] and seal['public_raw_snapshot_upload'] is False
assert sha((NATIVE / 'report.json').read_bytes()) == seal['report_sha256'] == 'e65c725ced6015a6ee60cfa67300b16021d9d46df8535e3d5c8bd4d1a1ecd265'
capture = load(NATIVE / 'report.json')
assert capture['error'] == "TimeoutError('Bounded original capture interrupted or deadline reached')"
assert capture['private_snapshot_backup'] is True and capture['public_raw_snapshot_upload'] is False
assert capture['observer_sha256'] == 'b1c10b0cf8648363694c8fed619cd640e8573ac9033768dbf741b044c488af38'
assert capture['storage_base_sha256'] == 'a32279bfcdff6dce8b80f6d7a1e87c945ccff04f42a540ec4d3d7f923445b182'
assert sha((NATIVE / 'capture-storage-base.py').read_bytes()) == capture['storage_base_sha256']
assert sha((NATIVE / 'continuation-base.py').read_bytes()) == '3070fded56c191eb5214c4cc2a6a91183941236f028e65681a26a38226ad3ee5'
assert sha((NATIVE / 'host-bound-base.py').read_bytes()) == 'e3313f7b33af62ebbd15fd174a60f3ad775bb5a918b1df26484c0354ee74629a'
launch = load(NATIVE / 'launch-receipt.json')
assert launch['observer_sha256'] == capture['observer_sha256'] and launch['maximum_seconds'] == 1800
assert launch['source_transforms'] == dict(retained=1, snapshots=2, png=1, host=1, summaries=1)
assert launch['candidate_archive_sha256'] == capture['candidate_archive_sha256'] == '547d1d542f25c1ba84489ca7dafac3c89d95f955483e8ef7407c5f4e640d03ec'
assert capture['previous_original_anchor_tick'] == FIRST
prior_reference = NATIVE / 'verified-prefix-reference.jsonl.gz'
assert sha(prior_reference.read_bytes()) == capture['previous_original_reference_sha256'] == 'aba3d8abab91a1b874896991edd992f983a591527396561974cf2d0d439841a1'
old_rows = [anchor.fidelity.strict_json(line.decode()) for line in gzip.decompress(prior_reference.read_bytes()).splitlines()]
old_anchor = [row for row in old_rows if row.get('index') == FIRST]
assert [row['phase'] for row in old_anchor] == ['present', 'post_update']
for row in old_anchor:
    observed = anchor.fidelity.strict_json(gzip.decompress((NATIVE / f"boundary-{FIRST}-{row['phase']}.json.gz").read_bytes()).decode())
    assert observed['projection'] == row['projection'] and observed['known_prefix_compared'] is True
    if row['phase'] == 'present':
        pixels = Image.open(NATIVE / f'original-level4-t298-{FIRST}-present.png').convert('RGB').tobytes()
        assert sha(pixels) == row['rgb_sha256']
assert sha((PRIVATE / 'level4-t313-native-capture/route.txt').read_bytes()) == 'd59bc17eae69a25bbf1b4793c7ae1a2092627cb5ed29ed2e418dffb6e83391b9'
rea_path = PRIVATE / 'level4-t316-rea-pickup-report.json'
assert sha(rea_path.read_bytes()) == '1606f6f8d345210cf1c25bd9a9ba331e1980cf330cf3b6f9b61eaff0f2b9951f'
rea = load(rea_path)
assert rea['status'] == 'completed' and rea['session_closed'] is True and rea['server_exit_code'] == 0
assert rea['target_preserved'] is True and rea['guest_execution'] is False
assert rea['provider']['id'] == 'ghidra' and rea['provider']['version'] == '12.1.4'
binary = (ROOT / 'LEZAC.EXE').read_bytes()
assert len(binary) == 52384 and sha(binary) == rea['target_sha256']
instructions_path = PRIVATE / 'level4-t316-rea-pickup-byte-checks.json'
assert sha(instructions_path.read_bytes()) == '8e167ea3b64e526b8fd505e249025ec2faf15c12491656c7afeeef4154ee1f60'
instructions = load(instructions_path)
assert len(instructions) == 39
for row in instructions:
    code = bytes.fromhex(row['decoded']['bytes'])
    assert row['bytes_equal'] is True and code == binary[0x770 + row['offset']:0x770 + row['offset'] + len(code)]
raw = BASE.read_bytes()
assert sha(raw) == 'b60280558774d12455d82f236bdd2969fca4ebe1fe0a9c99d6af0e58e3775a08'
counts = dict(root=0, native=0, window=0, route=0, baseline=0, capture_status=0,
    requested_window=0, request_ticks=0, storage=0, argv=0, png=0, member_loop=0, labels=0, audit_status=0, header=0)
class NativePath(ast.NodeTransformer):
    def visit_Name(self, node):
        return ast.copy_location(ast.Name(id='CAPTURE_RAM', ctx=node.ctx), node) if node.id == 'NATIVE' else node
class Configure(ast.NodeTransformer):
    def visit_Assign(self, node):
        if len(node.targets) == 1:
            name = ast.unparse(node.targets[0])
            values = {'ROOT': ('root', f'Path({str(ROOT)!r})'), 'NATIVE': ('native', f'Path({str(NATIVE)!r})'),
                '(FIRST, LAST)': ('window', repr((FIRST, LAST))), 'ROUTE_SHA': ('route', repr(ROUTE_SHA)),
                '(anchor_settings, anchor_events)': ('baseline', "prior.fidelity.read_route(PRIVATE / 'level4-t313-native-capture/route.txt')")}
            if name in values:
                key, value = values[name]
                node.value = ast.parse(value, mode='eval').body
                counts[key] += 1
            if name == 'header':
                counts['header'] += 1
                return [self.generic_visit(node), ast.parse(
                    "header.update(capture_status='incomplete', capture_requested_window=[12500,13300], "
                    "capture_request_complete=False, observed_complete_window=[12500,13107], "
                    "closed_original_prefix_only=True, original_source_capture=str(CAPTURE_RAM))").body[0]]
        return self.generic_visit(node)
    def visit_Assert(self, node):
        text = ast.unparse(node.test)
        if "binding['argv']" in text:
            counts['argv'] += 1
            return NativePath().visit(node)
        if text == "(capture['first_full_frame_tick'], capture['last_full_frame_tick']) == (FIRST, LAST)":
            counts['requested_window'] += 1
            return ast.copy_location(ast.parse("assert (capture['first_full_frame_tick'], capture['last_full_frame_tick']) == (12500,13300)").body[0], node)
        if text == "settings == {**anchor_settings, 'ticks': LAST}":
            counts['request_ticks'] += 1
            return ast.copy_location(ast.parse("assert settings == {**anchor_settings, 'ticks': 13300}").body[0], node)
        return self.generic_visit(node)
    def visit_Compare(self, node):
        if ast.unparse(node.left) == "receipt['png']" and len(node.comparators) == 1 and ast.unparse(node.comparators[0]) == 'str(path)':
            node.comparators[0] = ast.parse('str(CAPTURE_RAM / path.name)', mode='eval').body
            counts['png'] += 1
        return self.generic_visit(node)
    def visit_For(self, node):
        if isinstance(node.target, ast.Name) and node.target.id == 'row' and isinstance(node.iter, ast.Name) and node.iter.id == 'records':
            counts['member_loop'] += 1
            node.body = ast.parse("path = NATIVE / row['path']\nassert path.parent == NATIVE and not path.is_symlink()\ncheck_member(row, path.read_bytes(), seal['members'][row['path']])").body
        return self.generic_visit(node)
    def visit_Constant(self, node):
        if node.value == 'original_continuation_observed':
            counts['capture_status'] += 1
            return ast.copy_location(ast.Constant('incomplete'), node)
        if node.value == 'original_only_audit_passed':
            counts['audit_status'] += 1
            return ast.copy_location(ast.Constant('original_only_closed_prefix_audit_passed'), node)
        if node.value == 'lossless-gzip RAM-only; not claimed durably retained':
            counts['storage'] += 1
            return ast.copy_location(ast.Constant('lossless-gzip RAM plus private compressed backups; no public raw snapshots'), node)
        if isinstance(node.value, str):
            changed = node.value.replace('level4-t306-upper-walk-', 'level4-t326-closed-prefix-').replace(
                'level4-t306-original-upper-walk-', 'level4-t326-original-closed-prefix-')
            if changed != node.value:
                counts['labels'] += 1
                return ast.copy_location(ast.Constant(changed), node)
        return node

tree = Configure().visit(ast.parse(raw.decode(), filename=str(BASE)))
assert counts == dict(root=1, native=1, window=1, route=1, baseline=1, capture_status=1,
    requested_window=1, request_ticks=1, storage=1, argv=1, png=1, member_loop=1, labels=4, audit_status=1, header=1), counts
ast.fix_missing_locations(tree)
exec(compile(tree, str(BASE), 'exec'), {'__name__': '__main__', '__file__': str(Path(__file__)),
    'CAPTURE_RAM': CAPTURE_RAM, 'check_member': check_member, 'seal': seal})
destination = PRIVATE / 'level4-t326-closed-prefix-original-audit.json'
report = load(destination)
assert (report['frames'], report['boundaries'], report['compressed_members']) == (608, 1216, 2444)
report.update(capture_status='incomplete', capture_requested_window=[FIRST, REQUEST_LAST], capture_request_complete=False,
    observed_complete_window=[FIRST, LAST], closed_original_prefix_only=True,
    prefix_repeat_boundaries=2, prefix_repeat_differences=0, private_snapshot_backup=True,
    public_raw_snapshot_upload=False, retention_seal_sha256=sha(seal_path.read_bytes()),
    retained_member_negative_controls_rejected=controls, capture_producer_sha256=capture['observer_sha256'],
    audit_producer_sha256=sha(Path(__file__).read_bytes()), audit_base_sha256=sha(raw),
    rea_report_sha256=sha(rea_path.read_bytes()), rea_bytechecks_sha256=sha(instructions_path.read_bytes()))
destination.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'records'}), flush=True)
