"""Audit the full original-only approach, throw, escape and collapse window."""
import ast
import hashlib
import json
from pathlib import Path
import sys

SOURCE = Path(__file__).with_name('audit-original-pickup-t329.py')
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'ab4d587a0915afd613ae548f958070938926315d2dd10147361f02a6387d6929'
integers = {13107: 13700, 13300: 14700, 194: 1001, 388: 2002, 788: 4016, 1800: 2400}
strings = {
    '6705189731170c89d5a9f353db4609c2517eb6ebf6c5ec35ff7a74ca6b604a53':
        'a58a48cd67942a1ba49323cb7f65394acff1d9b0a5ef8928cc398db2375cbc2b',
    'd7d27ea29bc0afebec1e0840de74c334a0810c883e004f5e3bbc64d55e4955d0':
        '582739d3d1e049e02e37e9d5a5e586f5a5346058655c4cbb2991b1a95429bc96',
    '1edf3726ad19fce9141cef993271cec9e5f13d2becbe027b4bac0ad6f607d724':
        'dd7b7782cdfe7a0e20fac25878b34cc1efa080412a9249f36df999488dc8f344',
    '3ce6cfb739a07ff8a813ccb54b89635a2d583ea18705039437c6507e6fe74712':
        '53ff70a488bc3d2f42e19e5aac747b5b0005497b10567b7c1e8e078588db7384',
    '7f5bcf8ae4d526effbddf5c31543118cc2121c6bc0e9af9219ce8ffda6161400':
        'f37a3cb76b2f44013fe36686cee60966114dface40f6cae9f44ae09416c5448e',
    '547d1d542f25c1ba84489ca7dafac3c89d95f955483e8ef7407c5f4e640d03ec':
        'd7dbd11d9e30a14ab3497e1675e382e5bc128854d84272493421eacbf79e7ff4',
    'level4-t326-closed-prefix-original-audit.json': 'level4-t339-support-wait-original-audit.json',
    'capture-pickup-overlap-t327.py': 'capture-first-cavity-blast-t343.py',
}
seen_integers, seen_strings, labels, configurations = set(), set(), 0, 0
class Configure(ast.NodeTransformer):
    def visit_Assert(self, node):
        global configurations
        if "launch['configuration_transforms']" in ast.unparse(node.test):
            calls = [part for part in ast.walk(node.test) if isinstance(part, ast.Call)
                and isinstance(part.func, ast.Name) and part.func.id == 'dict']
            assert len(calls) == 1
            calls[0].keywords.extend([ast.keyword(arg='deadline', value=ast.Constant(2)),
                ast.keyword(arg='batch_policy', value=ast.Constant(1))])
            configurations += 1
        return self.generic_visit(node)

    def visit_Constant(self, node):
        global labels
        if type(node.value) is int and node.value in integers:
            seen_integers.add(node.value)
            return ast.copy_location(ast.Constant(integers[node.value]), node)
        if isinstance(node.value, str):
            if node.value in strings:
                seen_strings.add(node.value)
                return ast.copy_location(ast.Constant(strings[node.value]), node)
            value = node.value.replace('level4-t327-input/verified-prefix-route.txt',
                'level4-t341-native-capture/route.txt').replace('level4-t327-', 'level4-t343-').replace(
                'lezac-native-pickup-overlap-t327', 'lezac-native-first-cavity-blast-t343').replace(
                'level4-t329-pickup-', 'level4-t344-first-blast-').replace(
                'level4-t329-original-pickup-', 'level4-t344-original-first-blast-').replace(
                '[13107,13300]', '[13700,14700]')
            if value != node.value:
                labels += 1
                return ast.copy_location(ast.Constant(value), node)
        return node

tree = Configure().visit(ast.parse(raw.decode(), filename=str(SOURCE)))
assert seen_integers == set(integers) and seen_strings == set(strings), (seen_integers, seen_strings)
assert labels > 0 and configurations == 1
ast.fix_missing_locations(tree)
if sys.argv[1:] != ['--self-test']:
    private = SOURCE.parent
    receipt = json.loads((private / 'level4-t343-replace-capture-receipt.json').read_bytes())
    assert receipt['status'] == 'completed' and receipt['process_replace_hook_restored'] is True
    assert receipt['maximum_seconds'] == 2400 and receipt['cumulative_report_batch_interval'] == 25
    assert receipt['snapshot_backups_individually_flushed'] is receipt['full_readback_requirements_unchanged'] is True
    assert receipt['public_upload'] is False
    helper = private / 'private_replace_t341.py'
    assert receipt['helper_sha256'] == hashlib.sha256(helper.read_bytes()).hexdigest() == \
        '9128f4864daf44adf2d525cca4c4fa70462ba17a9bb62b732e815432d766190a'
    control = private / 'level4-t341-sharing-control/result.json'
    assert receipt['actual_sharing_control_sha256'] == hashlib.sha256(control.read_bytes()).hexdigest()
    assert json.loads(control.read_bytes())['actual_windows_sharing_denial'] is True
    batching = private / 'level4-t343-batch-controls/result.json'
    assert receipt['batch_control_sha256'] == hashlib.sha256(batching.read_bytes()).hexdigest()
    batch = json.loads(batching.read_bytes())
    assert batch['status'] == 'passed' and len(batch['controls']) == 8
    assert batch['observer_sha256'] == receipt['observer_sha256']
    assert batch['snapshot_and_boundary_backup_frequency_unchanged'] is True
exec(compile(tree, str(SOURCE), 'exec'), {'__name__': '__main__', '__file__': str(Path(__file__))})
