"""Audit a completed overlapping original pickup capture without C++ expectations."""
import ast
import copy
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
from PIL import Image

PRIVATE = Path(__file__).parent
ROOT = Path('C:/Users/andrz/git/lezac-level4-left-demolition-20261103')
NATIVE = PRIVATE / 'level4-t327-native-capture'
RAM = Path('//wsl.localhost/Ubuntu/dev/shm/lezac-native-pickup-overlap-t327')
CAPTURE_RAM = PurePosixPath('/dev/shm/lezac-native-pickup-overlap-t327')
FIRST, LAST, FRAMES = 13107, 13300, 194
ROUTE_SHA = '6705189731170c89d5a9f353db4609c2517eb6ebf6c5ec35ff7a74ca6b604a53'
BASE = PRIVATE / 'audit-original-upper-walk-t306.py'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
helper = PRIVATE / 'audit-closed-original-prefix-t326.py'
helper_raw = helper.read_bytes()
assert sha(helper_raw) == 'c3d7ddc37720d6a0bbde9115baac3b2edd65958b69257c935b7b95e83779b791'
functions = [node for node in ast.parse(helper_raw.decode()).body if isinstance(node, ast.FunctionDef)
    and node.name in ('check_member', 'self_tests')]
assert len(functions) == 2
helper_namespace = dict(Path=Path, copy=copy, gzip=gzip, sha=sha)
exec(compile(ast.Module(body=functions, type_ignores=[]), str(helper), 'exec'), helper_namespace)
check_member = helper_namespace['check_member']
controls = helper_namespace['self_tests']()
if sys.argv[1:] == ['--self-test']:
    print(json.dumps(dict(status='passed', negative_controls_rejected=controls, guest_launched=False)), flush=True)
    raise SystemExit(0)
assert not sys.argv[1:] and sys.platform == 'win32'
sys.path.insert(0, str(ROOT / 'tools'))
import natural_level4_portal as anchor
load = lambda path: anchor.fidelity.strict_json(path.read_text())
capture = load(NATIVE / 'report.json')
assert capture['status'] == 'original_continuation_observed' and capture['owned_child_terminal'] is True
assert capture['private_snapshot_backup'] is True and capture['public_raw_snapshot_upload'] is False
assert capture['observer_sha256'] == sha((NATIVE / 'observer.py').read_bytes()) == \
    sha((PRIVATE / 'capture-pickup-overlap-t327.py').read_bytes()) == '1edf3726ad19fce9141cef993271cec9e5f13d2becbe027b4bac0ad6f607d724'
assert capture['storage_base_sha256'] == sha((NATIVE / 'capture-storage-base.py').read_bytes()) == \
    'a32279bfcdff6dce8b80f6d7a1e87c945ccff04f42a540ec4d3d7f923445b182'
assert sha((NATIVE / 'continuation-base.py').read_bytes()) == '3070fded56c191eb5214c4cc2a6a91183941236f028e65681a26a38226ad3ee5'
assert sha((NATIVE / 'host-bound-base.py').read_bytes()) == 'e3313f7b33af62ebbd15fd174a60f3ad775bb5a918b1df26484c0354ee74629a'
launch = load(NATIVE / 'launch-receipt.json')
assert launch['observer_sha256'] == capture['observer_sha256'] and launch['maximum_seconds'] == 1800
assert launch['source_transforms'] == dict(retained=1, snapshots=2, png=1, host=1, summaries=1)
assert launch['configuration_transforms'] == capture['configuration_transforms'] == dict(constants=7,
    prefix_limit=1, route=1, window=1, baseline=1, reference=1, protected=1, receipt=1,
    report=1, storage_source=1, immutable_readback=1)
assert launch['candidate_archive_sha256'] == capture['candidate_archive_sha256'] == '547d1d542f25c1ba84489ca7dafac3c89d95f955483e8ef7407c5f4e640d03ec'
assert launch['route_input_source'] == capture['route_input_source'] == 'C++ route planning stimulus only; no C++ state expectations'
assert launch['public_raw_snapshot_upload'] is False
assert capture['previous_original_anchor_tick'] == FIRST
assert sha((PRIVATE / 'level4-t327-input/verified-prefix-route.txt').read_bytes()) == \
    'd7d27ea29bc0afebec1e0840de74c334a0810c883e004f5e3bbc64d55e4955d0'
prepared = load(PRIVATE / 'level4-t327-storage-prepare/report.json')
assert prepared['status'] == 'prepared_no_guest' and prepared['guest_launched'] is False
assert prepared['observer_sha256'] == capture['observer_sha256']
mirror = load(NATIVE / 'mirror-control-tests.json')
assert mirror['status'] == 'passed' and mirror['tests'] == 6 and mirror['guest_launched'] is False
assert mirror['observer_sha256'] == capture['observer_sha256']
assert sha((NATIVE / 'mirror-control-tests.json').read_bytes()) == capture['mirror_control_sha256'] == launch['mirror_control_sha256']
synthetic = load(NATIVE / 'storage-controls.json')
assert len(synthetic) == 6
for name, value in synthetic.items():
    assert name.startswith('synthetic-') and value['kind'] == 'synthetic_codec_preflight' and value['readback_equal'] is True
    packed = (NATIVE / (name + '.gz')).read_bytes()
    decoded = gzip.decompress(packed)
    assert (len(packed), sha(packed)) == (value['encoded_bytes'], value['encoded_sha256'])
    assert (len(decoded), sha(decoded)) == (value['source_bytes'], value['source_sha256'])
prior_reference = NATIVE / 'verified-prefix-reference.jsonl.gz'
assert sha(prior_reference.read_bytes()) == capture['previous_original_reference_sha256'] == \
    '3ce6cfb739a07ff8a813ccb54b89635a2d583ea18705039437c6507e6fe74712'
prior_audit = PRIVATE / 'level4-t326-closed-prefix-original-audit.json'
assert sha(prior_audit.read_bytes()) == '7f5bcf8ae4d526effbddf5c31543118cc2121c6bc0e9af9219ce8ffda6161400'
assert load(prior_audit)['cpp_expectations_used'] is False
old = [anchor.fidelity.strict_json(line.decode()) for line in gzip.decompress(prior_reference.read_bytes()).splitlines()]
expected = [row for row in old if row.get('index') == FIRST]
assert [row['phase'] for row in expected] == ['present', 'post_update']
for row in expected:
    observed = anchor.fidelity.strict_json(gzip.decompress((NATIVE / f"boundary-{FIRST}-{row['phase']}.json.gz").read_bytes()).decode())
    assert observed['projection'] == row['projection'] and observed['known_prefix_compared'] is True
    if row['phase'] == 'present':
        pixels = Image.open(NATIVE / f'original-level4-t298-{FIRST}-present.png').convert('RGB').tobytes()
        assert sha(pixels) == row['rgb_sha256']
assert (RAM / 'report.json').read_bytes() == (NATIVE / 'report.json').read_bytes()
assert (RAM / 'lossless-retention.jsonl').read_bytes() == (NATIVE / 'lossless-retention.jsonl').read_bytes()
records = [anchor.fidelity.strict_json(line) for line in (NATIVE / 'lossless-retention.jsonl').read_text().splitlines()]
assert len(records) == len({row['path'] for row in records}) == 788
sealed_members = {}
compressed_bytes = decoded_bytes = 0
for row in records:
    name = row['path']
    assert Path(name).name == name and not (NATIVE / name).is_symlink() and not (RAM / name).is_symlink()
    packed, volatile = (NATIVE / name).read_bytes(), (RAM / name).read_bytes()
    assert packed == volatile
    decoded = gzip.decompress(volatile)
    sealed_members[name] = dict(complete_compressed_file_byte_equal=True, gzip_decode_valid=True,
        compressed_bytes=len(volatile), compressed_sha256=sha(volatile), decoded_bytes=len(decoded), decoded_sha256=sha(decoded))
    check_member(row, packed, sealed_members[name])
    compressed_bytes += len(packed)
    decoded_bytes += len(decoded)
raw = BASE.read_bytes()
assert sha(raw) == 'b60280558774d12455d82f236bdd2969fca4ebe1fe0a9c99d6af0e58e3775a08'
counts = dict(root=0, native=0, window=0, route=0, baseline=0, storage=0, argv=0, png=0, member_loop=0, labels=0, header=0)
class NativePath(ast.NodeTransformer):
    def visit_Name(self, node):
        return ast.copy_location(ast.Name(id='CAPTURE_RAM', ctx=node.ctx), node) if node.id == 'NATIVE' else node
class Configure(ast.NodeTransformer):
    def visit_Assign(self, node):
        if len(node.targets) == 1:
            name = ast.unparse(node.targets[0])
            values = {'ROOT': ('root', f'Path({str(ROOT)!r})'), 'NATIVE': ('native', f'Path({str(NATIVE)!r})'),
                '(FIRST, LAST)': ('window', repr((FIRST, LAST))), 'ROUTE_SHA': ('route', repr(ROUTE_SHA)),
                '(anchor_settings, anchor_events)': ('baseline', "prior.fidelity.read_route(PRIVATE / 'level4-t327-input/verified-prefix-route.txt')")}
            if name in values:
                key, value = values[name]
                node.value = ast.parse(value, mode='eval').body
                counts[key] += 1
            if name == 'header':
                counts['header'] += 1
                return [self.generic_visit(node), ast.parse(
                    "header.update(capture_request_complete=True, capture_requested_window=[13107,13300], "
                    "observed_complete_window=[13107,13300], original_source_capture=str(CAPTURE_RAM))").body[0]]
        return self.generic_visit(node)
    def visit_Assert(self, node):
        if "binding['argv']" in ast.unparse(node.test):
            counts['argv'] += 1
            return NativePath().visit(node)
        return self.generic_visit(node)
    def visit_Compare(self, node):
        if ast.unparse(node.left) == "receipt['png']" and len(node.comparators) == 1 and ast.unparse(node.comparators[0]) == 'str(path)':
            node.comparators[0] = ast.parse('str(CAPTURE_RAM / path.name)', mode='eval').body
            counts['png'] += 1
        return self.generic_visit(node)
    def visit_For(self, node):
        if isinstance(node.target, ast.Name) and node.target.id == 'row' and isinstance(node.iter, ast.Name) and node.iter.id == 'records':
            counts['member_loop'] += 1
            node.body = ast.parse("path = NATIVE / row['path']\nassert path.parent == NATIVE and not path.is_symlink()\ncheck_member(row, path.read_bytes(), sealed_members[row['path']])").body
        return self.generic_visit(node)
    def visit_Constant(self, node):
        if node.value == 'lossless-gzip RAM-only; not claimed durably retained':
            counts['storage'] += 1
            return ast.copy_location(ast.Constant('lossless-gzip RAM plus private compressed backups; no public raw snapshots'), node)
        if isinstance(node.value, str):
            changed = node.value.replace('level4-t306-upper-walk-', 'level4-t329-pickup-').replace(
                'level4-t306-original-upper-walk-', 'level4-t329-original-pickup-')
            if changed != node.value:
                counts['labels'] += 1
                return ast.copy_location(ast.Constant(changed), node)
        return node

tree = Configure().visit(ast.parse(raw.decode(), filename=str(BASE)))
assert counts == dict(root=1, native=1, window=1, route=1, baseline=1, storage=1, argv=1,
    png=1, member_loop=1, labels=4, header=1), counts
ast.fix_missing_locations(tree)
exec(compile(tree, str(BASE), 'exec'), {'__name__': '__main__', '__file__': str(Path(__file__)),
    'CAPTURE_RAM': CAPTURE_RAM, 'check_member': check_member, 'sealed_members': sealed_members})
destination = PRIVATE / 'level4-t329-pickup-original-audit.json'
report = load(destination)
assert (report['frames'], report['boundaries'], report['compressed_members']) == (194, 388, 788)
report.update(capture_request_complete=True, capture_requested_window=[FIRST, LAST],
    observed_complete_window=[FIRST, LAST], prefix_repeat_boundaries=2, prefix_repeat_differences=0,
    private_snapshot_backup=True, public_raw_snapshot_upload=False, full_private_member_byte_differences=0,
    compressed_bytes=compressed_bytes, decoded_bytes=decoded_bytes,
    retained_member_negative_controls_rejected=controls, capture_producer_sha256=capture['observer_sha256'],
    audit_producer_sha256=sha(Path(__file__).read_bytes()), audit_base_sha256=sha(raw),
    retained_member_helper_sha256=sha(helper_raw), prior_anchor_audit_sha256=sha(prior_audit.read_bytes()))
destination.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key not in ('records', 'final')}, sort_keys=True), flush=True)
