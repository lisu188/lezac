"""Audit original-only observations and retain a compact reference, never reading C++ output."""
import ast
import gzip
import hashlib
import json
from pathlib import Path
import struct
import sys
import zipfile
from PIL import Image

PRIVATE = Path(__file__).parent
ROOT = Path('/mnt/c/Users/andrz/git/lezac-level4-left-demolition-20261103')
NATIVE = Path('/dev/shm/lezac-native-upper-walk-t306')
FIRST, LAST = 10634, 11000
FRAMES = LAST - FIRST + 1
ROUTE_SHA = '6e636846b908ec7655ed6ecabc0cb96be39945f3448a74297bc23e65285f5909'
sys.path.insert(0, str(ROOT / 'tools'))
import natural_level4_bridge_access as prior
import natural_level4_portal as anchor
from original_capture_contract import ASSET_PINS, read_canonical_assets

sha = lambda raw: hashlib.sha256(raw).hexdigest()
load = lambda name: prior.fidelity.strict_json((NATIVE / name).read_text())
capture, binding = load('report.json'), load('host-binding.json')
assert capture['status'] == 'original_continuation_observed'
assert all(capture[key] is True for key in ('base_hooks_restored', 'extra_hooks_restored', 'owned_child_terminal',
    'protected_inputs_preserved', 'initial_rng_controlled', 'normalized_control_bank_inputs', 'ordinary_gameplay_inputs_only'))
assert all(capture[key] == 0 for key in ('gameplay_state_injections', 'full_guest_ram_exports', 'core_dumps',
    'manual_input_claim', 'wall_clock_claim', 'whole_game_fidelity_claim', 'full_frame_claim'))
assert (capture['first_full_frame_tick'], capture['last_full_frame_tick']) == (FIRST, LAST)
assert capture['route_sha256'] == sha((NATIVE / 'route.txt').read_bytes()) == ROUTE_SHA
assert capture['original_exe_sha256'] == prior.original.EXE_SHA256
assert capture['snapshot_storage'] == 'lossless-gzip RAM-only; not claimed durably retained'
assert capture['observer_sha256'] == binding['observer_sha256'] == sha((NATIVE / 'observer.py').read_bytes())
assert binding['host'] == prior.prior.HOST_PIN and binding['actual_host_sha256'] == prior.prior.HOST_PIN['sha256']
assert binding['argv'] == ['dosbox', '-conf', str(NATIVE / 'dosbox.conf'), '-c', 'mount c ' + str(NATIVE / 'runtime'),
    '-c', 'c:', '-c', 'L1ORACLE.COM', '-c', 'LEZAC.EXE']
assert binding['cwd'] == '/dev/shm' and binding['actual_pid'] > 0
assert binding['config_sha256'] == sha((NATIVE / 'dosbox.conf').read_bytes())
assert binding['loader_sha256'] == sha(prior.original.resident_program())
assets = {name: dict(bytes=size, sha256=digest) for name, (size, digest) in ASSET_PINS.items()}
read_canonical_assets(ROOT)
assert binding['canonical_source_assets'] == assets
assert binding['copied_assets'] == {name: value for name, value in assets.items() if name != 'SETUP.LOG'}
assert binding['environment']['SDL_AUDIODRIVER'] == 'dummy' and binding['whole_game_fidelity_claim'] is False
assert all(binding['environment'][key].startswith('/dev/shm/') for key in ('TMPDIR', 'TMP', 'TEMP'))
assert [int(binding['geometry'][key]) for key in ('WIDTH', 'HEIGHT', 'SCREEN')] == [320, 200, 0]
assert [(row['from_level'], row['to_level'], row['intro_frame'], row['intro_rng']) for row in capture['handoffs']] == [
    (1, 2, 305, 2497022769), (2, 3, 2669, 3666694644), (3, 4, 7798, 1603369198)]
settings, events = prior.fidelity.read_route(NATIVE / 'route.txt')
anchor_settings, anchor_events = anchor.check_route(anchor.FIXTURE / 'route.txt')
assert settings == {**anchor_settings, 'ticks': LAST}
assert {tick: rows for tick, rows in events.items() if tick <= FIRST} == {
    tick: rows for tick, rows in anchor_events.items() if tick <= FIRST}
live = {(row['tick'], row['phase']): row for row in capture['checkpoints']}
assert len(live) == len(capture['checkpoints']) == FRAMES * 2 + 6
records = [prior.fidelity.strict_json(line) for line in (NATIVE / 'lossless-retention.jsonl').read_text().splitlines()]
assert len(records) == len(live) * 2
assert len({row['path'] for row in records}) == len(records)
assert {row['path'] for row in records} == {f'{prefix}-{tick}-{phase}.{suffix}.gz' for tick, phase in live
    for prefix, suffix in (('boundary', 'json'), ('ds', 'bin'))}
for row in records:
    path = NATIVE / row['path']
    assert path.parent == NATIVE and not path.is_symlink()
    encoded = path.read_bytes()
    raw = gzip.decompress(encoded)
    assert (len(encoded), sha(encoded)) == (row['encoded_bytes'], row['encoded_sha256'])
    assert (len(raw), sha(raw)) == (row['source_bytes'], row['source_sha256']) and row['readback_equal'] is True
decoder = gzip.decompress((prior.EVIDENCE / 'frozen-ds-decoder.py.gz').read_bytes())
assert sha(decoder) == prior.manifest()['producer_pins']['frozen-ds-decoder.py']
functions = [node for node in ast.parse(decoder.decode()).body if isinstance(node, ast.FunctionDef) and node.name == 'state_from_ds']
assert len(functions) == 1
namespace = dict(original=prior.original, struct=struct)
exec(compile(ast.Module(body=functions, type_ignores=[]), 'frozen-original-ds-decoder', 'exec'), namespace)
header = dict(kind='header', first_tick=FIRST, last_tick=LAST, frames=FRAMES, boundaries=FRAMES * 2,
    expected_bytes_source='original_only', cpp_expectations_used=False, source_capture=str(NATIVE),
    route_sha256=ROUTE_SHA, original_exe_sha256=prior.original.EXE_SHA256, initial_rng_controlled=True,
    normalized_control_bank_inputs=True, gameplay_state_injections=False, raw_ds_snapshots_published=False,
    full_frame_claim=False, whole_game_fidelity_claim=False)
rows, audit = [header], []
for tick in range(FIRST, LAST + 1):
    for phase in ('present', 'post_update'):
        observed = prior.fidelity.strict_json(gzip.decompress((NATIVE / f'boundary-{tick}-{phase}.json.gz').read_bytes()).decode())
        raw = gzip.decompress((NATIVE / f'ds-{tick}-{phase}.bin.gz').read_bytes())
        receipt = live[tick, phase]
        assert len(raw) == 65536 and sha(raw) == observed['ds_sha256'] == receipt['ds_sha256']
        assert observed['original_observation'] is receipt['original_observation'] is True
        assert observed['sequence'] == receipt['sequence']
        state = namespace['state_from_ds'](raw)
        mapped = prior.original.project_original(state, 1, prior.original.word(raw, 0x2070))
        del mapped['tiles_hex'], mapped['words_hex']
        mapped.update(level=4, score=int.from_bytes(raw[0x785a:0x785e], 'little'),
            p2_inventory=list(raw[0x1b70:0x1b74]) + [raw[0x1b75] - 1], red_phase=raw[0x79ad])
        projection = observed['projection']
        assert mapped == {key: value for key, value in projection['mapped'].items() if key not in ('tiles_hex', 'words_hex', 'palette')}
        recovered = prior.support.recovered
        independent = dict(lifecycle=recovered.returned.native_lifecycle(state),
            monsters=recovered.projection.native_monsters(state, recovered.PROFILES[4]),
            markers=recovered.projection.native_markers(state), terrain=recovered.projection.native_terrain(raw))
        assert independent == {key: value for key, value in projection.items() if key != 'mapped'}
        assert receipt['mapped'] == {key: projection['mapped'][key] for key in ('frame', 'rng', 'progress', 'players')}
        assert projection['mapped']['frame'] == tick - 1623
        rgb = None
        if phase == 'present':
            path = NATIVE / f'original-level4-t298-{tick}-present.png'
            pixels = Image.open(path).convert('RGB').tobytes()
            assert len(pixels) == 192000 and sha(pixels) == receipt['rgb_sha256']
            assert sha(path.read_bytes()) == receipt['png_sha256'] and receipt['png'] == str(path)
            rgb = sha(pixels)
        rows.append(dict(kind='boundary', section='level4', index=tick, phase=phase, projection=projection, rgb_sha256=rgb))
        audit.append(dict(tick=tick, phase=phase, sequence=observed['sequence'], ds_sha256=sha(raw),
            projection_sha256=sha(prior.original.json_bytes(projection)), rgb_sha256=rgb))
rows.append(dict(kind='complete', frames=FRAMES, boundaries=FRAMES * 2, patches_restored=True))
reference = PRIVATE / 'level4-t306-upper-walk-original-reference.jsonl.gz'
assert not reference.exists()
payload = b''.join(prior.original.json_bytes(row) for row in rows)
reference.write_bytes(gzip.compress(payload, compresslevel=9, mtime=0))
assert gzip.decompress(reference.read_bytes()) == payload
report = dict(status='original_only_audit_passed', frames=FRAMES, boundaries=len(audit),
    independent_ds_redecode_differences=0, compressed_members=len(records), compressed_member_readback_differences=0,
    excluded_from_ds_redecode=['mapped.tiles_hex', 'mapped.words_hex', 'mapped.palette'],
    original_png_receipt_differences=0, reference_sha256=sha(reference.read_bytes()),
    capture_report_sha256=sha((NATIVE / 'report.json').read_bytes()), records=audit,
    expected_bytes_source='original_only', cpp_expectations_used=False, final=rows[-2]['projection']['mapped'],
    full_frame_claim=False, whole_game_fidelity_claim=False)
destination = PRIVATE / 'level4-t306-upper-walk-original-audit.json'
assert not destination.exists()
destination.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
archive = PRIVATE / 'level4-t306-upper-walk-original-images.zip'
assert not archive.exists()
images = [NATIVE / f'original-level4-t298-{tick}-present.png' for tick in range(FIRST, LAST + 1)]
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
    for path in images:
        target.write(path, path.name)
with zipfile.ZipFile(archive) as target:
    assert len(target.infolist()) == FRAMES
    assert all(target.read(path.name) == path.read_bytes() for path in images)
for tick in (FIRST, LAST):
    source = (NATIVE / f'original-level4-t298-{tick}-present.png').read_bytes()
    image = PRIVATE / f'level4-t306-original-upper-walk-{tick}.png'
    assert not image.exists()
    image.write_bytes(source)
    assert image.read_bytes() == source
report.update(images_archive_sha256=sha(archive.read_bytes()), all_original_png_members_byte_equal=True)
destination.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'records'}), flush=True)
