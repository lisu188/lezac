"""Original-only approach and first cavity blast, with complete private snapshots."""
import ast
import copy
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys
import traceback
import zipfile
from private_replace_t341 import replace_retry

PRIVATE = Path(__file__).parent
ROOT = Path('/mnt/c/Users/andrz/git/lezac-level4-left-demolition-20261103')
FIRST, LAST = 13700, 14700
SOURCE = PRIVATE / 'capture-right-pole-t313.py'
raw = SOURCE.read_bytes()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert sha(raw) == '10f190d72b77e2e956be0c977f44a1776c96349a9fe63ac4fd7a429350cf3756'
sys.path.insert(0, str(ROOT / 'tools'))
import level1_fidelity as fidelity

parent = PRIVATE / 'level4-t331-settled_field_right_walk-retained.zip'
PARENT_SHA = 'd7dbd11d9e30a14ab3497e1675e382e5bc128854d84272493421eacbf79e7ff4'
assert sha(parent.read_bytes()) == PARENT_SHA
with zipfile.ZipFile(parent) as archive:
    parent_route = archive.read('route.txt')
assert sha(parent_route) == '4ead9bbc3056e144ad6e25cb408940833082fb983304f2ba92042e639ce7512b'
inputs = PRIVATE / 'level4-t343-source-input'
inputs.mkdir(exist_ok=True)
parent_path = inputs / 'parent-route.txt'
if parent_path.exists():
    assert parent_path.read_bytes() == parent_route
else:
    with parent_path.open('xb') as output:
        output.write(parent_route)
settings, all_events = fidelity.read_route(parent_path)
assert settings['ticks'] == 15800
events = {tick: rows for tick, rows in all_events.items() if tick <= LAST}
held = set()
for tick in sorted(events):
    for row in events[tick]:
        if row['action'] == 'down':
            assert row['key'] not in held
            held.add(row['key'])
        else:
            held.remove(row['key'])
assert not held
lines = ['LEZAC_LEVEL1_ROUTE_V1', f"seed {settings['seed']}", f'ticks {LAST}', f"step_us {settings['step_us']}"]
lines += [f"event {tick} {row['action']} {row['key']}" for tick in sorted(events) for row in events[tick]]
ROUTE_BYTES = ('\n'.join([*lines, 'end']) + '\n').encode('ascii')
ROUTE_SHA = sha(ROUTE_BYTES)
baseline = PRIVATE / 'level4-t341-native-capture/route.txt'
assert sha(baseline.read_bytes()) == '582739d3d1e049e02e37e9d5a5e586f5a5346058655c4cbb2991b1a95429bc96'
anchor_settings, anchor_events = fidelity.read_route(baseline)
assert settings == {**anchor_settings, 'ticks': 15800} and anchor_settings['ticks'] == FIRST
assert {tick: rows for tick, rows in events.items() if tick <= FIRST} == anchor_events
assert events[14502] == [dict(action='down', key='n')]
assert events[13702] == [dict(action='down', key='z'), dict(action='down', key='m')]
audit_path = PRIVATE / 'level4-t339-support-wait-original-audit.json'
assert sha(audit_path.read_bytes()) == 'f37a3cb76b2f44013fe36686cee60966114dface40f6cae9f44ae09416c5448e'
audit = fidelity.strict_json(audit_path.read_text())
assert audit['cpp_expectations_used'] is False and audit['capture_request_complete'] is True
assert audit['observed_complete_window'] == [13300, FIRST]
reference = PRIVATE / 'level4-t339-support-wait-original-reference.jsonl.gz'
REFERENCE_SHA = '53ff70a488bc3d2f42e19e5aac747b5b0005497b10567b7c1e8e078588db7384'
assert sha(reference.read_bytes()) == audit['reference_sha256'] == REFERENCE_SHA
rows = [fidelity.strict_json(line.decode()) for line in gzip.decompress(reference.read_bytes()).splitlines()]
assert rows[0]['expected_bytes_source'] == 'original_only' and rows[0]['cpp_expectations_used'] is False
assert [(row['index'], row['phase']) for row in rows[-3:-1]] == [(FIRST, 'present'), (FIRST, 'post_update')]

BATCH_GUARD = '''if report['status'] == 'running' and report['checkpoints']:
    last = report['checkpoints'][-1]
    if last['tick'] >= FIRST and last['tick'] != LAST and (last['tick'] % 25 != 0 or last['phase'] != 'post_update'):
        return
'''
batch_path = PRIVATE / 'level4-t343-batch-controls/result.json'
storage = PRIVATE / 'capture-upper-demolition-t308.py'
storage_raw = storage.read_bytes()
assert sha(storage_raw) == 'a32279bfcdff6dce8b80f6d7a1e87c945ccff04f42a540ec4d3d7f923445b182'
if sys.argv[1:] == ['--batch-tests-only']:
    functions = [node for node in ast.parse(storage_raw.decode()).body
        if isinstance(node, ast.FunctionDef) and node.name == 'save_report']
    assert len(functions) == 1
    functions[0].body.insert(0, ast.parse(BATCH_GUARD).body[0])
    writes = []
    class FakeFile:
        def write_text(self, value):
            writes.append(json.loads(value))
    class FakeOut:
        def __truediv__(self, name):
            assert name == 'report.json'
            return FakeFile()
    namespace = dict(OUT=FakeOut(), FIRST=FIRST, LAST=LAST, json=json, mirror_metadata=lambda: None)
    module = ast.fix_missing_locations(ast.Module(body=functions, type_ignores=[]))
    exec(compile(module, str(storage), 'exec'), namespace)
    controls = []
    for name, status, checkpoint, expected in (
        ('initial_report', 'running', None, True),
        ('earlier_handoff', 'running', dict(tick=9422, phase='present'), True),
        ('intermediate_record', 'running', dict(tick=13701, phase='post_update'), False),
        ('quarter_present', 'running', dict(tick=13725, phase='present'), False),
        ('quarter_post', 'running', dict(tick=13725, phase='post_update'), True),
        ('last_present', 'running', dict(tick=LAST, phase='present'), True),
        ('failure_always_flushed', 'incomplete', dict(tick=13701, phase='present'), True),
        ('completion_always_flushed', 'original_continuation_observed', dict(tick=13701, phase='present'), True),
    ):
        namespace['report'] = dict(status=status, checkpoints=[] if checkpoint is None else [checkpoint])
        before = len(writes)
        namespace['save_report']()
        assert (len(writes) == before + 1) is expected
        if expected:
            assert writes[-1] == namespace['report']
        controls.append(name)
    batch_path.parent.mkdir(exist_ok=False)
    result = dict(status='passed', controls=controls, guest_launched=False,
        observer_sha256=sha(Path(__file__).read_bytes()), policy_sha256=sha(BATCH_GUARD.encode()),
        snapshot_and_boundary_backup_frequency_unchanged=True)
    with batch_path.open('x') as output:
        output.write(json.dumps(result, sort_keys=True, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    raise SystemExit(0)
batch = fidelity.strict_json(batch_path.read_text())
assert batch['status'] == 'passed' and len(batch['controls']) == 8 and batch['guest_launched'] is False
assert batch['observer_sha256'] == sha(Path(__file__).read_bytes()) and batch['policy_sha256'] == sha(BATCH_GUARD.encode())

mapping = {
    '/dev/shm/lezac-native-upper-demolition-t308': '/dev/shm/lezac-native-first-cavity-blast-t343',
    'level4-t308-storage-preflight': 'level4-t343-storage-preflight',
    'level4-t308-storage-prepare': 'level4-t343-storage-prepare',
    'level4-t308-native-capture': 'level4-t343-native-capture',
    'fabae4a51121143d55705a5f6ccf3ddd352fcfa863c13c6c1da81de7e79dfeaf': ROUTE_SHA,
    '6e636846b908ec7655ed6ecabc0cb96be39945f3448a74297bc23e65285f5909':
        '582739d3d1e049e02e37e9d5a5e586f5a5346058655c4cbb2991b1a95429bc96',
    '710495547ef420ed076415d618ad9d552434378a22817b6a70da8b9ef9e602ec': REFERENCE_SHA,
}
counts = dict(mapping=0, parent=0, parent_sha=0, route_sha=0, route_bytes=0, window=0,
    baseline=0, reference=0, anchor=0, report=0, labels=0, deadline=0, batching=0, counter_init=0, counter_check=0)
class Configure(ast.NodeTransformer):
    def visit_Assign(self, node):
        if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            values = {
                'replacements': ('mapping', repr(mapping)),
                'CANDIDATE_ARCHIVE': ('parent', "PRIVATE / 'level4-t331-settled_field_right_walk-retained.zip'"),
                'CANDIDATE_ARCHIVE_SHA': ('parent_sha', repr(PARENT_SHA)),
                'CANDIDATE_ROUTE_SHA': ('route_sha', repr(ROUTE_SHA)),
                'route_bytes': ('route_bytes', 'DERIVED_ROUTE_BYTES'),
            }
            if node.targets[0].id in values:
                key, value = values[node.targets[0].id]
                node.value = ast.parse(value, mode='eval').body
                counts[key] += 1
            if node.targets[0].id == 'changes':
                node.value.keywords.extend([ast.keyword(arg='deadline', value=ast.Constant(0)),
                    ast.keyword(arg='batch_policy', value=ast.Constant(0))])
                counts['counter_init'] += 1
        return self.generic_visit(node)

    def visit_Assert(self, node):
        if isinstance(node.test, ast.Compare) and isinstance(node.test.left, ast.Name) and node.test.left.id == 'changes':
            expected = node.test.comparators[0]
            assert isinstance(expected, ast.Call)
            expected.keywords.extend([ast.keyword(arg='deadline', value=ast.Constant(2)),
                ast.keyword(arg='batch_policy', value=ast.Constant(1))])
            counts['counter_check'] += 1
        return self.generic_visit(node)

    def visit_FunctionDef(self, node):
        node = self.generic_visit(node)
        if node.name == 'visit_Constant':
            node.body.insert(0, ast.parse("if type(node.value) is int and node.value == 1800:\n"
                "    changes['deadline'] += 1\n    return ast.copy_location(ast.Constant(2400), node)").body[0])
            counts['deadline'] += 1
        if node.name == 'visit_FunctionDef':
            node.body.insert(0, ast.parse("if node.name == 'save_report':\n"
                f"    node.body.insert(0, ast.parse({BATCH_GUARD!r}).body[0])\n"
                "    changes['batch_policy'] += 1").body[0])
            counts['batching'] += 1
        return node

    def visit_Call(self, node):
        if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and \
                node.func.value.id == 'ast' and node.func.attr == 'Constant' and len(node.args) == 1 and \
                isinstance(node.args[0], ast.Constant) and node.args[0].value == 12000:
            node.args[0] = ast.Constant(FIRST)
            counts['anchor'] += 1
        return self.generic_visit(node)

    def visit_Constant(self, node):
        if isinstance(node.value, str):
            values = {
                '(12000, 12500)': ('window', repr((FIRST, LAST))),
                "PRIVATE / 'level4-t308-native-capture/route.txt'": ('baseline', "PRIVATE / 'level4-t341-native-capture/route.txt'"),
                "PRIVATE / 'level4-t308-upper-demolition-original-reference.jsonl.gz'":
                    ('reference', "PRIVATE / 'level4-t339-support-wait-original-reference.jsonl.gz'"),
            }
            if node.value in values:
                key, value = values[node.value]
                counts[key] += 1
                return ast.copy_location(ast.Constant(value), node)
            if node.value.startswith('report.update('):
                embedded = ast.parse(node.value)
                call = embedded.body[0].value
                for keyword in call.keywords:
                    if keyword.arg == 'previous_original_anchor_tick':
                        keyword.value = ast.Constant(FIRST)
                    elif keyword.arg == 'previous_original_reference_sha256':
                        keyword.value = ast.Constant(REFERENCE_SHA)
                call.keywords.extend([ast.keyword(arg='cumulative_report_batch_interval', value=ast.Constant(25)),
                    ast.keyword(arg='snapshot_backups_individually_flushed', value=ast.Constant(True))])
                counts['report'] += 1
                return ast.copy_location(ast.Constant(ast.unparse(embedded)), node)
            if 't313' in node.value:
                counts['labels'] += 1
                return ast.copy_location(ast.Constant(node.value.replace('t313', 't343')), node)
        return node

tree = Configure().visit(ast.parse(raw.decode(), filename=str(SOURCE)))
assert counts == dict(mapping=1, parent=1, parent_sha=1, route_sha=1, route_bytes=1, window=1,
    baseline=1, reference=1, anchor=1, report=1, labels=4, deadline=1, batching=1,
    counter_init=1, counter_check=1), counts
ast.fix_missing_locations(tree)
helper_sha = sha((PRIVATE / 'private_replace_t341.py').read_bytes())
assert helper_sha == '9128f4864daf44adf2d525cca4c4fa70462ba17a9bb62b732e815432d766190a'
sharing_path = PRIVATE / 'level4-t341-sharing-control/result.json'
sharing = fidelity.strict_json(sharing_path.read_text())
assert sharing['status'] == 'passed' and sharing['actual_windows_sharing_denial'] is True
assert sharing['helper_sha256'] == helper_sha
actual_replace, retries = os.replace, []
def private_replace(source, destination):
    target = Path(destination)
    if target.parent.parent == PRIVATE and target.parent.name.startswith('level4-t343-'):
        return replace_retry(source, destination, actual_replace, retries)
    return actual_replace(source, destination)
mode = ('mirror' if '--mirror-tests-only' in sys.argv else 'preflight' if '--preflight-only' in sys.argv else
    'prepare' if '--prepare-only' in sys.argv else 'capture')
failure = None
os.replace = private_replace
try:
    exec(compile(tree, str(SOURCE), 'exec'), dict(__name__='__main__', __file__=str(Path(__file__)),
        DERIVED_ROUTE_BYTES=ROUTE_BYTES))
except BaseException as error:
    if not isinstance(error, SystemExit) or error.code not in (None, 0):
        failure = traceback.format_exc()
        with (PRIVATE / f'level4-t343-failure-{mode}.txt').open('x') as output:
            output.write(failure)
    raise
finally:
    assert os.replace is private_replace
    os.replace = actual_replace
    receipt = dict(status='failed' if failure is not None else 'completed', mode=mode,
        retry_events=retries, helper_sha256=helper_sha, observer_sha256=sha(Path(__file__).read_bytes()),
        actual_sharing_control_sha256=sha(sharing_path.read_bytes()), batch_control_sha256=sha(batch_path.read_bytes()),
        process_replace_hook_restored=True, maximum_seconds=2400, cumulative_report_batch_interval=25,
        snapshot_backups_individually_flushed=True, full_readback_requirements_unchanged=True,
        source_configuration_sha256=sha(raw), route_sha256=ROUTE_SHA, parent_archive_sha256=PARENT_SHA,
        previous_original_anchor_tick=FIRST, previous_original_reference_sha256=REFERENCE_SHA,
        public_upload=False)
    with (PRIVATE / f'level4-t343-replace-{mode}-receipt.json').open('x') as output:
        output.write(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
