"""Private ordinary-input original campaign continuation, with no gameplay-state seeds."""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import struct
import sys
import time

ROOT = Path('/mnt/c/Users/andrz/git/lezac-level4-continuation-20261103')
PRIVATE = Path(__file__).parent
OUT = Path('/dev/shm/lezac-native-level4-continuation-t298-v3')
ROUTE = Path('/dev/shm/lezac-level4-charge-t298/left_medium_follow_through/route.txt')
sys.path.insert(0, str(ROOT / 'tools'))
import level1_original as original
import level1_fidelity as fidelity
import capture_original_level1_handoff as handoff
import capture_original_level1_results as reels
import capture_original_level1_typing as typing
import natural_level4_support_column as support
from PIL import Image

resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
resource.setrlimit(resource.RLIMIT_FSIZE, (128 * 1024**2, 128 * 1024**2))
assert os.environ.get('DISPLAY') and os.environ.get('SDL_AUDIODRIVER') == 'dummy'
assert all(os.environ.get(key, '').startswith('/dev/shm/') for key in ('TMPDIR', 'TMP', 'TEMP'))
assert shutil.disk_usage('/dev/shm').free > 512 * 1024**2
OUT.mkdir(exist_ok=False)
RUN = OUT / 'runtime'
RUN.mkdir()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
protected = {str(path): sha(path) for path in (ROOT / 'LEZAC.EXE', ROUTE,
    support.FIXTURE / 'route.txt', *(ROOT / name for name in fidelity.ASSETS))}
for path in ROOT.iterdir():
    if path.suffix.upper() in {'.EXE', '.DAT', '.SPR', '.PAL', '.SCH', '.SON', '.MST', '.CAR', '.ZBG', '.DOC'}:
        shutil.copyfile(path, RUN / path.name)
shutil.copyfile(Path(__file__), OUT / 'observer.py')
shutil.copyfile(ROUTE, OUT / 'route.txt')
settings, events = fidelity.read_route(ROUTE)
_, old_events = support.check_route(support.FIXTURE / 'route.txt')
assert {tick: rows for tick, rows in events.items() if tick < 11740} == old_events
expected = {(row['index'], row['phase']): row for row in support.fixture()[1:-1]
            if row['section'] == 'level4'}
report = dict(status='running', route_sha256=sha(ROUTE), observer_sha256=sha(Path(__file__)),
    original_exe_sha256=original.EXE_SHA256, audio='dummy', ordinary_gameplay_inputs_only=True,
    initial_rng_controlled=True, normalized_control_bank_inputs=True,
    gameplay_state_injections=False, full_guest_ram_exports=0, core_dumps=0,
    manual_input_claim=False, wall_clock_claim=False, whole_game_fidelity_claim=False,
    checkpoints=[], handoffs=[], protected_inputs_sha256=protected)


def save_report():
    (OUT / 'report.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')


class Session(original.OriginalSession):
    extra_original = {}
    extra_restored = False

    def native_state(self):
        # All projected fields and heap planes come from one stopped-child instant.
        with self.stopped():
            data = original.OriginalSession.read(self, self.ds, 65536)
            state = original.OriginalSession.state(self)
            width, height = original.word(data, 0xC204), original.word(data, 0x2096) // 8 + 21
            level = data[0x79B7]
            assert (level, width, height) in {(1, 60, 33), (2, 100, 53), (3, 150, 60), (4, 100, 58)}, (level, width, height)
            for key, at, length in (('tiles', 0xC1E0, width * height), ('words', 0x6612, width * height * 2)):
                offset, segment = struct.unpack_from('<HH', data, at)
                assert 0 < segment < 0xA000 and offset + length <= 65536
                state[key] = self.read(self.base + (segment << 4) + offset, length).hex()
            dac = self.read(self.resident + handoff.DAC, 768).hex()
            assert all(value <= 63 for value in bytes.fromhex(dac))
            assert original.word(data, 0x78C2) == state['frame']
            assert struct.unpack_from('<I', data, 0x1AFE)[0] == state['rng']
            handshake = self.read(self.resident + original.SCRATCH, 20)
            assert struct.unpack('<8HI', handshake)[8] == self.sequence
        return state, data, dac, original.word(data, 0x2070)

    def observe(self, tick, phase, picture=False):
        state, data, dac, atlas = self.native_state()
        level = data[0x79B7]
        projection = support.recovered.native_projection(state, dac, atlas,
            actors=level in support.recovered.PROFILES)
        projection['terrain'] = support.recovered.projection.native_terrain(data)
        row = dict(tick=tick, phase=phase, sequence=self.sequence, level=level,
                   ds_sha256=hashlib.sha256(data).hexdigest(), projection=projection,
                   original_observation=True, known_prefix_compared=False)
        if (tick, phase) in expected:
            reference = expected[tick, phase]
            difference = fidelity.first_difference(reference['projection'], projection)
            row['known_prefix_difference'] = difference
            row['known_prefix_compared'] = difference is None
        (OUT / f'boundary-{tick}-{phase}.json').write_text(json.dumps(row, sort_keys=True) + '\n')
        (OUT / f'ds-{tick}-{phase}.bin').write_bytes(data)
        if picture:
            pixels = self.screenshot()
            path = OUT / f'original-level4-t298-{tick}-{phase}.png'
            Image.frombytes('RGB', (320, 200), pixels).save(path)
            assert Image.open(path).convert('RGB').tobytes() == pixels
            row['rgb_sha256'] = hashlib.sha256(pixels).hexdigest()
            row['png_sha256'] = sha(path)
            row['png'] = str(path)
            if (tick, phase) in expected and expected[tick, phase]['rgb_sha256'] is not None:
                row['known_rgb_match'] = row['rgb_sha256'] == expected[tick, phase]['rgb_sha256']
        summary = {key: value for key, value in row.items() if key != 'projection'}
        summary['mapped'] = {key: projection['mapped'][key] for key in ('frame', 'rng', 'progress', 'players')}
        report['checkpoints'].append(summary)
        save_report()
        print(json.dumps(summary), flush=True)
        if (tick, phase) in expected:
            assert row['known_prefix_compared'], row.get('known_prefix_difference')
            if picture and 'known_rgb_match' in row:
                assert row['known_rgb_match'], 'native prefix RGB differs'
        return state

    def patch(self, entry, code, slot):
        with self.stopped():
            if entry not in self.extra_original:
                self.extra_original[entry] = self.read(self.cs + entry, 5)
            self.write(self.resident + slot, code)
            self.write(self.cs + entry, original.far_call(slot, self.resident_segment))

    def gameplay_hooks(self, enabled):
        with self.stopped():
            for stage, (entry, signature) in enumerate(original.HOOKS, 1):
                if enabled and stage != 1:
                    slot = original.TRAMPOLINES + (stage - 1) * 0x80
                    code = handoff.palette_trampoline(original.trampoline(stage, self.image))
                    self.write(self.resident + slot, code)
                    self.write(self.cs + entry, original.far_call(slot, self.resident_segment))
                else:
                    self.write(self.cs + entry, bytes.fromhex(signature))

    def queue_return(self):
        before = self.read(self.base + 0x400, 64)
        assert original.word(before, 0x1A) == original.word(before, 0x1C), 'nonempty BIOS queue'
        self.xdo('key', '--clearmodifiers', 'Return')
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            after = self.read(self.base + 0x400, 64)
            head, tail = original.word(after, 0x1A), original.word(after, 0x1C)
            if head != tail:
                assert 0x1E <= head < 0x3E and 0x1E <= tail < 0x3E
                assert original.word(after, head) == 0x1C0D
                return dict(before_bda_hex=before.hex(), bda_hex=after.hex(), head=head, tail=tail)
            time.sleep(.01)
        raise RuntimeError('Return did not enter BIOS queue')

    def handoff(self, level):
        self.gameplay_hooks(False)
        assert self.read(self.cs + reels.ENTRY, 5).hex() == reels.SIGNATURE
        self.patch(reels.ENTRY, handoff.palette_trampoline(reels.result_trampoline()), 0x400)
        self.release(4)
        previous_rng, samples = None, []
        for index in range(100):
            self.wait(reels.STAGE)
            state, data, _, _ = self.native_state()
            assert data[0x79B7] == level
            if previous_rng is not None:
                assert state['rng'] == (previous_rng * 0x08088405 + 1) & 0xFFFFFFFF
            scores = bytes.fromhex(state['scores'])
            samples.append(dict(index=index, phase=scores[44], rng=state['rng'], score=int.from_bytes(scores[:4], 'little')))
            previous_rng = state['rng']
            if scores[44] == 2:
                break
            self.release(reels.STAGE)
        else:
            raise RuntimeError('native score reels did not settle')
        with self.stopped():
            self.write(self.cs + reels.ENTRY, self.extra_original[reels.ENTRY])
        native = self.extra_original.get(handoff.ENTRY, self.read(self.cs + handoff.ENTRY, 5))
        runtime_cs = (self.cs - self.base) >> 4
        assert native[:3].hex() == '9a0f03' and original.word(native, 3) == runtime_cs + 0x084A
        ack_code = typing.trampoline(native)
        for old, new in ((b'\x2e\xc7\x06' + struct.pack('<HH', original.SCRATCH, 5),
                          b'\x2e\xc7\x06' + struct.pack('<HH', original.SCRATCH, 7)),
                         (b'\x2e\x83\x3e' + struct.pack('<H', original.SCRATCH + 14) + b'\x05',
                          b'\x2e\x83\x3e' + struct.pack('<H', original.SCRATCH + 14) + b'\x07')):
            assert ack_code.count(old) == 1
            ack_code = ack_code.replace(old, new)
        self.patch(handoff.ENTRY, handoff.palette_trampoline(ack_code), 0x480)
        self.release(reels.STAGE)
        self.wait(7)
        intro_native = self.extra_original.get(handoff.INTRO_ENTRY, self.read(self.cs + handoff.INTRO_ENTRY, 5))
        assert intro_native == native
        self.patch(handoff.INTRO_ENTRY, handoff.intro_trampoline(intro_native), 0x400)
        self.gameplay_hooks(True)
        ack = self.queue_return()
        self.release(7)
        self.wait(6)
        state, data, _, _ = self.native_state()
        assert data[0x79B7] == level + 1
        intro_ack = self.queue_return()
        report['handoffs'].append(dict(from_level=level, to_level=level + 1, reels=samples,
            intro_frame=state['frame'], intro_rng=state['rng'], ack=ack, intro_ack=intro_ack))
        save_report()
        print(f'native_handoff={level}->{level + 1} frame={state["frame"]} rng={state["rng"]}', flush=True)
        self.release(6)

    def walk(self, first, last, level, offset):
        for tick in range(first, last + 1):
            self.wait(2)
            for event in events.get(tick - 1, []):
                if event['key'] in original.BANK:
                    self.write(self.ds + original.BANK[event['key']], bytes([event['action'] != 'up']))
            self.release(2)
            self.wait(3)
            retained = tick in {9422, 11301, 11740, 11800, 11900, last}
            if retained:
                self.observe(tick, 'present', picture=level == 4)
            self.release(3)
            self.wait(4)
            identity = self.read(self.ds + 0x78C2, 2)
            assert original.word(identity, 0) == tick - offset
            assert self.read(self.ds + 0x79B7, 1) == bytes([level])
            if retained:
                self.observe(tick, 'post_update')
            if tick % 250 == 0:
                print(f'native_level={level} tick={tick}/{last}', flush=True)
            if tick != last:
                self.release(4)

    def close(self):
        try:
            if self.child is not None and self.child.poll() is None and self.extra_original:
                with self.stopped():
                    for entry, native in self.extra_original.items():
                        self.write(self.cs + entry, native)
                    self.extra_restored = all(self.read(self.cs + at, 5) == raw for at, raw in self.extra_original.items())
                    assert self.extra_restored
        finally:
            super().close()


session = None
save_report()
try:
    args = argparse.Namespace(route=ROOT / 'tests/fixtures/level1_original/completion_gate/route.txt',
                              startup_seconds=10, intro_seconds=3)
    session = Session(args, RUN, OUT)
    with original.compressed_writer(OUT / 'prefix.jsonl.gz') as emit:
        assert session.capture(emit) == 305
    session.handoff(1)
    session.walk(731, 3094, 2, 425)
    session.handoff(2)
    session.walk(3777, 8905, 3, 1107)
    session.handoff(3)
    session.walk(9422, settings['ticks'], 4, 1623)
    report['status'] = 'original_continuation_observed'
except BaseException as error:
    report['status'] = 'incomplete'
    report['error'] = repr(error)
    raise
finally:
    if session is not None:
        session.close()
        report['base_hooks_restored'] = session.restored
        report['extra_hooks_restored'] = session.extra_restored
        report['owned_child_terminal'] = session.child is None or session.child.poll() is not None
    report['protected_inputs_preserved'] = protected == {path: sha(Path(path)) for path in protected}
    save_report()
