"""Original-only right-pole continuation with tested private snapshot mirroring."""
import ast
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys
import zipfile

PRIVATE = Path(__file__).parent
STORAGE_BASE_PATH = PRIVATE / 'capture-upper-demolition-t308.py'
STORAGE_BASE_RAW = STORAGE_BASE_PATH.read_bytes()
STORAGE_BASE_SHA = 'a32279bfcdff6dce8b80f6d7a1e87c945ccff04f42a540ec4d3d7f923445b182'
assert hashlib.sha256(STORAGE_BASE_RAW).hexdigest() == STORAGE_BASE_SHA
CANDIDATE_ARCHIVE = PRIVATE / 'level4-t311-right_pole_close_medium-retained.zip'
CANDIDATE_ARCHIVE_SHA = '724f7845b6256efbc7cb44a25746a621b0d6926de378b9d79adb2baba91fbdbe'
CANDIDATE_ROUTE_SHA = 'd59bc17eae69a25bbf1b4793c7ae1a2092627cb5ed29ed2e418dffb6e83391b9'
assert hashlib.sha256(CANDIDATE_ARCHIVE.read_bytes()).hexdigest() == CANDIDATE_ARCHIVE_SHA
with zipfile.ZipFile(CANDIDATE_ARCHIVE) as archive:
    route_bytes = archive.read('route.txt')
assert hashlib.sha256(route_bytes).hexdigest() == CANDIDATE_ROUTE_SHA
inputs = PRIVATE / 'level4-t313-input'
inputs.mkdir(exist_ok=True)
route_path = inputs / 'route.txt'
if route_path.exists():
    assert route_path.read_bytes() == route_bytes
else:
    with route_path.open('xb') as output:
        output.write(route_bytes)
    assert route_path.read_bytes() == route_bytes

replacements = {
    '/dev/shm/lezac-native-upper-demolition-t308': '/dev/shm/lezac-native-right-pole-t313',
    'level4-t308-storage-preflight': 'level4-t313-storage-preflight',
    'level4-t308-storage-prepare': 'level4-t313-storage-prepare',
    'level4-t308-native-capture': 'level4-t313-native-capture',
    'fabae4a51121143d55705a5f6ccf3ddd352fcfa863c13c6c1da81de7e79dfeaf': CANDIDATE_ROUTE_SHA,
    '6e636846b908ec7655ed6ecabc0cb96be39945f3448a74297bc23e65285f5909':
        'fabae4a51121143d55705a5f6ccf3ddd352fcfa863c13c6c1da81de7e79dfeaf',
    '710495547ef420ed076415d618ad9d552434378a22817b6a70da8b9ef9e602ec':
        'ba1f32ed7c028a91885b06e0fe23fe404caa2df94bcaae5e513ea8aa55a66e8d',
}
changes = dict(constants=0, prefix_limit=0, route=0, window=0, baseline=0,
    reference=0, protected=0, receipt=0, report=0, storage_source=0, immutable_readback=0)

class Configure(ast.NodeTransformer):
    def visit_Constant(self, node):
        if isinstance(node.value, str) and node.value in replacements:
            changes['constants'] += 1
            return ast.copy_location(ast.Constant(replacements[node.value]), node)
        if type(node.value) is int and node.value == 11000:
            changes['prefix_limit'] += 1
            return ast.copy_location(ast.Constant(12000), node)
        return node

    def visit_Assign(self, node):
        if len(node.targets) == 1 and ast.unparse(node.targets[0]) == '(FIRST, LAST)':
            node.value = ast.parse('(12000, 12500)', mode='eval').body
            changes['window'] += 1
        elif len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            values = {
                'ROUTE': "PRIVATE / 'level4-t313-input/route.txt'",
                'baseline_route': "PRIVATE / 'level4-t308-native-capture/route.txt'",
                'prefix_path': "PRIVATE / 'level4-t308-upper-demolition-original-reference.jsonl.gz'",
            }
            if name in values:
                node.value = ast.parse(values[name], mode='eval').body
                changes[{'ROUTE': 'route', 'baseline_route': 'baseline', 'prefix_path': 'reference'}[name]] += 1
            if name == 'protected':
                assert isinstance(node.value, ast.DictComp)
                iterator = node.value.generators[0].iter
                assert isinstance(iterator, ast.Tuple)
                iterator.elts.extend(ast.parse(name, mode='eval').body for name in (
                    'STORAGE_BASE_PATH', 'CANDIDATE_ARCHIVE', 'prefix_path', 'baseline_route', 'MIRROR_CONTROL_PATH'))
                changes['protected'] += 1
            if name == 'controls':
                changes['storage_source'] += 1
                return [self.generic_visit(node), *ast.parse(
                    "(OUT / 'capture-storage-base.py').write_bytes(STORAGE_BASE_RAW)\n"
                    "private_write('capture-storage-base.py', STORAGE_BASE_RAW)\n"
                    "(OUT / 'mirror-control-tests.json').write_bytes(MIRROR_CONTROL_PATH.read_bytes())\n"
                    "private_write('mirror-control-tests.json', MIRROR_CONTROL_PATH.read_bytes())\n").body]
            if name == 'receipt':
                changes['receipt'] += 1
                return [self.generic_visit(node), ast.parse(
                    "receipt.update(storage_base_sha256=STORAGE_BASE_SHA, configuration_transforms=dict(changes), "
                    "mirror_control_sha256=MIRROR_CONTROL_SHA, "
                    "route_input_source='C++ route planning stimulus only; no C++ state expectations', "
                    "candidate_archive_sha256=CANDIDATE_ARCHIVE_SHA)").body[0]]
            if name == 'report':
                changes['report'] += 1
                return [self.generic_visit(node), ast.parse(
                    "report.update(storage_base_sha256=STORAGE_BASE_SHA, configuration_transforms=dict(changes), "
                    "mirror_control_sha256=MIRROR_CONTROL_SHA, "
                    "route_input_source='C++ route planning stimulus only; no C++ state expectations', "
                    "candidate_archive_sha256=CANDIDATE_ARCHIVE_SHA, previous_original_anchor_tick=12000, "
                    "previous_original_reference_sha256='ba1f32ed7c028a91885b06e0fe23fe404caa2df94bcaae5e513ea8aa55a66e8d')"
                ).body[0]]
        return self.generic_visit(node)

    def visit_FunctionDef(self, node):
        if node.name == 'mirror_file':
            assert isinstance(node.body[0], ast.Assert)
            node.body.insert(1, ast.parse(
                "if path.name.startswith(('ds-', 'boundary-')) and path.name.endswith('.gz') and (DURABLE / path.name).is_file():\n"
                "    assert (DURABLE / path.name).read_bytes() == path.read_bytes()\n"
                "    return\n").body[0])
            changes['immutable_readback'] += 1
        return self.generic_visit(node)

tree = Configure().visit(ast.parse(STORAGE_BASE_RAW.decode(), filename=str(STORAGE_BASE_PATH)))
assert changes == dict(constants=7, prefix_limit=1, route=1, window=1, baseline=1,
    reference=1, protected=1, receipt=1, report=1, storage_source=1, immutable_readback=1), changes
ast.fix_missing_locations(tree)
MIRROR_CONTROL_PATH = PRIVATE / 'level4-t313-mirror-controls-v2/control-results.json'

if sys.argv[1:] == ['--mirror-tests-only']:
    out = Path('/dev/shm/lezac-mirror-controls-t313-v2')
    durable = MIRROR_CONTROL_PATH.parent
    assert not out.exists() and not durable.exists()
    out.mkdir()
    durable.mkdir()
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef)
                 and node.name in ('private_write', 'mirror_file')]
    assert len(functions) == 2
    namespace = dict(OUT=out, DURABLE=durable, mirrored={}, os=os, Path=Path)
    exec(compile(ast.Module(body=functions, type_ignores=[]), 'actual-transformed-mirror-functions', 'exec'), namespace)
    writes = []
    actual_write = namespace['private_write']
    def tracked_write(name, raw):
        writes.append(name)
        actual_write(name, raw)
    namespace['private_write'] = tracked_write
    mirror = namespace['mirror_file']
    passed = []
    for prefix, source in (('ds', bytes(range(256)) * 256), ('boundary', b'{"synthetic_only":true}\n')):
        name = f'{prefix}-12000-present.test.gz'
        path = out / name
        raw = gzip.compress(source, mtime=0)
        path.write_bytes(raw)
        mirror(path)
        mirror(path)
        assert (durable / name).read_bytes() == raw and writes.count(name) == 1
        passed.append(prefix + '_immutable_no_duplicate_write')
    for name in ('prefix.jsonl.gz', 'report.json'):
        path = out / name
        old = gzip.compress(b'synthetic-open', mtime=0) if name.endswith('.gz') else b'{"synthetic":"open"}\n'
        new = gzip.compress(b'synthetic-complete-with-trailer', mtime=0) if name.endswith('.gz') else b'{"synthetic":"complete"}\n'
        path.write_bytes(old)
        mirror(path)
        path.write_bytes(new)
        mirror(path)
        assert (durable / name).read_bytes() == new and writes.count(name) == 2
        passed.append(name + '_mutable_refresh')
    immutable = out / 'ds-12000-present.test.gz'
    original = (durable / immutable.name).read_bytes()
    immutable.write_bytes(gzip.compress(b'synthetic-corruption', mtime=0))
    try:
        mirror(immutable)
    except AssertionError:
        assert (durable / immutable.name).read_bytes() == original
        passed.append('immutable_mutation_rejected_preserving_backup')
    else:
        raise AssertionError('Immutable mutation was not rejected')
    try:
        mirror(out / 'nested/outside-source.gz')
    except AssertionError:
        passed.append('outside_source_rejected')
    else:
        raise AssertionError('Outside source was not rejected')
    assert len(passed) == 6
    result = dict(status='passed', tests=6, controls=passed, source='synthetic controls on actual transformed functions',
        guest_launched=False, original_expectations_used=False,
        observer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), storage_base_sha256=STORAGE_BASE_SHA)
    with MIRROR_CONTROL_PATH.open('x') as handle:
        handle.write(json.dumps(result, sort_keys=True, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    raise SystemExit(0)

mirror_controls = json.loads(MIRROR_CONTROL_PATH.read_text())
assert mirror_controls['status'] == 'passed' and mirror_controls['tests'] == 6 and mirror_controls['guest_launched'] is False
assert mirror_controls['observer_sha256'] == hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
MIRROR_CONTROL_SHA = hashlib.sha256(MIRROR_CONTROL_PATH.read_bytes()).hexdigest()
exec(compile(tree, str(STORAGE_BASE_PATH), 'exec'), globals())
