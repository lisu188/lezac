"""Bounded original capture with user-authorized private compressed snapshot backups."""
import argparse
import ast
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import struct
import subprocess
import sys
import time
from PIL import Image

PRIVATE = Path(__file__).parent
ROOT = Path('/mnt/c/Users/andrz/git/lezac-level4-left-demolition-20261103')
PREFLIGHT = sys.argv[1:] == ['--preflight-only']
PREPARE = sys.argv[1:] == ['--prepare-only']
assert not sys.argv[1:] or PREFLIGHT or PREPARE
OUT = Path('/dev/shm/lezac-native-upper-demolition-t308' + ('-preflight' if PREFLIGHT else '-prepare' if PREPARE else ''))
DURABLE = PRIVATE / ('level4-t308-storage-preflight' if PREFLIGHT else 'level4-t308-storage-prepare' if PREPARE else 'level4-t308-native-capture')
ROUTE = Path('/dev/shm/lezac-upper-second-mid-t307/middle_left_bomb/route.txt')
ROUTE_SHA = 'fabae4a51121143d55705a5f6ccf3ddd352fcfa863c13c6c1da81de7e79dfeaf'
FIRST, LAST = 10634, 12000
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
resource.setrlimit(resource.RLIMIT_FSIZE, (128 * 1024**2, 128 * 1024**2))
ram, disk = shutil.disk_usage('/dev/shm'), shutil.disk_usage(PRIVATE)
assert ram.used + 192 * 1024**2 < int(ram.total * .75)
assert disk.used + 256 * 1024**2 < int(disk.total * .90)
assert not OUT.exists() and not DURABLE.exists()
OUT.mkdir()
DURABLE.mkdir()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def private_write(name, raw):
    assert Path(name).name == name and name not in ('.', '..')
    target = DURABLE / name
    temporary = DURABLE / ('.' + name + '.writing')
    assert target.parent.resolve() == DURABLE.resolve() and not temporary.exists()
    with temporary.open('xb') as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    assert temporary.read_bytes() == raw
    os.replace(temporary, target)
    assert target.read_bytes() == raw

def encoded(raw):
    buffer = io.BytesIO()
    with gzip.GzipFile(filename='', fileobj=buffer, mode='wb', mtime=0, compresslevel=9) as target:
        target.write(raw)
    result = buffer.getvalue()
    assert gzip.decompress(result) == raw
    return result

def append_exact(path, raw):
    with path.open('ab') as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())

def retain_lossless(path, raw):
    assert path.parent == OUT
    packed = encoded(raw)
    usage = shutil.disk_usage('/dev/shm')
    assert usage.used + len(packed) + 4 * 1024**2 < int(usage.total * .75)
    destination = path.with_name(path.name + '.gz')
    assert not destination.exists() and not (DURABLE / destination.name).exists()
    destination.write_bytes(packed)
    assert destination.read_bytes() == packed and gzip.decompress(destination.read_bytes()) == raw
    private_write(destination.name, packed)
    assert gzip.decompress((DURABLE / destination.name).read_bytes()) == raw
    metadata = dict(path=destination.name, source_bytes=len(raw), source_sha256=hashlib.sha256(raw).hexdigest(),
        encoded_bytes=len(packed), encoded_sha256=hashlib.sha256(packed).hexdigest(), readback_equal=True)
    line = (json.dumps(metadata, sort_keys=True) + '\n').encode('ascii')
    append_exact(OUT / 'lossless-retention.jsonl', line)
    append_exact(DURABLE / 'lossless-retention.jsonl', line)

mirrored = {}
def mirror_file(path):
    assert path.parent == OUT and not path.is_symlink()
    stat = path.stat()
    version = (stat.st_mtime_ns, stat.st_size)
    if mirrored.get(path.name) == version:
        return
    private_write(path.name, path.read_bytes())
    mirrored[path.name] = version

def mirror_metadata():
    for name in ('report.json', 'observer.py', 'route.txt', 'host-binding.json', 'dosbox.conf',
                 'L1ORACLE.COM', 'prefix.jsonl.gz', 'storage-controls.json', 'continuation-base.py',
                 'host-bound-base.py', 'verified-prefix-reference.jsonl.gz', 'launch-receipt.json'):
        path = OUT / name
        if path.is_file():
            mirror_file(path)

controls = {}
samples = {
    'synthetic-ds-zero': bytes(65536),
    'synthetic-ds-byte-domain': bytes(range(256)) * 256,
    'synthetic-ds-word-boundary': bytes((index * 73 + (index >> 8)) & 255 for index in range(65536)),
    **{f'synthetic-boundary-{phase}': json.dumps(dict(control_only=True, original_observation=False,
        phase=phase, bytes=[0, 127, 128, 255], word=65535), sort_keys=True).encode('ascii')
       for phase in ('input', 'present', 'post_update')},
}
for name, raw in samples.items():
    packed = encoded(raw)
    (OUT / (name + '.gz')).write_bytes(packed)
    private_write(name + '.gz', packed)
    assert gzip.decompress((DURABLE / (name + '.gz')).read_bytes()) == raw
    controls[name] = dict(kind='synthetic_codec_preflight', source_bytes=len(raw),
        source_sha256=hashlib.sha256(raw).hexdigest(), encoded_bytes=len(packed),
        encoded_sha256=hashlib.sha256(packed).hexdigest(), readback_equal=True)
(OUT / 'storage-controls.json').write_text(json.dumps(controls, sort_keys=True, indent=2) + '\n')
mirror_file(OUT / 'storage-controls.json')
if PREFLIGHT:
    private_write('result.json', json.dumps(dict(status='passed', controls=6, guest_launched=False,
        synthetic_controls_only=True, raw_guest_snapshots_used=False, atomic_private_readback_equal=True),
        sort_keys=True, indent=2).encode('ascii') + b'\n')
    print('storage_preflight=passed controls=6 guest_launched=0', flush=True)
    raise SystemExit(0)

assert Path.cwd() == Path('/dev/shm') and os.environ.get('DISPLAY')
assert os.environ.get('SDL_AUDIODRIVER') == 'dummy'
assert all(os.environ.get(name, '').startswith('/dev/shm/') for name in ('TMPDIR', 'TMP', 'TEMP'))
sys.path.insert(0, str(ROOT / 'tools'))
import level1_original as original
import level1_fidelity as fidelity
import capture_original_level1_handoff as handoff
import capture_original_level1_results as reels
import capture_original_level1_typing as typing
import natural_level4_support_column as support
import natural_level4_portal as anchor
from original_capture_contract import read_canonical_assets

assert sha(ROUTE) == ROUTE_SHA
settings, events = fidelity.read_route(ROUTE)
assert settings['ticks'] == LAST
baseline_route = Path('/dev/shm/lezac-native-upper-walk-t306/route.txt')
assert sha(baseline_route) == '6e636846b908ec7655ed6ecabc0cb96be39945f3448a74297bc23e65285f5909'
baseline_settings, baseline_events = fidelity.read_route(baseline_route)
assert settings == {**baseline_settings, 'ticks': LAST}
assert {tick: rows for tick, rows in events.items() if tick <= 11000} == baseline_events
prefix_path = PRIVATE / 'level4-t306-upper-walk-original-reference.jsonl.gz'
assert sha(prefix_path) == '710495547ef420ed076415d618ad9d552434378a22817b6a70da8b9ef9e602ec'
prefix = [fidelity.strict_json(line.decode()) for line in gzip.decompress(prefix_path.read_bytes()).splitlines()]
assert prefix[0]['expected_bytes_source'] == 'original_only' and prefix[0]['cpp_expectations_used'] is False
expected = {(row['index'], row['phase']): row for row in anchor.fixture()[1:-1]
            if row['section'] == 'level4' and row['index'] <= FIRST}
expected.update({(row['index'], row['phase']): row for row in prefix[1:-1]})
canonical = read_canonical_assets(ROOT)
CANONICAL_ASSETS = {name: dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) for name, raw in canonical.items()}
host = Path(shutil.which('dosbox')).resolve(strict=True)
HOST_PREFLIGHT = dict(path=str(host), sha256=sha(host), bytes=host.stat().st_size,
    package_version=subprocess.check_output(['dpkg-query', '-W', '-f=${Version}', 'dosbox'], text=True).strip())
assert HOST_PREFLIGHT['sha256'] == '9213fb131e11cb195bdff40c24513740ce497c5caf1cef1900ad1faad5c5026b'
base = PRIVATE / 'capture-level4-continuation-t298.py'
host_base = PRIVATE / 'capture-outside-column-host-bound-t300.py'
BASE_OBSERVER_SHA256 = '3070fded56c191eb5214c4cc2a6a91183941236f028e65681a26a38226ad3ee5'
assert sha(base) == BASE_OBSERVER_SHA256
assert sha(host_base) == 'e3313f7b33af62ebbd15fd174a60f3ad775bb5a918b1df26484c0354ee74629a'
base_tree = ast.parse(base.read_text())
classes = [node for node in base_tree.body if isinstance(node, ast.ClassDef) and node.name == 'Session']
assert len(classes) == 1
host_tree = ast.parse(host_base.read_text())
methods = [ast.literal_eval(node.value) for node in host_tree.body if isinstance(node, ast.Assign)
           and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'method']
assert len(methods) == 1
classes[0].body.append(ast.parse(methods[0]).body[0])
counts = dict(retained=0, snapshots=0, png=0, host=0, summaries=0)
class Configure(ast.NodeTransformer):
    def visit_Call(self, node):
        if isinstance(node.func, ast.Attribute) and node.func.attr in ('write_text', 'write_bytes'):
            expression = ast.unparse(node.func.value)
            if "f'boundary-" in expression or "f'ds-" in expression:
                assert len(node.args) == 1 and not node.keywords
                raw = node.args[0]
                if node.func.attr == 'write_text':
                    raw = ast.Call(func=ast.Attribute(value=raw, attr='encode', ctx=ast.Load()),
                        args=[ast.Constant('utf-8')], keywords=[])
                counts['snapshots'] += 1
                return ast.copy_location(ast.Call(func=ast.Name(id='retain_lossless', ctx=ast.Load()),
                    args=[node.func.value, raw], keywords=[]), node)
        return self.generic_visit(node)
    def visit_Assign(self, node):
        if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'retained':
            node.value = ast.parse("tick == last or (level == 4 and (tick == 9422 or tick >= FIRST))", mode='eval').body
            counts['retained'] += 1
        if len(node.targets) == 1 and ast.unparse(node.targets[0]) == "row['png']":
            counts['png'] += 1
            return [self.generic_visit(node), ast.parse("mirror_file(Path(row['png']))").body[0]]
        return self.generic_visit(node)
    def visit_Expr(self, node):
        if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute) and \
                node.value.func.attr == 'write_bytes' and 'host-binding.json' in ast.unparse(node.value.func.value):
            counts['host'] += 1
            return [self.generic_visit(node), ast.parse('mirror_metadata()').body[0]]
        if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == 'print' \
                and any(isinstance(part, ast.Name) and part.id == 'summary' for part in ast.walk(node)):
            counts['summaries'] += 1
            return ast.copy_location(ast.If(test=ast.parse("tick%100==0 and phase=='post_update'", mode='eval').body,
                body=[node], orelse=[]), node)
        return self.generic_visit(node)
tree = Configure().visit(ast.Module(body=classes, type_ignores=[]))
assert counts == dict(retained=1, snapshots=2, png=1, host=1, summaries=1), counts
ast.fix_missing_locations(tree)
exec(compile(tree, str(base), 'exec'), globals())

RUN = OUT / 'runtime'
RUN.mkdir()
for name, raw in canonical.items():
    if name != 'SETUP.LOG':
        (RUN / name).write_bytes(raw)
(OUT / 'observer.py').write_bytes(Path(__file__).read_bytes())
(OUT / 'route.txt').write_bytes(ROUTE.read_bytes())
(OUT / 'continuation-base.py').write_bytes(base.read_bytes())
(OUT / 'host-bound-base.py').write_bytes(host_base.read_bytes())
(OUT / 'verified-prefix-reference.jsonl.gz').write_bytes(prefix_path.read_bytes())
receipt = dict(pid=os.getpid(), proc_start_ticks=Path('/proc/self/stat').read_text().split()[21],
    init_start_ticks=Path('/proc/1/stat').read_text().split()[21],
    boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
    started_utc=datetime.now(timezone.utc).isoformat(), maximum_seconds=1800,
    observer_sha256=sha(Path(__file__)), source_transforms=counts, backup_root=str(DURABLE),
    synthetic_codec_controls=6, public_raw_snapshot_upload=False)
(OUT / 'launch-receipt.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
protected = {str(path): sha(path) for path in (ROUTE, ROOT / 'LEZAC.EXE', base, host_base, Path(__file__),
    *(ROOT / name for name in canonical))}
report = dict(status='running', route_sha256=sha(ROUTE), observer_sha256=sha(Path(__file__)),
    original_exe_sha256=original.EXE_SHA256, base_observer_sha256=BASE_OBSERVER_SHA256, audio='dummy',
    ordinary_gameplay_inputs_only=True, initial_rng_controlled=True, normalized_control_bank_inputs=True,
    gameplay_state_injections=False, full_guest_ram_exports=0, core_dumps=0, manual_input_claim=False,
    wall_clock_claim=False, whole_game_fidelity_claim=False, full_frame_claim=False,
    first_full_frame_tick=FIRST, last_full_frame_tick=LAST, full_frame_window_only=True,
    snapshot_storage='lossless-gzip RAM plus private compressed backups; no public raw snapshots',
    storage_readback='each encoded member equals its original complete bytes in RAM and private backup',
    storage_controls_origin='synthetic preflight; complete live original snapshots independently read back',
    private_snapshot_backup=True, durable_capture_root=str(DURABLE), public_raw_snapshot_upload=False,
    checkpoints=[], handoffs=[], protected_inputs_sha256=protected)

def save_report():
    (OUT / 'report.json').write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
    mirror_metadata()

def interrupted(*unused):
    raise TimeoutError('Bounded original capture interrupted or deadline reached')
signal.signal(signal.SIGALRM, interrupted)
signal.signal(signal.SIGTERM, interrupted)
signal.alarm(1800)
session = None
save_report()
if PREPARE:
    report.update(status='prepared_no_guest', guest_launched=False)
    save_report()
    print('capture_prepare=passed guest_launched=0 transforms=' + json.dumps(counts), flush=True)
    raise SystemExit(0)
try:
    args = argparse.Namespace(route=ROOT / 'tests/fixtures/level1_original/completion_gate/route.txt',
                              startup_seconds=10, intro_seconds=3)
    session = Session(args, RUN, OUT)
    with original.compressed_writer(OUT / 'prefix.jsonl.gz') as emit:
        assert session.capture(emit) == 305
    mirror_metadata()
    session.handoff(1)
    session.walk(731, 3094, 2, 425)
    session.handoff(2)
    session.walk(3777, 8905, 3, 1107)
    session.handoff(3)
    session.walk(9422, LAST, 4, 1623)
    report['status'] = 'original_continuation_observed'
except BaseException as error:
    report['status'] = 'incomplete'
    report['error'] = repr(error)
    raise
finally:
    signal.alarm(0)
    if session is not None:
        session.close()
        report['base_hooks_restored'] = session.restored
        report['extra_hooks_restored'] = session.extra_restored
        report['owned_child_terminal'] = session.child is None or session.child.poll() is not None
    report['protected_inputs_preserved'] = protected == {path: sha(Path(path)) for path in protected}
    save_report()
    for path in OUT.iterdir():
        if path.is_file() and path.name != 'lossless-retention.jsonl':
            mirror_file(path)
    assert (OUT / 'lossless-retention.jsonl').read_bytes() == (DURABLE / 'lossless-retention.jsonl').read_bytes()
