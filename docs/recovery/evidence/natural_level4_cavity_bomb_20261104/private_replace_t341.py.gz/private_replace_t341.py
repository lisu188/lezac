"""Bounded handling of Windows sharing violations during private atomic replacement."""
import errno
import time


def replace_retry(source, destination, replace, events, attempts=40, delay=.05):
    for attempt in range(attempts):
        try:
            result = replace(source, destination)
        except PermissionError as error:
            if error.errno not in (errno.EACCES, errno.EPERM):
                raise
            events.append(dict(destination=str(destination), attempt=attempt + 1, errno=error.errno))
            if attempt + 1 == attempts:
                raise
            time.sleep(delay)
        else:
            return result


def self_tests():
    events, calls = [], []
    def transient(source, destination):
        calls.append((source, destination))
        if len(calls) <= 3:
            raise PermissionError(errno.EACCES, 'synthetic sharing violation')
        return 'replaced'
    assert replace_retry('source', 'destination', transient, events, delay=0) == 'replaced'
    assert len(calls) == 4 and [row['attempt'] for row in events] == [1, 2, 3]
    def permanent(source, destination):
        raise PermissionError(errno.EACCES, 'synthetic permanent denial')
    try:
        replace_retry('source', 'destination', permanent, [], attempts=3, delay=0)
    except PermissionError:
        pass
    else:
        raise AssertionError('Permanent denial did not fail closed')
    for error in (OSError(errno.EIO, 'synthetic I/O error'), PermissionError(errno.ENOENT, 'synthetic non-sharing error')):
        calls = []
        def unrelated(source, destination):
            calls.append(1)
            raise error
        try:
            replace_retry('source', 'destination', unrelated, [], delay=0)
        except OSError as observed:
            assert observed is error and len(calls) == 1
        else:
            raise AssertionError('Unrelated error was swallowed')
    return ['transient_sharing_violation_retried', 'permanent_denial_fails_closed',
        'io_error_not_retried', 'non_sharing_permission_error_not_retried']
