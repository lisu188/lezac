"""Retain actual original constructor/countdown REA evidence without executing LEZAC."""
import hashlib
import json
from pathlib import Path
import resource
import shutil
import sys
import zipfile

PRIVATE = Path(__file__).parent
ROOT = Path('/mnt/c/Users/andrz/git/lezac-level4-left-demolition-20261103')
OUT = Path('/dev/shm/lezac-rea-first-blast-t344')
usage, disk = shutil.disk_usage('/dev/shm'), shutil.disk_usage(PRIVATE)
assert usage.used + 512 * 1024**2 < int(usage.total * .75)
assert disk.used + 64 * 1024**2 < int(disk.total * .90)
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
resource.setrlimit(resource.RLIMIT_FSIZE, (32 * 1024**2, 32 * 1024**2))
sys.path.insert(0, '/mnt/c/Users/andrz/git/lezac-post-render-recovery-20261025/tools')
import rea_prefix_audit as audit
helper = Path(audit.__file__)
assert hashlib.sha256(helper.read_bytes()).hexdigest() == 'acf74525b08220c0d976d10509c9d6592c772437628bc8990841356746924096'
rea = Path('/dev/shm/lezac-rea-npm-t313/_npx/a1722018f28f9df2/node_modules/rea-agents/scripts/rea.mjs')
assert rea.is_file()
audit.INSTRUCTIONS = (
    0x6c0a, 0x6c0e, 0x6c10, 0x6c13, 0x6c15, 0x6c18, 0x6c1b, 0x6c1e, 0x6c20,
    0x6c2b, 0x6c2e, 0x6c30, 0x6c32, 0x6c34, 0x6c35, 0x6c38, 0x6c3a, 0x6c3b, 0x6c3e, 0x6c41,
    0x6c5b, 0x3052, 0x75a7, 0x75aa, 0x75ad, 0x75b0, 0x75b4, 0x75cb, 0x75cf, 0x75f1)
audit.CALLS = {0x6c5b: 0x12f9f, 0x75f1: 0x1414a}
audit.run(ROOT, OUT, rea, Path('/mnt/c/Tools/ghidra_12.1.4_PUBLIC'),
    Path('/home/andrz/clion-2024.3.2/jbr'))
binary = (ROOT / 'LEZAC.EXE').read_bytes()
assert len(binary) == 52384 and hashlib.sha256(binary).hexdigest() == audit.EXE_SHA
checked = []
for offset in audit.INSTRUCTIONS:
    value = json.loads((OUT / f'instruction-{offset:04x}.json').read_bytes())['result']['structuredContent']
    assert value['subject']['digest']['sha256'] == audit.EXE_SHA
    decoded = value['normalized_result']
    content = bytes.fromhex(decoded['bytes'])
    assert content and content == binary[0x770 + offset:0x770 + offset + len(content)]
    checked.append(dict(offset=offset, evidence_id=value['evidence_id'], decoded=decoded, bytes_equal=True))
(OUT / 'byte-checks.json').write_text(json.dumps(checked, sort_keys=True, indent=2) + '\n')
(OUT / 'audit-producer.py').write_bytes(Path(__file__).read_bytes())
(OUT / 'frozen-rea-helper.py').write_bytes(helper.read_bytes())
for name in ('report.json', 'byte-checks.json'):
    destination = PRIVATE / ('level4-t344-rea-first-blast-' + name)
    raw = (OUT / name).read_bytes()
    with destination.open('xb') as output:
        output.write(raw)
    assert destination.read_bytes() == raw
files = sorted(path for path in OUT.iterdir() if path.is_file())
assert all(not path.is_symlink() and path.stat().st_size < 8 * 1024**2 for path in files)
archive = PRIVATE / 'level4-t344-rea-first-blast-evidence.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stored:
    for path in files:
        stored.write(path, path.name)
with zipfile.ZipFile(archive) as stored:
    assert len(stored.infolist()) == len(files)
    assert all(stored.read(path.name) == path.read_bytes() for path in files)
print(json.dumps(dict(status='static_original_constructor_countdown_bytes_verified', instructions=len(checked),
    direct_calls=['1000:6c5b -> 1000:2f9f', '1000:75f1 -> 1000:414a'],
    archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    all_archive_members_byte_equal=True, guest_execution=False, runtime_expiry_claim=False)), flush=True)
print(json.dumps([dict(offset=hex(row['offset']), instruction=row['decoded']['raw_disassembly'])
    for row in checked]), flush=True)
