"""Preserve the rejected call anchor and inspect the actual adjacent dispatch call."""
import ast
import hashlib
import json
from pathlib import Path
import zipfile

PRIVATE = Path(__file__).parent
SOURCE = PRIVATE / 'rea-first-blast-t344.py'
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'd51084d9ff7f136a4994f789a95162cf79d25444e0317781fbc002b620b5ddfe'
failed = Path('/dev/shm/lezac-rea-first-blast-t344')
report = json.loads((failed / 'report.json').read_bytes())
assert report['status'] == 'failed' and report['server_exit_code'] == 0
assert report['calls'][-1]['label'] == 'failure-close' and report['calls'][-1]['is_error'] is False
call = json.loads((failed / 'call-75f1.json').read_bytes())['result']['structuredContent']['normalized_result']
instruction = json.loads((failed / 'instruction-75f1.json').read_bytes())['result']['structuredContent']['normalized_result']
assert call['status'] == 'not-call' and instruction['bytes'] == '2d0c00'
archive = PRIVATE / 'level4-t344-rejected-call-anchor-evidence.zip'
files = {path.name: path for path in failed.iterdir() if path.is_file()}
files['attempt-producer.py'] = SOURCE
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stored:
    for name, path in files.items():
        stored.write(path, name)
with zipfile.ZipFile(archive) as stored:
    assert len(stored.infolist()) == len(files)
    assert all(stored.read(name) == path.read_bytes() for name, path in files.items())
print(json.dumps(dict(status='rejected_static_anchor_privately_retained', expected_call_at_75f1=False,
    actual_instruction='SUB AX,0xc', archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    all_archive_members_byte_equal=True)), flush=True)

counts = dict(instructions=0, calls=0, labels=0, call_label=0)
class Configure(ast.NodeTransformer):
    def visit_Assign(self, node):
        if len(node.targets) == 1:
            target = ast.unparse(node.targets[0])
            if target == 'audit.INSTRUCTIONS':
                node.value.elts.extend(ast.Constant(value) for value in (0x75f4, 0x75f6, 0x75fa, 0x75fb))
                counts['instructions'] += 1
            if target == 'audit.CALLS':
                node.value = ast.parse('{0x6c5b: 0x12f9f, 0x75fb: 0x1414a}', mode='eval').body
                counts['calls'] += 1
        return self.generic_visit(node)

    def visit_Constant(self, node):
        if isinstance(node.value, str):
            if node.value == '1000:75f1 -> 1000:414a':
                counts['call_label'] += 1
                return ast.copy_location(ast.Constant('1000:75fb -> 1000:414a'), node)
            if 't344' in node.value:
                counts['labels'] += 1
                return ast.copy_location(ast.Constant(node.value.replace('t344', 't344b')), node)
        return node

tree = Configure().visit(ast.parse(raw.decode(), filename=str(SOURCE)))
assert counts == dict(instructions=1, calls=1, labels=3, call_label=1), counts
ast.fix_missing_locations(tree)
exec(compile(tree, str(SOURCE), 'exec'), {'__name__': '__main__', '__file__': str(Path(__file__))})
