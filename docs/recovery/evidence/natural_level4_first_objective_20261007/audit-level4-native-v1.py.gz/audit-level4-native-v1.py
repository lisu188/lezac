"""Independently check recorded native projections against retained DS bytes."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import struct
import sys

SOURCE = Path('/dev/shm/lezac-level3-results-regression-20261006-t1')
sys.path.insert(0, str(SOURCE / 'tools'))
import level1_fidelity as fidelity
import level1_handoff as handoff
import level1_original as original


def differences(raw, state, index, role):
    assert len(raw) == 65536
    fields = [
        ('frame', 0x78c2, struct.pack('<H', state['frame'])),
        ('rng', 0x1afe, struct.pack('<I', state['rng'])),
        ('actor_count', 0x208d, bytes([state['actor_count']])),
    ]
    for field, offset, length in (
        ('globals', 0x79a0, 90), ('actors', 0x1bd4, state['actor_count'] * 38),
        ('visuals', 0xc21e, raw[0xc496] * 8), ('inventory', 0x1b6c, 12),
        ('scores', 0x785a, 92), ('destruction', 0x78c6, 4),
        ('progress', 0x2076, 36), ('spawners', 0x74c6, raw[0x79a6] * 30),
    ):
        value = bytes.fromhex(state[field])
        assert len(value) == length, (index, field, 'extent')
        fields.append((field, offset, value))
    assert len(state['players']) == 2
    for player_index, player in enumerate(state['players'], 1):
        offset = 0x1b62 + player_index * 38
        value = bytes.fromhex(player['raw'])
        assert len(value) == 38
        visual_offset = 0xc21e + raw[offset + 1] * 8
        visual = bytes.fromhex(player['visual'])
        assert len(visual) == 8
        assert player['xy'] == list(struct.unpack_from('<HH', visual))
        assert player['v'] == list(struct.unpack_from('<hh', value, 6))
        assert player['f'] == [value[10], value[12]]
        fields.extend([(f'player{player_index}_raw', offset, value),
                       (f'player{player_index}_visual', visual_offset, visual)])
    result = []
    for field, offset, value in fields:
        for relative, (actual, expected) in enumerate(zip(raw[offset:offset + len(value)], value)):
            if actual != expected:
                result.append(dict(record=index, role=role, field=field, ds_offset=offset + relative,
                                   raw=actual, projected_native=expected))
    return result


def audit(out, frames):
    reels = handoff.load(out / 'level3-results.jsonl.gz')
    entry = handoff.load(out / 'level4-handoff.jsonl.gz')
    assert len(reels) == 60 and len(entry) == frames + 2
    assert reels[-1]['gameplay_frozen'] and entry[-1]['native_level4_entry_observed']
    states = [reels[0]['baseline']] + [row['state'] for row in reels[1:-1]]
    states += [entry[0]['baseline'], entry[0]['intro']]
    states += [row[field] for row in entry[1:-1] for field in ('pre', 'rendered', 'post')]
    roles = [('gate_post', 8905, 4)] + [('result', None, 5)] * 58
    roles += [('ack', 9301, 7), ('intro', 9421, 6)]
    roles += [(role, tick, stage) for tick in range(9422, 9422 + frames)
              for role, stage in (('pre', 2), ('present', 3), ('post_update', 4))]
    journal = fidelity.strict_json((out / 'results-handoff-ds-journal.json').read_text())
    assert journal['complete'] and journal['snapshot_bytes'] == 65536
    assert journal['observation_method'] == 'stopped_single_ds_snapshot'
    assert journal['internal_projection_raw_globals_match'] is True
    assert len(states) == len(roles) == len(journal['records']) == 61 + 3 * frames
    found = []
    with gzip.open(out / 'results-handoff-ds.bin.gz', 'rb') as stream:
        previous = None
        for index, (state, record, role) in enumerate(zip(states, journal['records'], roles)):
            raw = stream.read(65536)
            assert len(raw) == 65536 and hashlib.sha256(raw).hexdigest() == record['sha256']
            assert record['index'] == index and (record['role'], record['cpp_tick'], record['stage']) == role
            assert previous is None or record['sequence'] == previous + 1
            assert record['native_frame'] == state['frame'] and record['level'] == raw[0x79b7]
            assert record['dimensions'] == ([100, 58] if index >= 60 else [150, 60])
            assert record['observation_method'] == journal['observation_method']
            assert record['internal_projection_raw_globals_match'] is True
            found.extend(differences(raw, state, index, role[0]))
            previous = record['sequence']
        assert not stream.read(1)
    return dict(status='native_snapshot_coherence_audited', boundaries=len(states),
                globals_bytes_per_boundary=90, differing_byte_observations=len(found), differences=found,
                normalized_bytes=0, raw_sha256=fidelity.sha256(out / 'results-handoff-ds.bin.gz'),
                journal_sha256=fidelity.sha256(out / 'results-handoff-ds-journal.json'),
                reader_sha256=fidelity.sha256(Path(__file__)),
                cpp_full_state_parity_claim=False, whole_game_complete=False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--frames', type=int, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    assert not args.report.exists()
    report = audit(args.out, args.frames)
    args.report.write_bytes(original.json_bytes(report))
    print(json.dumps({key: value for key, value in report.items() if key != 'differences'}), flush=True)
    assert report['differing_byte_observations'] == 0, 'native raw/projection differences retained in report'
