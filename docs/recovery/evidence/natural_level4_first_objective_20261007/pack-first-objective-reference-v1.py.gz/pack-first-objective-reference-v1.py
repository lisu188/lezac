"""Construct compact expectations only from the closed, retained atomic original capture."""
from common import *
import gzip
import importlib.util
import json

TARGET = Path('/dev/shm/lezac-level4-first-objective-regression-20261007-t1')
FIXTURE = TARGET / 'tests/fixtures/natural_level4_first_objective'
EVIDENCE = TARGET / 'docs/recovery/evidence/natural_level4_first_objective_20261007'
PREVIEWS = Path('/dev/shm/lezac-level4-first-objective-reference-pack-20261007-t1')
READER = DURABLE / 'compare-level4-native-v2.py'

protected()
assert fidelity.sha256(READER) == 'eaa9c0e49e79bcbcbbcbf6a703cd82123abffe1b5184f79b7ff16a092913790c'
assert not FIXTURE.exists() and not EVIDENCE.exists() and not PREVIEWS.exists()
assert load('capture-terminal-receipt.json')['exit_code'] == 0
assert load('keeper-terminal-receipt.json')['exit_code'] == 1
assert load('keeper-closure-proof.json')['pidfd_exit_verified'] is True
assert not Path('/proc/' + str(load('preparation-proof.json')['keeper']['identity']['pid'])).exists()
closed = load('closed-controls-retention-complete.json')
assert closed['status'] == 'native_raw_and_actual_terminal_controls_retained'
assert closed['retention']['all_notes_tree_anchors_verified'] and closed['raw_dependency']['all_member_readback_verified']
audit = load('native-coherence-v1.json')
assert audit['boundaries'] == 1078 and audit['differing_byte_observations'] == audit['normalized_bytes'] == 0
assert load('paired-comparison-v1.json')['status'] == 'match'
assert load('paired-comparison-v1-terminal.json')['exit_code'] == 0
for name in load('preparation-proof.json')['producer_hashes']:
    producer(name)
reserve(64 * 1024**2)
spec = importlib.util.spec_from_file_location('native_reference_reader', READER)
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
PREVIEWS.mkdir()
wanted = reader.native_records(OUT, PREVIEWS)
progress = reader.native_progression(wanted)
assert progress['objective_changes'] == [dict(tick=9680, objectives=1, destroyed=29,
    xy=[603.0, 400.0], health=42, reserve=0, inventory=[200, 9, 0, 0, 1], score=47590)]
header = dict(kind='header', schema='lezac-natural-level4-first-objective-v1',
    first_tick=GATE, ticks=LAST, gameplay_frames=339, frames=400, boundaries=740,
    raw_ds_boundaries=1078, repeated_original_level3_frames=5129, route_sha256=ROUTE_SHA,
    assets=load('native-audit.json')['final_mapped'] and load('preparation-proof.json')['source_head'],
    audio='dummy', state_injections=False, completed_levels=[1, 2, 3], entered_level=4,
    native_objective_changes=progress['objective_changes'],
    expectations_source='closed_retained_atomic_original_snapshots', cpp_expectations_used=False,
    full_prefix_cpp_comparison_claim=False, full_actor_clock_sound_byte_parity=False,
    level4_completion_claim=False, original_fidelity_claim=False, port_functionally_complete=False)
outcome = fidelity.strict_json((OUT / 'outcome-manifest.json').read_text())
header['assets'] = outcome['assets']
rows = [header, *wanted.values(), dict(kind='complete', frames=400, boundaries=740, patches_restored=True)]
FIXTURE.mkdir(parents=True)
with original.compressed_writer(FIXTURE / 'reference.jsonl.gz') as emit:
    for row in rows:
        emit(row)
(FIXTURE / 'route.txt').write_bytes(route_bytes())
entry = handoff.load(OUT / 'level4-handoff.jsonl.gz')
guarded = campaign.guard_inputs(entry[-2]['post'], entry[-2]['dac'][2], entry[0]['atlas'])
assert campaign.guard_projection(guarded, rows[-2]['projection']['mapped']) == 291
(FIXTURE / 'guard-input.json').write_bytes(original.json_bytes(guarded))
EVIDENCE.mkdir(parents=True)
names = [*load('preparation-proof.json')['producer_hashes'],
    'preparation-proof.json', 'native-audit.json', 'capture-terminal-receipt.json',
    'audit-level4-native-v1.py', 'native-coherence-v1.json', 'native-coherence-v1-terminal.json',
    'paired-comparison-v1.json', 'paired-comparison-v1-terminal.json', 'raw-retention-complete.json',
    'retained-inventory-v1-audit.json', 'keeper-closure-proof.json', 'keeper-terminal-receipt.json',
    'closed-controls-retention-complete.json', 'compare-level4-native-v2.py', Path(__file__).name]
pins = {}
for name in names:
    data = (DURABLE / name).read_bytes()
    (EVIDENCE / (name + '.gz')).write_bytes(gzip.compress(data, mtime=0))
    pins[name] = fidelity.sha256(DURABLE / name)
manifest = dict(schema='lezac-native-level4-first-objective-evidence-v1', reference_header=header,
    fixture_pins={name: fidelity.sha256(FIXTURE / name) for name in ('reference.jsonl.gz', 'route.txt', 'guard-input.json')},
    producer_pins=pins, raw_native_sha256=load('native-audit.json')['raw_ds_sha256'],
    raw_native_journal_sha256=load('native-audit.json')['raw_ds_journal_sha256'],
    native_stream_sha256=load('native-audit.json')['native_level4_stream_sha256'],
    snapshot_coherence_differences=0, normalized_bytes=0, closed_native_sessions=True,
    all_raw_members_independently_retained=True, expected_bytes_source='original_only')
(EVIDENCE / 'manifest.json').write_bytes(original.json_bytes(manifest))
report = dict(status='native_only_level4_first_objective_reference_packed', frames=400, boundaries=740,
    fixture_pins=manifest['fixture_pins'], manifest_sha256=fidelity.sha256(EVIDENCE / 'manifest.json'),
    producer_count=len(pins), cpp_expectations_used=False, whole_game_complete=False)
save('reference-pack-v1-report.json', report)
print(json.dumps(report), flush=True)
