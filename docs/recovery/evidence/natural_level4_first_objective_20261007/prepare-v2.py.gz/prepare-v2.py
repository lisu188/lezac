"""Freeze the observer, retained gate dependency and two-GiB capture budget."""
from common import *
import json

protected()
assert load('atomic-world-v1-test-report.json')['status'] == 'atomic_snapshot_mock_contract_passed'
assert load('atomic-world-v1-test-report.json')['source_sha256'] == ATOMIC_SHA
assert load('atomic-world-v1-test-terminal.json')['exit_code'] == 0
capacity = reserve(2 * 1024**3)
assert not OUT.exists() and not (DURABLE / 'preparation-proof.json').exists()
if WORK.exists():
    assert sorted(path.name for path in WORK.iterdir()) == [ROUTE.name]
    route_bytes()
owners = []
for path in Path('/proc').iterdir():
    if not path.name.isdigit():
        continue
    try:
        item = protocol.identity(int(path.name))
        if item['argv'] == protocol.MARKER:
            assert item['exe'] == '/usr/bin/sleep'
            owners.append(item)
    except (FileNotFoundError, ProcessLookupError, PermissionError):
        pass
assert len(owners) == 1
assert fidelity.strict_json((OLD_CONTROL / 'closed-controls-terminal-receipt.json').read_text())['exit_code'] == 0
assert fidelity.strict_json((OLD_CONTROL / 'gate-proof.json').read_text())['first_eligible_tick'] == GATE
candidate = fidelity.strict_json((SCOUT_CONTROL / 'pit-coast-v1-report.json').read_text())
assert candidate['status'] == 'closed_cpp_only_route_candidate'
assert candidate['endpoint']['level'] == 4 and candidate['endpoint']['progress'][0] == 1
assert candidate['command']['route_sha256'] == ROUTE_SHA and not candidate['original_comparison_claim']
assert fidelity.strict_json((SCOUT_CONTROL / 'pit-coast-v1-terminal.json').read_text())['exit_code'] == 0
WORK.mkdir(exist_ok=True)
if ROUTE.exists():
    assert ROUTE.read_bytes() == ROUTE_SOURCE.read_bytes()
else:
    shutil.copyfile(ROUTE_SOURCE, ROUTE)
route_bytes()
hashes = {name: fidelity.sha256(DURABLE / name) for name in
          ('common.py', 'prepare.py', 'prepare-v2.py', 'capture.py', 'private-capture.py',
           'atomic-world-v1.py', 'test-atomic-world-v1.py')}
hashes['launch-capture-v1.py'] = fidelity.sha256(DURABLE / 'launch-capture-v1.py')
dependencies = [fidelity.strict_json((OLD_CONTROL / name).read_text())['retention']
                for name in ('raw-retention-complete.json', 'closed-controls-retention-complete.json')]
transport = protocol.transport_module()
for retained in dependencies:
    for row in [retained] + retained['chunks']:
        assert transport.git(ROOT, 'ls-remote', 'origin', row['ref']).split() == [row['notes_commit'], row['ref']]
save('preparation-proof.json', dict(status='original_results_handoff_observer_prepared', capacity=capacity,
    keeper=dict(identity=owners[0], tool_session=int(sys.argv[1])), producer_hashes=hashes,
    source_head=protocol.HEAD, executable_sha256=protocol.EXE_SHA, route_sha256=ROUTE_SHA,
    prior_native_stream_sha256=NATIVE_SHA, unchanged_level3_frames=FRAMES,
    independently_retained_dependencies=dependencies, audio='dummy', new_gameplay_state_injections=False,
    original_results_and_level4_handoff_compared=False, whole_game_complete=False))
protocol.owner()
print('Owned silent results observer, unchanged gate route and capture reserve verified', flush=True)
