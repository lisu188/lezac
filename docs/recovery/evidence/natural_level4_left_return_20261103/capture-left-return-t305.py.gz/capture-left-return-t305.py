"""Observe the full ordinary-input original left-return window with lossless RAM retention."""
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import sys
import gzip

PRIVATE = Path(__file__).parent
ROOT = Path('/mnt/c/Users/andrz/git/lezac-level4-left-return-20261103')
ROUTE = Path('/dev/shm/lezac-level4-left-traverse-t304/jump_14102_fire_0/route.txt')
OUT = Path('/dev/shm/lezac-native-level4-left-return-t305')
BASE = PRIVATE / 'capture-outside-column-host-bound-t300.py'
sys.path.insert(0,str(ROOT / 'tools'))
import natural_level4_bridge_access as reference

resource.setrlimit(resource.RLIMIT_CORE,(0,0))
assert Path.cwd() == Path('/dev/shm') and not OUT.exists()
assert os.environ.get('SDL_AUDIODRIVER') == 'dummy'
usage = shutil.disk_usage('/dev/shm')
assert usage.used + 176 * 1024**2 < int(usage.total * .75)
assert hashlib.sha256(ROUTE.read_bytes()).hexdigest() == '28a4bc9d3949e09351d545d4eecd16470e9a5cde8f7fbe1743ac2c8b0b7872c7'
settings, events = reference.fidelity.read_route(ROUTE)
baseline_settings, baseline_events = reference.check_route(reference.FIXTURE / 'route.txt')
assert settings == {**baseline_settings,'ticks':14800}
assert {tick:rows for tick,rows in events.items() if tick <= 13040} == baseline_events
reference.fixture()
raw = BASE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == reference.prior.manifest()['repeat_producer_pins'][BASE.name]

# Verify the storage codec against retained original bytes, including an entire DS.
controls = {}
prior = Path('/dev/shm/lezac-native-level4-t302-floor_medium_escape_up')
for name in ('ds-13040-present.bin','ds-13220-present.bin','ds-13800-post_update.bin',
        'boundary-13040-present.json','boundary-13220-present.json','boundary-13800-post_update.json'):
    source = (prior / name).read_bytes()
    buffer = io.BytesIO()
    with gzip.GzipFile(filename='',fileobj=buffer,mode='wb',mtime=0,compresslevel=9) as target:
        target.write(source)
    encoded = buffer.getvalue()
    assert gzip.decompress(encoded) == source
    controls[name] = dict(bytes=len(source),sha256=hashlib.sha256(source).hexdigest(),
        compressed_bytes=len(encoded),compressed_sha256=hashlib.sha256(encoded).hexdigest())

changes = {
    '/mnt/c/Users/andrz/git/lezac-level4-return-portal-20261103': str(ROOT),
    "Path('/dev/shm/lezac-outside-column-t300/original-repeat')": f'Path({str(OUT)!r})',
    "ROOT / 'tests/fixtures/natural_level4_outside_column/route.txt'": f'Path({str(ROUTE)!r})',
    "{(row['index'],row['phase']): row for row in support.fixture()[1:-1] if row['section']=='level4' and row['index']<=11300}":
        "{(row['index'],row['phase']): row for row in support.fixture()[1:-1] + "
        "__import__('natural_level4_bridge_access').fixture()[1:-1] "
        "if row['section']=='level4' and row['index']<=13040}",
    "tick == last or (level == 4 and (tick == 9422 or tick >= 11300))":
        "tick == last or (level == 4 and (tick == 9422 or tick >= 13040))",
    "assert {t:r for t,r in events.items() if t<11300} == {t:r for t,r in old_events.items() if t<11300}":
        "assert {t:r for t,r in events.items() if t<=13040} == "
        "__import__('natural_level4_bridge_access').check_route(ROOT / "
        "'tests/fixtures/natural_level4_bridge_access/route.txt')[1]",
    "report.update(base_observer_sha256=BASE_OBSERVER_SHA256, first_full_frame_tick=11300,last_full_frame_tick=settings['ticks'],full_frame_window_only=True)":
        "report.update(base_observer_sha256=BASE_OBSERVER_SHA256,first_full_frame_tick=13040,"
        "last_full_frame_tick=settings['ticks'],full_frame_window_only=True,"
        "snapshot_storage='lossless-gzip RAM-only; not claimed durably retained',"
        "storage_readback='each encoded member equals its original complete bytes',"
        "full_frame_claim=False)",
}
counts = dict.fromkeys(changes,0)

helper = '''
def retain_lossless(path, raw):
    import io
    buffer = io.BytesIO()
    with gzip.GzipFile(filename='',fileobj=buffer,mode='wb',mtime=0,compresslevel=9) as target:
        target.write(raw)
    encoded = buffer.getvalue()
    assert gzip.decompress(encoded) == raw
    destination = path.with_name(path.name + '.gz')
    assert not destination.exists() and destination.parent == OUT
    usage = shutil.disk_usage('/dev/shm')
    assert usage.used + len(encoded) + 4*1024**2 < int(usage.total*.75)
    destination.write_bytes(encoded)
    stored = destination.read_bytes()
    assert stored == encoded and gzip.decompress(stored) == raw
    metadata = dict(path=destination.name,source_bytes=len(raw),source_sha256=hashlib.sha256(raw).hexdigest(),
        encoded_bytes=len(stored),encoded_sha256=hashlib.sha256(stored).hexdigest(),readback_equal=True)
    with (OUT / 'lossless-retention.jsonl').open('a') as log:
        log.write(json.dumps(metadata,sort_keys=True) + '\\n')
'''

def finalize_capture(tree):
    class Retention(ast.NodeTransformer):
        def __init__(self):
            self.changed = []
        def visit_Call(self,node):
            if isinstance(node.func,ast.Attribute) and node.func.attr in ('write_text','write_bytes'):
                expression = ast.unparse(node.func.value)
                if "f'boundary-" in expression or "f'ds-" in expression:
                    assert len(node.args) == 1 and not node.keywords
                    data = node.args[0]
                    if node.func.attr == 'write_text':
                        data = ast.Call(func=ast.Attribute(value=data,attr='encode',ctx=ast.Load()),
                            args=[ast.Constant('utf-8')],keywords=[])
                    self.changed.append(expression)
                    return ast.copy_location(ast.Call(func=ast.Name(id='retain_lossless',ctx=ast.Load()),
                        args=[node.func.value,data],keywords=[]),node)
            return self.generic_visit(node)
    transform = Retention()
    tree = transform.visit(tree)
    assert len(transform.changed) == 2,transform.changed
    tree.body[0:0] = ast.parse(helper).body
    ast.fix_missing_locations(tree)
    return tree

class Configure(ast.NodeTransformer):
    finalize = 0
    def visit_Constant(self,node):
        if isinstance(node.value,str) and node.value in changes:
            counts[node.value] += 1
            return ast.copy_location(ast.Constant(changes[node.value]),node)
        return node
    def visit_Assign(self,node):
        if len(node.targets) == 1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id == 'tree' \
                and isinstance(node.value,ast.Call) and ast.unparse(node.value.func) == 'config.visit':
            node.value = ast.Call(func=ast.Name(id='finalize_capture',ctx=ast.Load()),args=[node.value],keywords=[])
            self.finalize += 1
        return self.generic_visit(node)

transform = Configure()
tree = transform.visit(ast.parse(raw.decode(),filename=str(BASE)))
assert set(counts.values()) == {1} and transform.finalize == 1,(counts,transform.finalize)
ast.fix_missing_locations(tree)

def expired(*unused):
    raise TimeoutError('Original left-return capture exceeded its bounded deadline')

signal.signal(signal.SIGALRM,expired)
signal.alarm(1800)
try:
    exec(compile(tree,str(BASE),'exec'),{'__name__':'__main__','__file__':str(Path(__file__)),
        'finalize_capture':finalize_capture})
finally:
    signal.alarm(0)
    if OUT.exists():
        (OUT / 'storage-controls.json').write_text(json.dumps(controls,sort_keys=True,indent=2)+'\n')
        (OUT / 'host-bound-base.py').write_bytes(raw)
        (OUT / 'continuation-base.py').write_bytes((PRIVATE / 'capture-level4-continuation-t298.py').read_bytes())
