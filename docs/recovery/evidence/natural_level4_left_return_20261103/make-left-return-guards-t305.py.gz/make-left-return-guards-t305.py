"""Retain baseline/final CPP mutation stimuli without changing original expectations."""
import gzip
import hashlib
import json
from pathlib import Path
import sys
import zipfile

PRIVATE = Path(__file__).parent
ROOT = Path('/mnt/c/Users/andrz/git/lezac-level4-left-return-20261103')
sys.path.insert(0,str(ROOT/'tools'))
import natural_level4_left_return as reader
sha = lambda raw: hashlib.sha256(raw).hexdigest()
reference = (reader.FIXTURE/'reference.jsonl.gz').read_bytes()
wanted = {(row['index'],row['phase']):row for row in reader.fixture()[1:-1]}
with zipfile.ZipFile(PRIVATE/'level4-t305-linux-13040-13159.zip') as archive:
    baseline = archive.read('run/trace.jsonl')
final = Path('/dev/shm/lezac-level4-left-traverse-t304/jump_14102_fire_0/run/trace.jsonl').read_bytes()
inputs = []
for tick,raw in ((13040,baseline),(14800,final)):
    rows = [json.loads(line) for line in raw.splitlines()]
    item = next(row for row in rows if row.get('tick')==tick and row.get('phase')=='post_update')
    reader.support.recovered.check_cpp(item['state'],wanted[tick,'post_update'])
    inputs.append(dict(kind='cpp_typed_mutation_stimulus_only',index=tick,phase='post_update',state=item['state']))
encoded = gzip.compress(b''.join(reader.original.json_bytes(row) for row in inputs),compresslevel=9,mtime=0)
(reader.FIXTURE/'guard-inputs.jsonl.gz').write_bytes(encoded)
source = Path(__file__).read_bytes()
path = reader.EVIDENCE/(Path(__file__).name+'.gz')
path.write_bytes(gzip.compress(source,compresslevel=9,mtime=0))
metadata = json.loads((reader.EVIDENCE/'manifest.json').read_bytes())
metadata['guard_input_source'] = dict(kind='cpp_typed_mutation_stimulus_only',expected_bytes_source=False,
    indices=reader.INDICES,phase='post_update',cpp_trace_sha256=[sha(baseline),sha(final)],
    cpp_executable_sha256='7b7007e505ee67eeb664faf23926a222dafe3a40ba4c22e58b2c2ce33a14a114')
metadata['guard_producer_pins'] = {Path(__file__).name:sha(source)}
metadata['evidence_file_pins'][path.name] = sha(path.read_bytes())
metadata['fixture_pins']['guard-inputs.jsonl.gz'] = sha(encoded)
(reader.EVIDENCE/'manifest.json').write_bytes(reader.original.json_bytes(metadata))
assert (reader.FIXTURE/'reference.jsonl.gz').read_bytes()==reference
print(json.dumps(dict(manifest_sha256=sha((reader.EVIDENCE/'manifest.json').read_bytes()),
    original_reference_unchanged=True,stimuli=len(inputs))),flush=True)
