"""Pack and independently audit original-only left-return observations; never read CPP output."""
import ast
import gzip
import hashlib
import json
from pathlib import Path

PRIVATE = Path(__file__).parent
ROOT = Path('/mnt/c/Users/andrz/git/lezac-level4-left-return-20261103')
NATIVE = Path('/dev/shm/lezac-native-level4-left-return-t305')
BASE = PRIVATE/'pack-native-bridge-escape-t302.py'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
capture = json.loads((NATIVE/'report.json').read_bytes())
assert capture['status']=='original_continuation_observed' and capture['owned_child_terminal']
assert (capture['first_full_frame_tick'],capture['last_full_frame_tick'])==(13040,14800)
assert capture['snapshot_storage']=='lossless-gzip RAM-only; not claimed durably retained'
assert capture['full_frame_claim'] is False
assert sha((NATIVE/'observer.py').read_bytes())==capture['observer_sha256']=='5af2ded1d67b482f430d9f28fe647ccf6e34e3fbd05c643709a9e2e3b1b3df0f'
checkpoints = {(row['tick'],row['phase']):row for row in capture['checkpoints']}
assert len(checkpoints)==len(capture['checkpoints'])==3528
records = [json.loads(line) for line in (NATIVE/'lossless-retention.jsonl').read_text().splitlines()]
assert len(records)==len(checkpoints)*2
expected_paths = {f'{prefix}-{tick}-{phase}.{suffix}.gz' for tick,phase in checkpoints
    for prefix,suffix in (('boundary','json'),('ds','bin'))}
assert {row['path'] for row in records}==expected_paths and len(expected_paths)==len(records)
for row in records:
    assert set(row)=={'path','source_bytes','source_sha256','encoded_bytes','encoded_sha256','readback_equal'}
    path = NATIVE/row['path']
    assert path.parent==NATIVE and not path.is_symlink()
    stored = path.read_bytes()
    raw = gzip.decompress(stored)
    assert (len(stored),sha(stored))==(row['encoded_bytes'],row['encoded_sha256'])
    assert (len(raw),sha(raw))==(row['source_bytes'],row['source_sha256']) and row['readback_equal'] is True

def verify_record(tick,phase,observed,raw,projection,rgb):
    live = checkpoints[tick,phase]
    assert observed['sequence']==live['sequence'] and observed['ds_sha256']==live['ds_sha256']==sha(raw)
    assert live['original_observation'] is True and observed['original_observation'] is True
    assert live['mapped']=={key:projection['mapped'][key] for key in ('frame','rng','progress','players')}
    assert projection['mapped']['frame']==tick-1623 and projection['mapped']['level']==4
    if phase=='present':
        path = NATIVE/f'original-level4-t298-{tick}-present.png'
        assert rgb==live['rgb_sha256'] and sha(path.read_bytes())==live['png_sha256']
        assert live['png']==str(path)
    else:
        assert rgb is None

values = {
    '/mnt/c/Users/andrz/git/lezac-level4-final-demolition-20261103':str(ROOT),
    '/dev/shm/lezac-native-level4-t302-floor_medium_escape_up':str(NATIVE),
    'tests/fixtures/natural_level4_bridge_escape':'tests/fixtures/natural_level4_left_return',
    'docs/recovery/evidence/natural_level4_bridge_escape_20261103':'docs/recovery/evidence/natural_level4_left_return_20261103',
    '5fc39ddfea7b0a662d3decf83913aaf81a6d60d8b6a4b42d6c9265dc9f1d58d1':
        '28a4bc9d3949e09351d545d4eecd16470e9a5cde8f7fbe1743ac2c8b0b7872c7',
    'lezac-natural-level4-bridge-escape-v1':'lezac-natural-level4-left-return-v1',
    'lezac-native-bridge-escape-ds-audit-v1':'lezac-native-left-return-ds-audit-v1',
    'lezac-native-level4-bridge-escape-evidence-v1':'lezac-native-level4-left-return-evidence-v1',
    '/dev/shm/lezac-level4-drop-rea-t302/report.json':'/dev/shm/lezac-left-return-rea-t305/report.json',
    '/dev/shm/lezac-level4-drop-rea-t302':'/dev/shm/lezac-left-return-rea-t305',
    'rea-level4-drop-t302.py':'rea-left-return-t305.py',
    'capture-level4-final-t302.py':'capture-left-return-t305.py',
    13800:14800,13801:14801,761:1761,1522:3522,1524:3524,
}
changed = set()
class Configure(ast.NodeTransformer):
    reads = calls = sources = 0
    def visit_Constant(self,node):
        if isinstance(node.value,(str,int)) and node.value in values:
            changed.add(node.value)
            return ast.copy_location(ast.Constant(values[node.value]),node)
        return node
    def visit_Call(self,node):
        if isinstance(node.func,ast.Attribute) and node.func.attr=='read_bytes' and \
                any(token in ast.unparse(node.func.value) for token in ("f'boundary-","f'ds-")):
            path = node.func.value
            assert isinstance(path,ast.BinOp) and isinstance(path.right,ast.JoinedStr)
            assert isinstance(path.right.values[-1],ast.Constant)
            path.right.values[-1].value += '.gz'
            self.reads += 1
            return ast.copy_location(ast.Call(func=ast.Attribute(value=ast.Name(id='gzip',ctx=ast.Load()),
                attr='decompress',ctx=ast.Load()),args=[node],keywords=[]),node)
        return self.generic_visit(node)
    def visit_Assign(self,node):
        if len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
            name = node.targets[0].id
            if name=='row' and isinstance(node.value,ast.Call):
                self.calls += 1
                audit = ast.parse('verify_record(tick,phase,observed,raw,projection,rgb)').body[0]
                return [self.generic_visit(node),audit]
            if name=='sources' and isinstance(node.value,ast.List):
                self.sources += 1
                node.value.elts.append(ast.parse(f'Path({str(BASE)!r})',mode='eval').body)
        return self.generic_visit(node)

raw = BASE.read_bytes()
transform = Configure()
tree = transform.visit(ast.parse(raw.decode(),filename=str(BASE)))
assert changed==set(values) and (transform.reads,transform.calls,transform.sources)==(2,1,1),(
    changed,set(values),transform.reads,transform.calls,transform.sources)
ast.fix_missing_locations(tree)
namespace = {'__name__':'__main__','__file__':str(Path(__file__)),'verify_record':verify_record}
exec(compile(tree,str(BASE),'exec'),namespace)
retain,manifest = namespace['retain'],namespace['manifest']
for source,destination in (('storage-controls.json','storage-controls.json.gz'),
        ('lossless-retention.jsonl','lossless-retention.jsonl.gz')):
    retain(destination,(NATIVE/source).read_bytes(),True)
for name in ('test-left-retention-t305.py',):
    raw = (PRIVATE/name).read_bytes()
    retain(name+'.gz',raw,True)
    manifest['producer_pins'][name]=sha(raw)
retain('storage-control-tests.json.gz',(PRIVATE/'left-retention-t305-tests.json').read_bytes(),True)
retain('storage-control-tests.log.gz',(PRIVATE/'left-retention-t305-tests.log').read_bytes(),True)
manifest['raw_ds_snapshot_retention']=capture['snapshot_storage']
manifest['lossless_retention_members']=len(records)
manifest['all_compressed_members_independently_decoded']=True
manifest['original_pngs_bound_to_live_receipt']=True
namespace['audit_report'].update(lossless_retention_members=len(records),compressed_member_readback_differences=0)
retain('native-audit.json.gz',namespace['prior'].original.json_bytes(namespace['audit_report']),True)
(namespace['EVIDENCE']/'manifest.json').write_bytes(namespace['prior'].original.json_bytes(manifest))
print(json.dumps(dict(manifest_sha256=sha((namespace['EVIDENCE']/'manifest.json').read_bytes()),
    original_frames=1761,original_boundaries=3522,lossless_members=len(records),
    independent_ds_redecode_differences=0,original_png_receipt_differences=0)),flush=True)
