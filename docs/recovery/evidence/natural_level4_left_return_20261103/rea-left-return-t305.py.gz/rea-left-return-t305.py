"""Read original player flame-impulse instructions with actual REA/Ghidra on WSL."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path('/mnt/c/Users/andrz/git/lezac-level4-left-return-20261103')
OUT = Path('/dev/shm/lezac-left-return-rea-t305')
PRIVATE = Path(__file__).parent
usage = shutil.disk_usage('/dev/shm')
assert usage.used + 160*1024**2 < int(usage.total*.75)
sys.path.insert(0,'/mnt/c/Users/andrz/git/lezac-post-render-recovery-20261025/tools')
import rea_prefix_audit as audit
assert hashlib.sha256(Path(audit.__file__).read_bytes()).hexdigest() == 'acf74525b08220c0d976d10509c9d6592c772437628bc8990841356746924096'
scripts = list(Path('/dev/shm/lezac-rea-npm-t301/_npx').glob('*/node_modules/rea-agents/scripts/rea.mjs'))
assert len(scripts) == 1
audit.INSTRUCTIONS = (0x6f90,0x6f93,0x6f98,0x6fa6,0x6fb0,0x6fb3,0x6fc5,0x6fc9,
    0x6fca,0x6fcd,0x6fd3,0x6fd7,0x6fd8,0x6fdb,0x6ff9,0x7011)
audit.CALLS = {0x6fa6:0x156b6,0x6fb0:0x13a56}
audit.run(ROOT,OUT,scripts[0],Path('/mnt/c/Tools/ghidra_12.1.4_PUBLIC'),
    Path('/home/andrz/clion-2024.3.2/jbr'))
binary = (ROOT / 'LEZAC.EXE').read_bytes()
assert len(binary) == 52384
checked = []
for offset in audit.INSTRUCTIONS:
    value = json.loads((OUT / f'instruction-{offset:04x}.json').read_bytes())['result']['structuredContent']
    decoded = value['normalized_result']
    code = bytes.fromhex(decoded['bytes'])
    assert code == binary[0x770+offset:0x770+offset+len(code)]
    checked.append(dict(offset=offset,evidence_id=value['evidence_id'],decoded=decoded,bytes_equal=True))
(OUT / 'byte-checks.json').write_text(json.dumps(checked,sort_keys=True,indent=2)+'\n')
for name in ('report.json','byte-checks.json'):
    data = (OUT / name).read_bytes()
    assert len(data) <= 65536
    path = PRIVATE / ('level4-t305-rea-left-return-'+name)
    assert not path.exists()
    path.write_bytes(data)
print(json.dumps([dict(offset=hex(row['offset']),instruction=row['decoded']['raw_disassembly']) for row in checked]),flush=True)
