"""Exercise the frozen live capture's lossless storage helper without launching a guest."""
import ast
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest import mock

PRIVATE = Path(__file__).parent
NATIVE = Path('/dev/shm/lezac-native-level4-left-return-t305')
source = (NATIVE/'observer.py').read_bytes()
module = ast.parse(source.decode())
values = [ast.literal_eval(node.value) for node in module.body if isinstance(node,ast.Assign) and
    any(isinstance(target,ast.Name) and target.id=='helper' for target in node.targets)]
assert len(values)==1
HELPER = compile(values[0],'frozen-left-return-retention','exec')

class StorageTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='codec-controls-',dir='/dev/shm/lezac-left-return-t305-temp')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.namespace = dict(OUT=self.root,gzip=gzip,shutil=shutil,json=json,hashlib=hashlib)
        exec(HELPER,self.namespace)
        self.retain = self.namespace['retain_lossless']

    def test_complete_source_bytes_and_metadata_roundtrip(self):
        payloads = [b'',bytes(65536),bytes(range(256))*256,b'{"text":"ASCII"}\n']
        prior = Path('/dev/shm/lezac-native-level4-t302-floor_medium_escape_up')
        payloads.append((prior/'ds-13800-post_update.bin').read_bytes())
        for index,raw in enumerate(payloads):
            self.retain(self.root/f'case-{index}.bin',raw)
            path = self.root/f'case-{index}.bin.gz'
            stored = path.read_bytes()
            self.assertEqual(gzip.decompress(stored),raw)
            self.assertEqual(stored[:10],bytes.fromhex('1f8b08000000000002ff'))
        rows = [json.loads(line) for line in (self.root/'lossless-retention.jsonl').read_text().splitlines()]
        self.assertEqual(len(rows),len(payloads))
        for index,(row,raw) in enumerate(zip(rows,payloads)):
            stored = (self.root/row['path']).read_bytes()
            self.assertEqual(row,dict(path=f'case-{index}.bin.gz',source_bytes=len(raw),
                source_sha256=hashlib.sha256(raw).hexdigest(),encoded_bytes=len(stored),
                encoded_sha256=hashlib.sha256(stored).hexdigest(),readback_equal=True))

    def test_existing_member_is_preserved(self):
        target = self.root/'preserved.bin.gz'
        target.write_bytes(b'preserve existing bytes')
        with self.assertRaises(AssertionError):
            self.retain(self.root/'preserved.bin',b'new bytes')
        self.assertEqual(target.read_bytes(),b'preserve existing bytes')
        self.assertFalse((self.root/'lossless-retention.jsonl').exists())

    def test_path_escape_is_rejected(self):
        with self.assertRaises(AssertionError):
            self.retain(self.root/'missing-parent'/'escape.bin',b'new bytes')
        self.assertFalse((self.root/'missing-parent').exists())

    def test_reserve_exhaustion_writes_nothing(self):
        usage = shutil.disk_usage('/dev/shm')
        limit = usage._replace(used=int(usage.total*.75),free=usage.total-int(usage.total*.75))
        with mock.patch.object(shutil,'disk_usage',return_value=limit),self.assertRaises(AssertionError):
            self.retain(self.root/'capacity.bin',bytes(65536))
        self.assertEqual(list(self.root.iterdir()),[])

    def test_bad_decode_is_rejected_before_storage(self):
        with mock.patch.object(gzip,'decompress',return_value=b'wrong'),self.assertRaises(AssertionError):
            self.retain(self.root/'invalid.bin',b'expected')
        self.assertEqual(list(self.root.iterdir()),[])

    def test_readback_mismatch_has_no_success_receipt(self):
        original = Path.read_bytes
        def mismatch(path):
            raw = original(path)
            return bytes((raw[0]^1,))+raw[1:] if path.name=='changed.bin.gz' else raw
        with mock.patch.object(Path,'read_bytes',mismatch),self.assertRaises(AssertionError):
            self.retain(self.root/'changed.bin',b'expected')
        self.assertTrue((self.root/'changed.bin.gz').is_file())
        self.assertFalse((self.root/'lossless-retention.jsonl').exists())

output = io.StringIO()
result = unittest.TextTestRunner(stream=output,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(StorageTests))
report = dict(tests=result.testsRun,passed=result.wasSuccessful(),
    observer_sha256=hashlib.sha256(source).hexdigest(),helper_sha256=hashlib.sha256(values[0].encode()).hexdigest(),
    guest_launched=False,raw_guest_memory_published=False)
(PRIVATE/'left-retention-t305-tests.log').write_text(output.getvalue())
(PRIVATE/'left-retention-t305-tests.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
assert result.wasSuccessful(),output.getvalue()
print(json.dumps(report),flush=True)
