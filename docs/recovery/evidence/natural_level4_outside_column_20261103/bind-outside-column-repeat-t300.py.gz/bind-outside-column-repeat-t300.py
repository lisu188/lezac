"""Bind the frozen original expectations to an independently host-qualified repeat."""
import ast
import gzip
import hashlib
import json
from pathlib import Path
import struct
import sys

ROOT = Path('/mnt/c/Users/andrz/git/lezac-level4-return-portal-20261103')
PRIVATE = Path(__file__).parent
CAPTURE = Path('/dev/shm/lezac-outside-column-t300/original-repeat')
EVIDENCE = ROOT / 'docs/recovery/evidence/natural_level4_outside_column_20261103'
FIXTURE = ROOT / 'tests/fixtures/natural_level4_outside_column'
sys.path.insert(0, str(ROOT / 'tools'))
import level1_fidelity as fidelity
import level1_original as original
import level1_handoff as handoff
import natural_level4_support_column as support
from original_capture_contract import ASSET_PINS
from PIL import Image

sha = lambda data: hashlib.sha256(data).hexdigest()
manifest_path = EVIDENCE / 'manifest.json'
assert sha(manifest_path.read_bytes()) == 'b43dca0d5d4111c10df44b4ab90293a99bb68aa1a5b1320f9d159cbc783bd7d8'
metadata = fidelity.strict_json(manifest_path.read_text())
reference = (FIXTURE / 'reference.jsonl.gz').read_bytes()
assert sha(reference) == metadata['fixture_pins']['reference.jsonl.gz']
rows = handoff.load(FIXTURE / 'reference.jsonl.gz')
capture = fidelity.strict_json((CAPTURE / 'report.json').read_text())
assert capture['status'] == 'original_continuation_observed'
assert all(capture[key] for key in ('base_hooks_restored', 'extra_hooks_restored', 'owned_child_terminal',
    'protected_inputs_preserved', 'initial_rng_controlled', 'normalized_control_bank_inputs'))
binding = fidelity.strict_json((CAPTURE / 'host-binding.json').read_text())
assert binding['host']['sha256'] == binding['actual_host_sha256'] == binding['prefix_header']['dosbox_sha256'] == \
    '9213fb131e11cb195bdff40c24513740ce497c5caf1cef1900ad1faad5c5026b'
assert binding['observer_sha256'] == capture['observer_sha256'] == sha(
    (PRIVATE / 'capture-outside-column-host-bound-t300.py').read_bytes())
assert capture['route_sha256'] == sha((CAPTURE / 'route.txt').read_bytes()) == metadata['fixture_pins']['route.txt']
for name in binding['copied_assets']:
    data = (CAPTURE / 'runtime' / name).read_bytes()
    assert (len(data), sha(data)) == ASSET_PINS[name]

source = gzip.decompress((EVIDENCE / 'pack-outside-column-t300.py.gz').read_bytes())
assert sha(source) == metadata['producer_pins']['pack-outside-column-t300.py']
functions = [node for node in ast.parse(source.decode()).body
             if isinstance(node, ast.FunctionDef) and node.name == 'state_from_ds']
assert len(functions) == 1
namespace = dict(original=original, struct=struct)
exec(compile(ast.Module(body=functions, type_ignores=[]), 'frozen-original-ds-decoder', 'exec'), namespace)
audits = []
for row in rows[1:-1]:
    tick, phase = row['index'], row['phase']
    observed = fidelity.strict_json((CAPTURE / f'boundary-{tick}-{phase}.json').read_text())
    assert observed['projection'] == row['projection'], (tick, phase, 'repeat projection')
    raw = (CAPTURE / f'ds-{tick}-{phase}.bin').read_bytes()
    assert len(raw) == 65536 and sha(raw) == observed['ds_sha256']
    state = namespace['state_from_ds'](raw)
    mapped = original.project_original(state, 1, original.word(raw, 0x2070))
    del mapped['tiles_hex'], mapped['words_hex']
    mapped.update(level=4, score=int.from_bytes(raw[0x785A:0x785E], 'little'),
        p2_inventory=list(raw[0x1B70:0x1B74]) + [raw[0x1B75] - 1], red_phase=raw[0x79AD])
    assert mapped == {key: value for key, value in observed['projection']['mapped'].items()
                      if key not in ('tiles_hex', 'words_hex', 'palette')}
    independent = dict(lifecycle=support.recovered.returned.native_lifecycle(state),
        monsters=support.recovered.projection.native_monsters(state, support.recovered.PROFILES[4]),
        markers=support.recovered.projection.native_markers(state),
        terrain=support.recovered.projection.native_terrain(raw))
    assert independent == {key: value for key, value in observed['projection'].items() if key != 'mapped'}
    rgb = None
    if phase == 'present':
        pixels = Image.open(CAPTURE / f'original-level4-t298-{tick}-present.png').convert('RGB').tobytes()
        assert len(pixels) == 192000
        rgb = sha(pixels)
    assert rgb == row['rgb_sha256']
    audits.append(dict(index=tick, phase=phase, native_sequence=observed['sequence'],
        ds_sha256=sha(raw), projection_sha256=sha(original.json_bytes(observed['projection'])), rgb_sha256=rgb))
assert len(audits) == 1602
audit = dict(schema='lezac-native-outside-column-bound-repeat-v1', frames=801, boundaries=1602,
    original_reference_unchanged=True, projected_differences=0, rgb_differences=0,
    ds_redecode_differences=0, raw_ds_snapshots_published=False, records=audits)

def retain(name, data, compressed=True):
    target = EVIDENCE / name
    assert not target.exists()
    target.write_bytes(gzip.compress(data, mtime=0) if compressed else data)
    metadata['evidence_file_pins'][name] = sha(target.read_bytes())


retain('repeat-capture-report.json.gz', (CAPTURE / 'report.json').read_bytes())
retain('repeat-host-binding.json.gz', (CAPTURE / 'host-binding.json').read_bytes())
retain('repeat-audit.json.gz', original.json_bytes(audit))
retain('repeat-dosbox.conf', (CAPTURE / 'dosbox.conf').read_bytes(), compressed=False)
producers = [PRIVATE / 'capture-outside-column-host-bound-t300.py', Path(__file__), ROOT / 'tools/original_capture_contract.py']
metadata['repeat_producer_pins'] = {}
for path in producers:
    retain(path.name + '.gz', path.read_bytes())
    metadata['repeat_producer_pins'][path.name] = sha(path.read_bytes())
metadata['repeat_capture'] = dict(host=binding['host'], frames=801, boundaries=1602,
    reference_sha256=sha(reference), reference_unchanged=True, raw_ds_snapshots_published=False,
    config_sha256=sha((CAPTURE / 'dosbox.conf').read_bytes()),
    loader_sha256=sha(original.resident_program()), source_capture=str(CAPTURE))
manifest_path.write_bytes(json.dumps(metadata, sort_keys=True, separators=(',', ':')).encode() + b'\n')
assert (FIXTURE / 'reference.jsonl.gz').read_bytes() == reference
print(json.dumps(dict(manifest_sha256=sha(manifest_path.read_bytes()), repeat_frames=801,
                      repeated_boundaries=1602, original_reference_unchanged=True)))
