"""Run a separate full-frame original replay of the 261-tile C++ candidate."""
import ast
import hashlib
from pathlib import Path

base = Path(__file__).with_name('capture-level4-preportal-t299.py')
raw = base.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '049c2cfc7e10ed439691e6d43c8b214c63cbfe3a40de434f280342d9449d1fdf'


class Configure(ast.NodeTransformer):
    def __init__(self):
        self.replacements = set()

    def visit_Constant(self, node):
        changes = {
            "Path('/dev/shm/lezac-native-level4-preportal-t299')":
                "Path('/dev/shm/lezac-native-level4-outside-pillar-t299')",
            "Path('/dev/shm/lezac-level4-preportal-t299/preportal_left_jump/route.txt')":
                "Path('/dev/shm/lezac-level4-outside-pillar-t299/outside_pillar_standing_medium/route.txt')",
        }
        if isinstance(node.value, str) and node.value in changes:
            self.replacements.add(node.value)
            return ast.copy_location(ast.Constant(changes[node.value]), node)
        return node


tree = ast.parse(raw.decode(), filename=str(base))
config = Configure()
tree = config.visit(tree)
assert len(config.replacements) == 2
ast.fix_missing_locations(tree)
exec(compile(tree, str(base), 'exec'), {'__name__': '__main__', '__file__': str(Path(__file__))})
