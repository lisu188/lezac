"""Configure the audited native observer for every frame of the preportal branch."""
import ast
import hashlib
from pathlib import Path

PRIVATE = Path(__file__).parent
base = PRIVATE / 'capture-level4-continuation-t298.py'
raw = base.read_bytes()
BASE_SHA = '3070fded56c191eb5214c4cc2a6a91183941236f028e65681a26a38226ad3ee5'
assert hashlib.sha256(raw).hexdigest() == BASE_SHA
ROOT = Path('/mnt/c/Users/andrz/git/lezac-level4-return-portal-20261103')


class Configure(ast.NodeTransformer):
    def __init__(self):
        self.assignments, self.prefix_check, self.verbose_prints = set(), 0, 0

    def visit_Assign(self, node):
        if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            expressions = {
                'ROOT': f'Path({str(ROOT)!r})',
                'OUT': "Path('/dev/shm/lezac-native-level4-preportal-t299')",
                'ROUTE': "Path('/dev/shm/lezac-level4-preportal-t299/preportal_left_jump/route.txt')",
                'expected': "{(row['index'], row['phase']): row for row in support.fixture()[1:-1] "
                            "if row['section'] == 'level4' and row['index'] <= 11300}",
                'retained': "tick == last or (level == 4 and (tick == 9422 or tick >= 11300))",
            }
            if name in expressions:
                node.value = ast.parse(expressions[name], mode='eval').body
                self.assignments.add(name)
            if name == 'report':
                additions = ast.parse("report.update(base_observer_sha256=BASE_OBSERVER_SHA256, "
                    "first_full_frame_tick=11300, last_full_frame_tick=settings['ticks'], "
                    "full_frame_window_only=True)").body
                return [self.generic_visit(node), *additions]
        return self.generic_visit(node)

    def visit_Assert(self, node):
        if any(isinstance(part, ast.Name) and part.id == 'old_events' for part in ast.walk(node)):
            self.prefix_check += 1
            return ast.copy_location(ast.parse(
                "assert {tick: rows for tick, rows in events.items() if tick < 11300} == "
                "{tick: rows for tick, rows in old_events.items() if tick < 11300}").body[0], node)
        return self.generic_visit(node)

    def visit_Expr(self, node):
        if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and \
                node.value.func.id == 'print' and any(isinstance(part, ast.Name) and part.id == 'summary'
                                                     for part in ast.walk(node)):
            self.verbose_prints += 1
            return ast.copy_location(ast.If(test=ast.parse(
                "tick % 50 == 0 and phase == 'post_update'", mode='eval').body,
                body=[node], orelse=[]), node)
        return self.generic_visit(node)


tree = ast.parse(raw.decode(), filename=str(base))
config = Configure()
tree = config.visit(tree)
assert config.assignments == {'ROOT', 'OUT', 'ROUTE', 'expected', 'retained'}
assert config.prefix_check == config.verbose_prints == 1
ast.fix_missing_locations(tree)
exec(compile(tree, str(base), 'exec'), {'__name__': '__main__', '__file__': str(Path(__file__)),
                                      'BASE_OBSERVER_SHA256': BASE_SHA})
