"""Repeat the original window with explicit canonical assets and live host/launch binding."""
import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

PRIVATE = Path(__file__).parent
ROOT = Path('/mnt/c/Users/andrz/git/lezac-level4-return-portal-20261103')
sys.path.insert(0, str(ROOT / 'tools'))
from original_capture_contract import ASSET_PINS, read_canonical_assets

canonical = read_canonical_assets(ROOT)
host = Path(shutil.which('dosbox')).resolve(strict=True)
HOST = dict(path=str(host), sha256=hashlib.sha256(host.read_bytes()).hexdigest(),
    bytes=host.stat().st_size,
    package_version=subprocess.check_output(['dpkg-query', '-W', '-f=${Version}', 'dosbox'], text=True).strip())
assert HOST['sha256'] == '9213fb131e11cb195bdff40c24513740ce497c5caf1cef1900ad1faad5c5026b'
ASSETS = {name: dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()) for name, raw in canonical.items()}
base = PRIVATE / 'capture-level4-continuation-t298.py'
raw = base.read_bytes()
BASE_SHA = '3070fded56c191eb5214c4cc2a6a91183941236f028e65681a26a38226ad3ee5'
assert hashlib.sha256(raw).hexdigest() == BASE_SHA

method = '''
def capture(self, emit):
    def bound_emit(row):
        if row['kind'] == 'header':
            process = Path('/proc') / str(self.child.pid)
            actual_host = process / 'exe'
            assert str(actual_host.resolve()) == HOST_PREFLIGHT['path']
            assert sha(actual_host) == row['dosbox_sha256'] == HOST_PREFLIGHT['sha256']
            actual_argv = [value.decode() for value in (process / 'cmdline').read_bytes().split(b'\\0') if value]
            assert actual_argv == self.child.args
            expected_argv = ['dosbox', '-conf', str(self.output / 'dosbox.conf'), '-c',
                'mount c ' + str(self.run), '-c', 'c:', '-c', 'L1ORACLE.COM', '-c', 'LEZAC.EXE']
            assert actual_argv == expected_argv
            cwd = (process / 'cwd').resolve()
            assert cwd == self.output.parent and cwd.is_relative_to(Path('/dev/shm'))
            assert str(self.xdo('getwindowpid', self.window)) == str(self.child.pid)
            geometry = dict(line.split('=', 1) for line in self.xdo('getwindowgeometry', '--shell', self.window).splitlines())
            assert geometry['WINDOW'] == self.window and int(geometry['SCREEN']) == 0
            assert (int(geometry['WIDTH']), int(geometry['HEIGHT'])) == (320, 200)
            assert 0 <= int(geometry['X']) <= 320 and 0 <= int(geometry['Y']) <= 280
            copied = {name: dict(bytes=(self.run / name).stat().st_size, sha256=sha(self.run / name))
                      for name in CANONICAL_ASSETS if name != 'SETUP.LOG'}
            assert copied == {name: value for name, value in CANONICAL_ASSETS.items() if name != 'SETUP.LOG'}
            binding = dict(schema='lezac-native-outside-column-host-binding-v1',
                host=HOST_PREFLIGHT, actual_host_sha256=sha(actual_host), actual_pid=self.child.pid,
                argv=actual_argv, cwd=str(cwd), config_sha256=sha(self.output / 'dosbox.conf'),
                loader_sha256=sha(self.output / 'L1ORACLE.COM'), prefix_header=row,
                copied_assets=copied, canonical_source_assets=CANONICAL_ASSETS,
                omitted_installation_log='SETUP.LOG', geometry=geometry,
                environment={key: os.environ.get(key) for key in
                    ('SDL_AUDIODRIVER', 'SDL_VIDEODRIVER', 'DISPLAY', 'TMPDIR', 'TMP', 'TEMP')},
                observer_sha256=sha(Path(__file__)), base_observer_sha256=BASE_OBSERVER_SHA256,
                whole_game_fidelity_claim=False)
            assert binding['environment']['SDL_AUDIODRIVER'] == 'dummy'
            (self.output / 'host-binding.json').write_bytes(original.json_bytes(binding))
        emit(row)
    return super().capture(bound_emit)
'''


class Configure(ast.NodeTransformer):
    def __init__(self):
        self.assignments, self.prefix_check, self.classes, self.prints = set(), 0, 0, 0

    def visit_Assign(self, node):
        if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            values = {
                'ROOT': f'Path({str(ROOT)!r})',
                'OUT': "Path('/dev/shm/lezac-outside-column-t300/original-repeat')",
                'ROUTE': "ROOT / 'tests/fixtures/natural_level4_outside_column/route.txt'",
                'expected': "{(row['index'],row['phase']): row for row in support.fixture()[1:-1] "
                            "if row['section']=='level4' and row['index']<=11300}",
                'retained': "tick == last or (level == 4 and (tick == 9422 or tick >= 11300))",
            }
            if name in values:
                node.value = ast.parse(values[name], mode='eval').body
                self.assignments.add(name)
            if name == 'report':
                extras = ast.parse("report.update(base_observer_sha256=BASE_OBSERVER_SHA256, "
                    "first_full_frame_tick=11300,last_full_frame_tick=settings['ticks'],full_frame_window_only=True)").body
                return [self.generic_visit(node), *extras]
        return self.generic_visit(node)

    def visit_ClassDef(self, node):
        if node.name == 'Session':
            self.classes += 1
            node.body.append(ast.parse(method).body[0])
        return self.generic_visit(node)

    def visit_Assert(self, node):
        if any(isinstance(part, ast.Name) and part.id == 'old_events' for part in ast.walk(node)):
            self.prefix_check += 1
            return ast.copy_location(ast.parse(
                "assert {t:r for t,r in events.items() if t<11300} == {t:r for t,r in old_events.items() if t<11300}").body[0], node)
        return self.generic_visit(node)

    def visit_Expr(self, node):
        if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and \
                node.value.func.id == 'print' and any(isinstance(part, ast.Name) and part.id == 'summary'
                                                     for part in ast.walk(node)):
            self.prints += 1
            return ast.copy_location(ast.If(test=ast.parse("tick%100==0 and phase=='post_update'", mode='eval').body,
                                           body=[node], orelse=[]), node)
        return self.generic_visit(node)


tree = ast.parse(raw.decode(), filename=str(base))
config = Configure()
tree = config.visit(tree)
assert config.assignments == {'ROOT', 'OUT', 'ROUTE', 'expected', 'retained'}
assert config.prefix_check == config.classes == config.prints == 1
ast.fix_missing_locations(tree)
exec(compile(tree, str(base), 'exec'), {'__name__': '__main__', '__file__': str(Path(__file__)),
    'BASE_OBSERVER_SHA256': BASE_SHA, 'HOST_PREFLIGHT': HOST, 'CANONICAL_ASSETS': ASSETS})
