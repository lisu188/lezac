"""Separate original expectation producers from C++ mutation-stimulus producers."""
import gzip
import hashlib
import json
from pathlib import Path

root = Path('/mnt/c/Users/andrz/git/lezac-level4-return-portal-20261103/docs/recovery/evidence/natural_level4_outside_column_20261103')
manifest = json.loads((root / 'manifest.json').read_text())
manifest['evidence_file_pins'] = manifest.pop('native_file_pins')
name = 'make-outside-column-guards-t300.py'
manifest['guard_producer_pins'] = {name: manifest['producer_pins'].pop(name)}
data = Path(__file__).read_bytes()
name = Path(__file__).name
packed = gzip.compress(data, mtime=0)
(root / (name + '.gz')).write_bytes(packed)
manifest['guard_producer_pins'][name] = hashlib.sha256(data).hexdigest()
manifest['evidence_file_pins'][name + '.gz'] = hashlib.sha256(packed).hexdigest()
(root / 'manifest.json').write_bytes(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode() + b'\n')
print(hashlib.sha256((root / 'manifest.json').read_bytes()).hexdigest())
