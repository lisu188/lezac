"""Keep C++ typed mutation stimuli separate from the original-only reference writer."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/mnt/c/Users/andrz/git/lezac-level4-return-portal-20261103')
FIXTURE = ROOT / 'tests/fixtures/natural_level4_outside_column'
EVIDENCE = ROOT / 'docs/recovery/evidence/natural_level4_outside_column_20261103'
TRACE = Path('/dev/shm/lezac-level4-outside-pillar-t299/outside_pillar_standing_medium/run/trace.jsonl')
sha = lambda data: hashlib.sha256(data).hexdigest()
encode = lambda value: json.dumps(value, sort_keys=True, separators=(',', ':')).encode()
reference_before = (FIXTURE / 'reference.jsonl.gz').read_bytes()
rows = []
for line in TRACE.open():
    row = json.loads(line)
    if row.get('phase') == 'post_update' and row['tick'] in (11300, 11958, 12100):
        rows.append(dict(kind='cpp_typed_mutation_stimulus_only', index=row['tick'],
                         phase=row['phase'], state=row['state']))
assert [row['index'] for row in rows] == [11300, 11958, 12100]
path = FIXTURE / 'guard-inputs.jsonl.gz'
assert not path.exists()
path.write_bytes(gzip.compress(b''.join(encode(row) + b'\n' for row in rows), mtime=0))
manifest = json.loads((EVIDENCE / 'manifest.json').read_text())
manifest['fixture_pins'][path.name] = sha(path.read_bytes())
manifest['guard_input_source'] = dict(kind='cpp_typed_mutation_stimulus_only',
    expected_bytes_source=False, indices=[11300, 11958, 12100], phase='post_update',
    trace_sha256=sha(TRACE.read_bytes()),
    executable_sha256=sha(Path('/dev/shm/lezac-debris-phase-t296/build/lezac_cpp').read_bytes()))
producer = Path(__file__)
name = producer.name + '.gz'
(EVIDENCE / name).write_bytes(gzip.compress(producer.read_bytes(), mtime=0))
manifest['native_file_pins'][name] = sha((EVIDENCE / name).read_bytes())
manifest['producer_pins'][producer.name] = sha(producer.read_bytes())
(EVIDENCE / 'manifest.json').write_bytes(encode(manifest) + b'\n')
assert (FIXTURE / 'reference.jsonl.gz').read_bytes() == reference_before
print(json.dumps(dict(manifest_sha256=sha((EVIDENCE / 'manifest.json').read_bytes()),
                      guard_bytes=path.stat().st_size, native_reference_unchanged=True)))
