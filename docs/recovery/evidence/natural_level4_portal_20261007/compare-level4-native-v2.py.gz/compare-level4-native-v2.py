"""Compare an extended, unmodified ordinary route with its native observations."""
import argparse
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

from PIL import Image

SOURCE = Path('/dev/shm/lezac-level3-results-regression-20261006-t1')
sys.path.insert(0, str(SOURCE / 'tools'))
import level1_fidelity as fidelity
import level1_handoff as handoff
import level1_original as original
import natural_campaign as campaign
import natural_level3_handoff as recovered
import natural_level3_gate_projections as projection

FIRST, LAST, ENTRY = 8905, 10720, 9422
FRAMES = LAST - ENTRY + 1
ROUTE_SHA = '4bef0a96a8a3607025138192956013338a8afb3112d590399c3cc6d992db5b5b'
REVISION = '4fe016ad7bfce8ab41f70301b22e7216067df3e5'
BINARY_SHA = 'f25e005ce78add7e2c90926c05440a08e70acd166fdd4924a138c325474db91f'
PREVIEWS = {9760, 10100, 10300, 10500, 10562, 10620, 10632, 10633, 10660, 10662, 10675, 10720}
require = fidelity.require


def save_image(directory, name, pixels):
    target = directory / (name + '.png')
    require(not target.exists(), 'fresh preview required')
    Image.frombytes('RGB', (320, 200), pixels).save(target)
    require(Image.open(target).convert('RGB').tobytes() == pixels, 'preview conversion changed RGB')


def native_records(out, previews):
    records = []
    pixels = bytes(192000)
    with gzip.open(out / 'level3-handoff.jsonl.gz', 'rt') as stream:
        head = fidelity.strict_json(next(stream))
        for index in range(5129):
            row = fidelity.strict_json(next(stream))
            require(row['cpp_tick'] == 3777 + index, 'native prefix order differs')
            pixels = original.decode_frame(row['rgb_delta_zlib_hex'], pixels, row['rgb_sha256'])
        require(fidelity.strict_json(next(stream))['frames'] == 5129 and not stream.read(), 'native prefix incomplete')
    for pi, field, phase in ((1, 'rendered', 'present'), (2, 'post', 'post_update')):
        records.append(recovered.boundary('gate', FIRST, phase, row[field], row['dac'][pi],
                                         head['atlas'], row['rgb_sha256'] if pi == 1 else None))
    reels = handoff.load(out / 'level3-results.jsonl.gz')
    entry = handoff.load(out / 'level4-handoff.jsonl.gz')
    require(len(reels) == 60 and len(entry) == FRAMES + 2 and
            reels[-1]['gameplay_frozen'] and entry[-1]['native_level4_entry_observed'] and
            entry[0]['dimensions'] == [100, 58], 'native results/entry incomplete')
    pixels = bytes(192000)
    for index, sample in enumerate(reels[1:-1]):
        require(sample['sample'] == index and sample['player'] == 1, 'native reels reordered')
        campaign.raw_state(sample['state'], 3, (150, 60))
        pixels = original.decode_frame(sample['rgb_delta_zlib_hex'], pixels, sample['rgb_sha256'])
        records.append(recovered.boundary('result', 76 + index, 'result', sample['state'], sample['dac'],
                                         reels[0]['atlas'], sample['rgb_sha256']))
    for section, tick, field, dac in (('ack', 9301, 'baseline', 'baseline_dac'),
                                      ('intro', 9421, 'intro', 'intro_dac')):
        queued = entry[0]['ack' if section == 'ack' else 'intro_ack']
        before, after = bytes.fromhex(queued['before_bda_hex']), bytes.fromhex(queued['bda_hex'])
        require(len(before) == len(after) == 64 and original.word(before, 0x1a) == original.word(before, 0x1c)
                and original.word(after, queued['head']) == queued['key_word'] == 0x1c0d,
                'native acknowledgement is not a fresh Return')
        image_name = 'original_level3_results_before_ack.png' if section == 'ack' else 'original_level4_intro.png'
        pixels = Image.open(out / image_name).convert('RGB').tobytes()
        digest = entry[0][section + '_rgb_sha256']
        require(len(pixels) == 192000 and hashlib.sha256(pixels).hexdigest() == digest, 'native acknowledgement RGB differs')
        records.append(recovered.boundary(section, tick, 'present', entry[0][field], entry[0][dac],
            reels[0]['atlas'] if section == 'ack' else entry[0]['atlas'], digest, False))
    pixels = bytes(192000)
    for index, sample in enumerate(entry[1:-1]):
        tick = ENTRY + index
        require(sample['sample'] == index and sample['cpp_tick'] == tick, 'native Level 4 order differs')
        pixels = original.decode_frame(sample['rgb_delta_zlib_hex'], pixels, sample['rgb_sha256'])
        if tick in PREVIEWS:
            save_image(previews, f'original_level4_{tick}', pixels)
        for pi, field, phase in ((1, 'rendered', 'present'), (2, 'post', 'post_update')):
            campaign.raw_state(sample[field], 4, (100, 58))
            records.append(recovered.boundary('level4', tick, phase, sample[field], sample['dac'][pi],
                entry[0]['atlas'], sample['rgb_sha256'] if pi == 1 else None))
    indexed = {(item['section'], item['index'], item['phase']): item for item in records}
    journal = fidelity.strict_json((out / 'results-handoff-ds-journal.json').read_text())
    require(journal['complete'] and len(journal['records']) == 61 + 3 * FRAMES, 'native raw journal incomplete')
    with gzip.open(out / 'results-handoff-ds.bin.gz', 'rb') as stream:
        for index, record in enumerate(journal['records']):
            raw = stream.read(65536)
            require(len(raw) == 65536 and hashlib.sha256(raw).hexdigest() == record['sha256'], 'native DS hash differs')
            role, tick = record['role'], record['cpp_tick']
            if role in ('pre', 'ack', 'intro'):
                continue
            key = ('gate', FIRST, 'post_update') if role == 'gate_post' else \
                  ('result', index + 75, 'result') if role == 'result' else ('level4', tick, role)
            require(key in indexed and 'terrain' not in indexed[key]['projection'], 'native raw role is duplicate/unknown')
            indexed[key]['projection']['terrain'] = projection.native_terrain(raw)
        require(not stream.read(1), 'trailing native DS bytes')
    require(len(indexed) == len(records) == 62 + 2 * FRAMES, 'native boundary cardinality differs')
    require(all('terrain' in item['projection'] for item in records
                if item['section'] not in ('ack', 'intro') and
                not (item['section'] == 'gate' and item['phase'] == 'present')), 'missing terrain comparison')
    return indexed


def native_progression(wanted):
    milestones = []
    portals = []
    previous = 0
    prior_player = None
    for tick in range(ENTRY, LAST + 1):
        mapped = wanted['level4', tick, 'post_update']['projection']['mapped']
        player = mapped['players'][0]
        if prior_player is not None and abs(player['xy'][0] - prior_player['xy'][0]) > 100:
            portals.append(dict(tick=tick, before_xy=prior_player['xy'], after_xy=player['xy'],
                health=player['energy'], inventory=player['inventory']))
        objectives = mapped['progress'][0]
        if objectives != previous:
            player = mapped['players'][0]
            milestones.append(dict(tick=tick, objectives=objectives,
                destroyed=mapped['progress'][1], xy=player['xy'],
                health=player['energy'], reserve=player['reserve'],
                inventory=player['inventory'], score=mapped['score']))
        previous = objectives
        prior_player = player
    return dict(objective_changes=milestones, portal_transitions=portals,
                endpoint=wanted['level4', LAST, 'post_update']['projection']['mapped'])


def compare(native, work, control, previews):
    require(not previews.exists(), 'fresh comparison previews required')
    previews.mkdir()
    receipt = fidelity.strict_json((control / 'capture-terminal-receipt.json').read_text())
    require(receipt['terminal'] and receipt['exit_code'] == 0, 'native capture has no successful terminal receipt')
    native_audit = fidelity.strict_json((control / 'native-audit.json').read_text())
    require(native_audit['level4_frames'] == FRAMES and native_audit['raw_ds_boundaries'] == 61 + 3 * FRAMES and
            native_audit['patches_restored'], 'native capture audit incomplete')
    for name, key in (
        ('level3-handoff.jsonl.gz', 'native_gate_stream_sha256'),
        ('level3-results.jsonl.gz', 'native_results_sha256'),
        ('level4-handoff.jsonl.gz', 'native_level4_stream_sha256'),
        ('results-handoff-ds.bin.gz', 'raw_ds_sha256'),
        ('results-handoff-ds-journal.json', 'raw_ds_journal_sha256'),
    ):
        require(fidelity.sha256(native / name) == native_audit[key], 'native audited file changed: ' + name)
    require(native_audit['route_sha256'] == fidelity.sha256(native / 'level3-route.txt') == ROUTE_SHA,
            'native route differs from C++ route')
    outcome = fidelity.strict_json((native / 'outcome-manifest.json').read_text())
    require(outcome['status'] == 'captured' and outcome['patches_restored'] and
            outcome['assets'] == {name: fidelity.sha256(SOURCE / name) for name in fidelity.ASSETS} and
            original.fingerprint(native) == handoff.PREFIX_SHA256, 'native assets/startup/restoration differs')
    for name, digest in outcome['files'].items():
        require(fidelity.sha256(fidelity.safe_file(native, name)) == digest, 'native manifest file changed: ' + name)
    preparation = fidelity.strict_json((control / 'preparation-proof.json').read_text())
    for name, digest in preparation['producer_hashes'].items():
        require(fidelity.sha256(control / name) == digest, 'native producer changed after launch: ' + name)
    coherence = fidelity.strict_json((control / 'native-coherence-v1.json').read_text())
    require(coherence['boundaries'] == 61 + 3 * FRAMES and coherence['differing_byte_observations'] == 0 and
            coherence['normalized_bytes'] == 0 and
            coherence['raw_sha256'] == fidelity.sha256(native / 'results-handoff-ds.bin.gz') and
            coherence['journal_sha256'] == fidelity.sha256(native / 'results-handoff-ds-journal.json'),
            'independent native coherence audit absent/stale')
    require(fidelity.strict_json((work / 'child-result.json').read_text())['exit_code'] == 0, 'C++ replay failed')
    command = fidelity.strict_json((work / 'command.json').read_text())
    require(command['source'] == dict(revision=REVISION, dirty=False) and
            command['executable_sha256'] == BINARY_SHA and command['audio'] == command['video'] == 'dummy' and
            command['state_injections'] is False and command['candidate_only'] is True and
            command['original_fidelity_claim'] is False and command['port_functionally_complete'] is False,
            'C++ command provenance differs')
    require(fidelity.sha256(work / 'route.txt') == command['route_sha256'] == ROUTE_SHA, 'C++ route differs')
    settings, events = fidelity.read_route(work / 'route.txt')
    require(settings['ticks'] == LAST, 'C++ route length differs')
    require(command['assets'] == {name: fidelity.sha256(SOURCE / name) for name in fidelity.ASSETS}, 'C++ assets differ')
    wanted = native_records(native, previews)
    seen, mismatches, state_differences, rgb_differences = set(), [], 0, 0
    frames, compared_rgb, checks, previous, footer, mutations = 0, 0, 0, None, None, 0
    previous_state = None
    order = {'input': 0, 'present': 1, 'after_nonplayers': 2, 'post_update': 3}

    def check(state, key, pixels=None):
        nonlocal state_differences, rgb_differences, compared_rgb, mutations
        require(key in wanted and key not in seen, 'unknown/duplicate comparison boundary')
        expected = wanted[key]
        try:
            recovered.check_cpp(state, expected)
        except fidelity.EvidenceError as error:
            state_differences += 1
            if len(mismatches) < 20:
                mismatches.append(dict(key=list(key), type='state', difference=str(error)))
        else:
            if key in (('result', 133, 'result'), ('ack', 9301, 'present'),
                       ('intro', 9421, 'present'), ('level4', LAST, 'post_update')):
                mutations += recovered.guard_cpp(state, expected)
        if expected['rgb_sha256'] is not None:
            require(pixels is not None, 'missing comparison RGB')
            compared_rgb += 1
            digest = hashlib.sha256(pixels).hexdigest()
            if digest != expected['rgb_sha256']:
                rgb_differences += 1
                if len(mismatches) < 20:
                    mismatches.append(dict(key=list(key), type='rgb', expected=expected['rgb_sha256'], actual=digest))
        else:
            require(pixels is None, 'unexpected comparison RGB')
        seen.add(key)

    with (work / 'cpp/trace.jsonl').open() as stream:
        header = fidelity.strict_json(next(stream))
        require(header['schema'] == 'lezac.level1.scout.v1' and header['candidate_only'] is True and
                header['capture_from_tick'] == FIRST and header['ticks'] == LAST and header['source'] == 'cpp' and
                header['phase_model'] == 'cpp-pre-actors-v2' and header['state_scope'] == 'level1-observations-v2' and
                header['input_model'] == 'sdl-events-original-intro-wait-v1' and
                header['seed'] == settings['seed'] and header['step_us'] == settings['step_us'] and
                header['route_fnv1a64'] == fidelity.fnv1a64((work / 'route.txt').read_bytes()) and
                header['asset_fnv1a64'] == {name: fidelity.fnv1a64((SOURCE / name).read_bytes()) for name in fidelity.ASSETS}
                and header['original_fidelity_claim'] is False and (header['width'], header['height']) == (320, 200),
                'C++ trace provenance differs')
        for line in stream:
            row = fidelity.strict_json(line)
            require(footer is None, 'data after C++ completion')
            if row['kind'] == 'complete':
                footer = row
                continue
            require(row['kind'] == 'checkpoint' and row['phase'] in order, 'invalid C++ checkpoint')
            tick, phase, state = row['tick'], row['phase'], row['state']
            current = row['seq'], tick, order[phase]
            require(FIRST <= tick <= LAST, 'C++ tick outside capture')
            if previous is None:
                require(current[1:] == (FIRST, 0), 'wrong first C++ phase')
            else:
                allowed = {(previous[1], previous[2] + 1)} if previous[2] < 3 else {(previous[1] + 1, 0)}
                if previous[2] == 1 and (previous_state['flow'][3] or previous_state['flow'][4]):
                    allowed.add((previous[1], 3))
                require(current[0] == previous[0] + 1 and current[1:] in allowed, 'C++ phases skipped/reordered')
            require(row['events'] == events.get(tick - 1, []) and
                    row['time_ms'] == (tick - 1) * settings['step_us'] // 1000, 'C++ input/time differs')
            fidelity.validate_state(state)
            pixels = None
            if phase == 'present':
                require(row['frame'] == f'frame_{tick:06d}.ppm', 'C++ frame name differs')
                pixels = fidelity.read_ppm(fidelity.safe_file(work / 'cpp', row['frame']))
                require(fidelity.fnv1a64(pixels) == row['rgb_fnv1a64'], 'C++ RGB hash differs')
                frames += 1
                if tick in PREVIEWS:
                    save_image(previews, f'cpp_level4_{tick}', pixels)
            else:
                require('frame' not in row and 'rgb_fnv1a64' not in row, 'unexpected C++ RGB')
            section = 'gate' if tick == FIRST else 'ack' if tick == 9301 else 'intro' if tick == 9421 else 'level4'
            key = section, tick, phase
            if key in wanted:
                check(state, key, pixels)
            previous, previous_state, checks = current, state, checks + 1
        require(footer is not None and previous[1:] == (LAST, 3) and footer['ticks'] == LAST and
                footer['frames'] == frames == LAST - FIRST + 1 and footer['retained_checkpoints'] == checks and
                footer['checkpoints'] == previous[0] + 1 and footer['events'] == sum(map(len, events.values())) and
                footer['level1_route_complete'] is True and footer['candidate_only'] is True and
                footer['capture_from_tick'] == FIRST and footer['original_fidelity_claim'] is False and
                footer['port_functionally_complete'] is False, 'C++ footer incomplete')
    reels = [fidelity.strict_json(line) for line in (work / 'cpp/result_reels.jsonl').read_text().splitlines()]
    require(reels[0] == dict(kind='header', schema='lezac.level1.result-reels.v1',
            boundary='prepared-score-then-after-delayed-rng', original_fidelity_claim=False) and
            len(reels) == 136 and reels[-1] == dict(kind='complete', samples=134, original_fidelity_claim=False),
            'C++ result stream incomplete')
    for index, row in enumerate(reels[1:-1]):
        require(set(row) == {'kind', 'sample', 'player', 'frame', 'state'} and row['kind'] == 'sample' and
                row['sample'] == index and row['player'] == 1 and row['frame'] == f'result_frame_{index:06d}.ppm',
                'C++ result sample reordered')
        fidelity.validate_state(row['state'])
        pixels = fidelity.read_ppm(fidelity.safe_file(work / 'cpp', row['frame']))
        if index >= 76:
            check(row['state'], ('result', index, 'result'), pixels)
    require(seen == set(wanted) and compared_rgb == 61 + FRAMES, 'missing native/C++ comparisons')
    if not state_differences:
        require(mutations == 43, 'missing C++ projection mutation checks')
    return dict(status='match' if not state_differences and not rgb_differences else 'different',
                compared_rgb_frames=compared_rgb, compared_mapped_boundaries=len(seen),
                state_differing_boundaries=state_differences, rgb_differing_frames=rgb_differences,
                first_differences=mismatches, cpp_retained_frames=frames, cpp_retained_checkpoints=checks,
                cpp_projection_mutations_rejected=mutations, raw_coherent_boundaries=coherence['boundaries'],
                route_sha256=ROUTE_SHA, source_revision=REVISION, reader_sha256=fidelity.sha256(Path(__file__)),
                native_stream_sha256=fidelity.sha256(native / 'level4-handoff.jsonl.gz'),
                cpp_trace_sha256=fidelity.sha256(work / 'cpp/trace.jsonl'),
                native_progression=native_progression(wanted),
                completed_levels=[1, 2, 3], entered_level=4, audio='dummy', state_injections=False,
                full_prefix_cpp_comparison_claim=False, full_actor_clock_sound_byte_parity=False,
                level4_completion_claim=False, original_fidelity_claim=False, port_functionally_complete=False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('native', 'work', 'control', 'previews', 'report'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    require(not args.report.exists(), 'fresh comparison report required')
    report = compare(args.native, args.work, args.control, args.previews)
    args.report.write_bytes(original.json_bytes(report))
    print(json.dumps(report), flush=True)
    require(report['status'] == 'match', 'native/C++ differences retained in report')
