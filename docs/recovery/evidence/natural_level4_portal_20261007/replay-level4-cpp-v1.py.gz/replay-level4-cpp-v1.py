"""Fresh ordinary-input replay, gated on the actual native terminal receipt."""
from common import *
import json
import subprocess

CPP = Path('/dev/shm/lezac-level4-portal-native-cpp-20261007-t3')


def main():
    protected()
    protocol.owner()
    terminal = load('capture-terminal-receipt.json')
    assert terminal['terminal'] and terminal['exit_code'] == 0
    native = load('native-audit.json')
    assert native['level4_frames'] == LEVEL4_FRAMES and native['patches_restored']
    assert fidelity.source_version(CPP_WORK) == dict(revision=protocol.HEAD, dirty=False)
    assert fidelity.sha256(protocol.EXE) == protocol.EXE_SHA
    capacity = reserve((512 + 1200) * 1024**2)
    assert not CPP.exists()
    data = route_bytes()
    CPP.mkdir()
    (CPP / 'route.txt').write_bytes(data)
    assets = {name: fidelity.sha256(CPP_WORK / name) for name in fidelity.ASSETS}
    command = [str(protocol.EXE), '--replay-level1-scout', str(CPP / 'route.txt'),
               str(CPP / 'cpp'), str(GATE), '--original-intro-wait', '--result-reels']
    metadata = dict(command=command, source=fidelity.source_version(CPP_WORK), assets=assets,
                    executable_sha256=protocol.EXE_SHA, route_sha256=ROUTE_SHA,
                    helper_sha256=fidelity.sha256(Path(__file__)), capacity=capacity,
                    state_injections=False, candidate_only=True, audio='dummy', video='dummy',
                    original_fidelity_claim=False, level4_completion_claim=False,
                    port_functionally_complete=False)
    (CPP / 'command.json').write_bytes(original.json_bytes(metadata))
    with (CPP / 'stdout.txt').open('wb') as stdout, (CPP / 'stderr.txt').open('wb') as stderr:
        result = subprocess.run(command, cwd=CPP_WORK, stdout=stdout, stderr=stderr,
            env=dict(os.environ, SDL_AUDIODRIVER='dummy', SDL_VIDEODRIVER='dummy',
                     LEZAC_LOAD_JSON_ASSETS='0', LEZAC_LOAD_ORIGINAL_ASSETS='1'))
    (CPP / 'child-result.json').write_bytes(original.json_bytes(dict(exit_code=result.returncode)))
    assert result.returncode == 0
    assert assets == {name: fidelity.sha256(CPP_WORK / name) for name in fidelity.ASSETS}
    protected()
    print(json.dumps(dict(status='cpp_level4_comparison_replay_complete',
        work=str(CPP), route_sha256=ROUTE_SHA, first_tick=GATE, last_tick=LAST,
        compared_to_original=False, whole_game_complete=False)), flush=True)


if __name__ == '__main__':
    main()
