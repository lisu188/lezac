"""Launch one tracked silent observer independently of the chat shell lifetime."""
from common import *
import json
import subprocess

UNIT = 'lezac-level4-portal-capture-20261007-t3.service'
protected()
protocol.owner()
reserve(2 * 1024**3)
assert not OUT.exists()
state = subprocess.run(['systemctl', '--user', 'show', UNIT, '--property=LoadState'],
                       text=True, capture_output=True)
assert 'LoadState=not-found' in state.stdout
for name, digest in load('preparation-proof.json')['producer_hashes'].items():
    assert fidelity.sha256(DURABLE / name) == digest
command = ['systemd-run', '--user', '--unit=' + UNIT, '--service-type=exec', '--remain-after-exit',
    '--working-directory=' + str(ROOT), '--property=Restart=no', '--property=RuntimeMaxSec=7200',
    '--property=KillMode=control-group', '--property=StandardInput=null',
    '--property=StandardOutput=append:' + str(WORK / 'service-stdout.txt'),
    '--property=StandardError=append:' + str(WORK / 'service-stderr.txt'),
    '--setenv=SDL_AUDIODRIVER=dummy', '--setenv=PYTHONDONTWRITEBYTECODE=1',
    '--setenv=TMPDIR=/dev/shm', '/usr/bin/python3', str(DURABLE / 'launch-capture-v1.py')]
save('tracked-service-launch-command.json', dict(command=command, unit=UNIT,
    source_sha256=fidelity.sha256(Path(__file__)), audio='dummy', original_capture_success_claim=False,
    new_gameplay_state_injections=False, whole_game_complete=False))
result = subprocess.run(command, text=True, capture_output=True)
assert result.returncode == 0, result.stderr
properties = 'ActiveState,SubState,MainPID,ControlGroup,ExecMainCode,ExecMainStatus,Result'
unit_state = dict(line.split('=', 1) for line in subprocess.check_output([
    'systemctl', '--user', 'show', UNIT, '--property=' + properties], text=True).splitlines())
assert unit_state['ActiveState'] == 'active' and unit_state['SubState'] == 'running'
identity = protocol.identity(int(unit_state['MainPID']))
assert identity['argv'] == ['/usr/bin/python3', str(DURABLE / 'launch-capture-v1.py')]
save('tracked-service-start-proof.json', dict(unit=UNIT, state=unit_state, identity=identity,
    launcher_stdout=result.stdout, launcher_stderr=result.stderr,
    original_capture_success_claim=False, whole_game_complete=False))
print(json.dumps(dict(status='tracked_native_capture_service_started', unit=UNIT,
    state=unit_state, identity=identity, output=str(OUT))), flush=True)
