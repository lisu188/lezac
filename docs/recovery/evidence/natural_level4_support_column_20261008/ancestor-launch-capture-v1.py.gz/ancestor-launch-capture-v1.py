"""Run the frozen native observer under one private display and preserve all logs."""
from common import *
import json
import subprocess

protected()
protocol.owner()
producer('launch-capture-v1.py')
reserve(2 * 1024 ** 3)
logs = WORK / 'run-logs'
assert not logs.exists()
logs.mkdir()
command = ['xvfb-run', '-a', 'python3', str(DURABLE / 'private-capture.py')]
environment = dict(os.environ, SDL_AUDIODRIVER='dummy', SDL_VIDEODRIVER='x11', TMPDIR='/dev/shm')
save('capture-launch-command.json', dict(command=command, audio='dummy', video='private_xvfb',
    observer_sha256=fidelity.sha256(DURABLE / 'capture.py'), atomic_source_sha256=ATOMIC_SHA,
    route_sha256=ROUTE_SHA, new_gameplay_state_injections=False, whole_game_complete=False))
with (logs / 'stdout.txt').open('wb') as stdout, (logs / 'stderr.txt').open('wb') as stderr:
    result = subprocess.run(command, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr)
save('capture-process-result.json', dict(exit_code=result.returncode, owned_process_terminal=True,
    stdout_sha256=fidelity.sha256(logs / 'stdout.txt'), stderr_sha256=fidelity.sha256(logs / 'stderr.txt'),
    original_comparison_claim=False, whole_game_complete=False))
print(json.dumps(dict(status='native_capture_process_terminal', exit_code=result.returncode,
    output=str(OUT), stdout=str(logs / 'stdout.txt'), stderr=str(logs / 'stderr.txt'))), flush=True)
raise SystemExit(result.returncode)
