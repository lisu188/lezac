"""Pair a native projection and raw DS bytes while the owned process is stopped."""
import hashlib
import struct


def cached_read(session, at, count, reader):
    data = getattr(session, '_atomic_ds', None)
    if data is not None and session.ds <= at and at + count <= session.ds + len(data):
        start = at - session.ds
        return data[start:start + count]
    return reader(at, count)


def validate_projection(data, state):
    assert len(data) == 65536
    assert struct.unpack_from('<H', data, 0x78c2)[0] == state['frame']
    assert struct.unpack_from('<I', data, 0x1afe)[0] == state['rng']
    assert data[0x208d] == state['actor_count']
    for key, offset, length in (
        ('actors', 0x1bd4, state['actor_count'] * 38),
        ('visuals', 0xc21e, data[0xc496] * 8), ('inventory', 0x1b6c, 12),
        ('scores', 0x785a, 92), ('destruction', 0x78c6, 4),
        ('progress', 0x2076, 36), ('globals', 0x79a0, 90),
        ('spawners', 0x74c6, data[0x79a6] * 30),
    ):
        assert data[offset:offset + length].hex() == state[key], key
    for index, player in enumerate(state['players'], 1):
        offset = 0x1b62 + index * 38
        actor = data[offset:offset + 38]
        visual_offset = 0xc21e + actor[1] * 8
        visual = data[visual_offset:visual_offset + 8]
        assert actor.hex() == player['raw'] and visual.hex() == player['visual']
        assert list(struct.unpack_from('<HH', visual)) == player['xy']
        assert list(struct.unpack_from('<hh', actor, 6)) == player['v']
        assert [actor[10], actor[12]] == player['f']


def capture_world(session, raw_reader, decoder, validator, scratch_offset):
    assert getattr(session, '_atomic_ds', None) is None, 'nested native snapshot'
    session.atomic_snapshot = None
    with session.stopped():
        handshake = raw_reader(session.resident + scratch_offset, 20)
        assert len(handshake) == 20
        values = struct.unpack('<8HI', handshake)
        assert values[8] == session.sequence and values[7] == 0
        data = raw_reader(session.ds, 65536)
        assert len(data) == 65536
        width, scroll = struct.unpack_from('<H', data, 0xc204)[0], struct.unpack_from('<H', data, 0x2096)[0]
        level = data[0x79b7]
        assert scroll % 8 == 0 and 1 <= level <= 7
        dimensions = [width, scroll // 8 + 21]
        assert 1980 <= width * dimensions[1] <= 16384
        session._atomic_ds = data
        try:
            state = decoder(session)
            for key, pointer, size in (
                ('tiles', 0xc1e0, width * dimensions[1]),
                ('words', 0x6612, width * dimensions[1] * 2),
            ):
                offset, segment = struct.unpack_from('<HH', data, pointer)
                assert 0 < segment < 0xa000 and offset + size <= 65536
                block = session.read(session.base + (segment << 4) + offset, size)
                assert len(block) == size
                state[key] = block.hex()
            validate_projection(data, state)
            validator(state, dimensions, level)
            assert raw_reader(session.resident + scratch_offset, 20) == handshake
        finally:
            session._atomic_ds = None
        snapshot = dict(data=data, handshake=handshake, sequence=session.sequence,
                        dimensions=[*dimensions, level], state=state,
                        sha256=hashlib.sha256(data).hexdigest(),
                        observation_method='stopped_single_ds_snapshot')
    session.atomic_snapshot = snapshot
    return state, dimensions
