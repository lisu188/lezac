"""Execute the pinned observer without editing its imported source."""
from common import *
import runpy

runpy.run_path(str(frozen('capture.py')), run_name='__main__')
