"""Bind the frozen atomic observer to a stationary support-column trial."""
import hashlib as _hashlib
import importlib.util as _importlib
from pathlib import Path as _Path

_CONTROL = _Path(__file__).parent
_PRIOR = _CONTROL.parent / 'level4-third-objective-native-work-20261007-t4'
_SOURCE = _PRIOR / 'common.py'
assert _hashlib.sha256(_SOURCE.read_bytes()).hexdigest() == '91bc01592be771d1ed6041af361d236577022e24778bfe33c8af24840699b8ee'
_spec = _importlib.spec_from_file_location('column_trial_frozen_bindings', _SOURCE)
_module = _importlib.module_from_spec(_spec)
_spec.loader.exec_module(_module)
_module.DURABLE = _CONTROL
_module.WORK = _Path('/dev/shm/lezac-level4-column-trial-native-work-20261007-t9')
_module.OUT = _Path('/dev/shm/lezac-level4-column-trial-native-original-20261007-t9')
_module.LAST = 11740
_module.LEVEL4_FRAMES = _module.LAST - _module.LEVEL4_FIRST + 1
_module.ROUTE_SOURCE = _Path('/dev/shm/lezac-level4-stationary-column-seven-blast-20261007-t9/route.txt')
_module.ROUTE_SHA = 'df39d4ac769d61e0073f1382ddca883e5572e7dfca48a7f4e6868d79557183b2'
_module.ROUTE = _module.WORK / 'stationary-column-seven-v1.route'
_module.protocol.DURABLE = _CONTROL
_module.protocol.WORK = _module.WORK
_module.protocol.MARKER = ['lezac-level4-column-trial-keepalive-20261007-t9', '86400']
globals().update({key: value for key, value in vars(_module).items() if not key.startswith('_')})


def route_bytes():
    assert fidelity.sha256(ROUTE_SOURCE) == ROUTE_SHA
    if ROUTE.exists():
        assert ROUTE.read_bytes() == ROUTE_SOURCE.read_bytes()
    settings, events = fidelity.read_route(ROUTE_SOURCE)
    prefix = _Path('/dev/shm/lezac-level4-third-native-cpp-20261007-t4/route.txt')
    assert fidelity.sha256(prefix) == '00e22cf9842b7ae313f5efe966e948abea665cf42f51d5be1d14aed8195c4240'
    prior_settings, prior = fidelity.read_route(prefix)
    assert settings == {**prior_settings, 'ticks': LAST}
    assert {tick: rows for tick, rows in events.items() if tick < 11420} == prior
    assert all(row['key'] in original.BANK and row['action'] in ('up', 'down')
               for tick, rows in events.items() if tick > 11420 for row in rows)
    return ROUTE_SOURCE.read_bytes()


_module.route_bytes = route_bytes
FROZEN_FILES = {
    'capture.py': '8fd3ffbcef609759243ae6befb0d099f370d536aaff629b86a843b0ceb5767b0',
    'private-capture.py': '65c01489ec392d4acaf2381ac0eef211bcf244b394c1c0d3eae3e0e35f54502b',
    'launch-capture-v1.py': '0382fb6a281680a444f4b742a2011ca3374cb2d023ea2fe8e7bcac5af81dbd28',
}


def frozen(name):
    path = _PRIOR / name
    assert fidelity.sha256(path) == FROZEN_FILES[name]
    return path
