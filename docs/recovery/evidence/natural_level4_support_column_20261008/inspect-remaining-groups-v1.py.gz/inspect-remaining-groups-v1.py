"""Inventory remaining physical damage groups from the closed verified anchor."""
from collections import defaultdict
import json
from pathlib import Path
import struct
import sys

SOURCE = Path('/dev/shm/lezac-level3-results-regression-20261006-t1')
CONTROL = Path(__file__).parent
TRACE = Path('/dev/shm/lezac-level4-third-native-cpp-20261007-t4/cpp/trace.jsonl')
TRACE_SHA = '147479cda3a3a85baa5c0d47c5c37304f71ff34c16cbabe9b1d8a72bfb584b3e'
sys.path.insert(0, str(SOURCE / 'tools'))
import level1_fidelity as fidelity
import level1_original as original


def main():
    target = CONTROL / 'remaining-groups-v1.json'
    assert not target.exists()
    assert fidelity.sha256(TRACE) == TRACE_SHA
    with TRACE.open() as stream:
        for line in stream:
            row = fidelity.strict_json(line)
            if row.get('tick') == 11420 and row.get('phase') == 'post_update':
                state = row['state']
                break
        else:
            raise AssertionError('anchor missing')
    fidelity.validate_state(state)
    assert state['dimensions'] == [100, 58] and state['level'] == 4
    tiles = bytes.fromhex(state['tiles_hex'])
    words = struct.unpack('<5800H', bytes.fromhex(state['words_hex']))
    groups = defaultdict(list)
    for i, word in enumerate(words):
        if 0 < word < 0x4000:
            groups[word].append(dict(x=i % 100, y=i // 100, tile=tiles[i]))
    summary = []
    for word, cells in groups.items():
        summary.append(dict(word=word, count=len(cells),
            bounds=[min(c['x'] for c in cells), min(c['y'] for c in cells),
                    max(c['x'] for c in cells), max(c['y'] for c in cells)], cells=cells))
    grid = [[dict(x=x, y=y, tile=tiles[y * 100 + x], word=words[y * 100 + x])
             for x in range(12, 64)] for y in range(29, 48)]
    report = dict(status='closed_verified_anchor_physical_groups_read_only',
        source_trace=str(TRACE), trace_sha256=TRACE_SHA, tick=11420,
        source_sha256=fidelity.sha256(Path(__file__)), groups=summary, grid=grid,
        player=state['players'][0], progress=state['progress'],
        candidate_only=True, state_injections=False, whole_game_complete=False)
    target.write_bytes(original.json_bytes(report))
    print(json.dumps([{k: row[k] for k in ('word', 'count', 'bounds')} for row in summary]))
    for cells in grid:
        print(str(cells[0]['y']) + ': ' + ' '.join(f"{c['tile']:02x}:{c['word']:04x}" for c in cells))


if __name__ == '__main__':
    main()
