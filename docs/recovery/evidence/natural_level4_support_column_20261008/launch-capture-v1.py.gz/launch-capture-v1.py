"""Own the native observer and its keeper until both become terminal."""
from common import *
import json
import runpy
import subprocess
import time

protected()
preflight = load('preflight-v1-report.json')
assert preflight['transitive_setup_passed'] and not WORK.exists() and not OUT.exists()
for name, digest in preflight['producer_hashes'].items():
    assert fidelity.sha256(DURABLE / name) == digest
capacity = reserve(2 * 1024**3)
WORK.mkdir()
shutil.copyfile(ROUTE_SOURCE, ROUTE)
route_bytes()
marker, seconds = protocol.MARKER
keeper_command = ['/usr/bin/bash', '-c', 'exec -a ' + marker + ' /usr/bin/sleep ' + seconds]
keeper = subprocess.Popen(keeper_command, env=dict(os.environ, SDL_AUDIODRIVER='dummy'))
identity = None
try:
    for _ in range(30):
        identity = protocol.identity(keeper.pid)
        if identity['exe'] == '/usr/bin/sleep' and identity['argv'] == protocol.MARKER:
            break
        time.sleep(.1)
    else:
        raise AssertionError('keeper did not reach its owned sleep process')
    save('preparation-proof.json', dict(status='owned_stationary_column_original_observer_prepared',
        producer_hashes=preflight['producer_hashes'], frozen_producers=FROZEN_FILES,
        keeper=dict(identity=identity, tool_session=None, parent_owned=True, command=keeper_command),
        capacity=capacity, route_sha256=ROUTE_SHA, source_head=protocol.HEAD,
        executable_sha256=protocol.EXE_SHA, audio='dummy', state_injections=False,
        whole_game_complete=False))
    protocol.owner()
    runpy.run_path(str(frozen('launch-capture-v1.py')), run_name='__main__')
finally:
    if keeper.poll() is None:
        assert protocol.identity(keeper.pid) == identity
        keeper.terminate()
    code = keeper.wait(timeout=15)
    save('keeper-terminal.json', dict(terminal=True, exit_code=code, identity=identity,
        parent_owned=True, whole_game_complete=False))
