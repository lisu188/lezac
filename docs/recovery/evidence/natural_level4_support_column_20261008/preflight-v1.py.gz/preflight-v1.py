"""Check transitive observation setup and the exact ordinary-input fork."""
from common import *
import ast
import json
import subprocess

protected()
route_bytes()
assert not WORK.exists() and not OUT.exists()
report = fidelity.strict_json((FIRST_CONTROL / 'stationary-column-seven-blast-v1-report.json').read_text())
terminal = fidelity.strict_json((FIRST_CONTROL / 'stationary-column-seven-blast-v1-terminal.json').read_text())
assert terminal['terminal'] and terminal['exit_code'] == 0
assert report['command']['route_sha256'] == ROUTE_SHA and report['full_state_fork_boundaries'] == 4
assert report['endpoint']['health'] == [22, 0, 0, 0, 0] and report['endpoint']['progress'][:2] == [3, 244]
parent_spec = importlib.util.spec_from_file_location('column_trial_preflight_parent', PARENT)
parent = importlib.util.module_from_spec(parent_spec)
parent_spec.loader.exec_module(parent)
parent.FRAMES, parent.ROUTE, parent.route_bytes = FRAMES, ROUTE_SOURCE, route_bytes
observer = parent.load_observer()
base = observer.base_module()
route_base, prefix_events = base.setup()
assert issubclass(observer.session_class(base), original.OriginalSession) and prefix_events
hashes = {}
for path in sorted(DURABLE.glob('*.py')):
    ast.parse(path.read_text())
    hashes[path.name] = fidelity.sha256(path)
for name in FROZEN_FILES:
    frozen(name)
mock = fidelity.strict_json((_PRIOR / 'atomic-world-v1-test-report.json').read_text()) if False else None
memory = {row.split(':')[0]: int(row.split()[1]) * 1024
          for row in Path('/proc/meminfo').read_text().splitlines()}
windows = int(subprocess.check_output([
    '/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe', '-NoProfile', '-NonInteractive',
    '-Command', '(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory'], text=True).strip()) * 1024
assert windows > 4 * 1024**3 + 2 * 1024**3
assert memory['MemAvailable'] > 8 * 1024**3 + 2 * 1024**3
assert memory['SwapTotal'] == memory['SwapFree']
payload = dict(status='stationary_column_observer_preflight_passed', producer_hashes=hashes,
    frozen_producers=FROZEN_FILES, route_sha256=ROUTE_SHA, capture_budget=reserve(2 * 1024**3),
    planned_level4_frames=LEVEL4_FRAMES, unchanged_original_backed_prefix_last_tick=11420,
    windows_free_physical=windows, linux_mem_available=memory['MemAvailable'],
    transitive_setup_passed=True, historical_atomic_mock_reused=True, atomic_mock_rerun_claim=False,
    candidate_trace_sha256=report['trace_sha256'], source_production_changed=False,
    state_injections=False, original_comparison_claim=False, whole_game_complete=False)
target = DURABLE / 'preflight-v1-report.json'
assert not target.exists()
target.write_bytes(original.json_bytes(payload))
print(json.dumps(payload), flush=True)
