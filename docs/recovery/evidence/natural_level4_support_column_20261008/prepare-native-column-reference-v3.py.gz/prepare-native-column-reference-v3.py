"""Prepare original-only support-column expectations and verify the retained prefix."""
import copy
from datetime import datetime, timezone
import gzip
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

CONTROL = Path(__file__).parent
T9 = CONTROL.parent / 'level4-completion-scout-work-20261007-t9'
T4 = CONTROL.parent / 'level4-third-objective-native-work-20261007-t4'
T11 = CONTROL.parent / 'level4-completion-work-20261007-t11'
FIXTURE_SOURCE = Path('/dev/shm/lezac-reward-checkout-preservation-20261007-t10')
TARGET = Path('/dev/shm/lezac-level4-column-reference-preparation-v3-20261007-t12')
sys.path.insert(0, str(T9))
from common import *


def read(path):
    return fidelity.strict_json(path.read_text())


def main():
    protected()
    assert not TARGET.exists()
    capacity = reserve(128 * 1024**2)
    terminal = read(T9 / 'capture-terminal-receipt.json')
    assert terminal['terminal'] and terminal['exit_code'] == 0
    assert read(T9 / 'capture-process-result.json')['exit_code'] == 0
    assert read(T9 / 'keeper-terminal.json')['terminal']
    previous = read(FIRST_CONTROL / 'next-recovery-checkpoint-v19.json')
    process_checks = {}
    for role, identity in previous['native_column_trial']['live_processes'].items():
        proc = Path('/proc') / str(identity['pid'])
        if proc.exists():
            assert protocol.identity(identity['pid']) != identity
        process_checks[role] = dict(original_identity_terminal=True, identity=identity)
    preparation = read(T9 / 'preparation-proof.json')
    for name, digest in preparation['producer_hashes'].items():
        assert fidelity.sha256(T9 / name) == digest
    audit = read(T9 / 'native-audit.json')
    coherence = read(T9 / 'native-coherence-v1.json')
    assert audit['raw_ds_boundaries'] == coherence['boundaries'] == 7018
    assert audit['level4_frames'] == 2319 and audit['patches_restored']
    assert coherence['differing_byte_observations'] == coherence['normalized_bytes'] == 0
    pins = {
        'level3-handoff.jsonl.gz': audit['native_gate_stream_sha256'],
        'level3-results.jsonl.gz': audit['native_results_sha256'],
        'level4-handoff.jsonl.gz': audit['native_level4_stream_sha256'],
        'results-handoff-ds.bin.gz': audit['raw_ds_sha256'],
        'results-handoff-ds-journal.json': audit['raw_ds_journal_sha256'],
        'level3-route.txt': audit['route_sha256'],
    }
    assert {name: fidelity.sha256(OUT / name) for name in pins} == pins
    assert coherence['raw_sha256'] == pins['results-handoff-ds.bin.gz']
    assert coherence['journal_sha256'] == pins['results-handoff-ds-journal.json']
    outcome = read(OUT / 'outcome-manifest.json')
    assert outcome['status'] == 'captured' and outcome['patches_restored']
    assert outcome['assets'] == {name: fidelity.sha256(ROOT / name) for name in fidelity.ASSETS}
    for name, digest in outcome['files'].items():
        assert fidelity.sha256(fidelity.safe_file(OUT, name)) == digest
    retained = read(T11 / 'support-and-repaired-reward-retention-complete.json')['retention']
    receipt = read(T11 / 'support-and-repaired-reward-retention-terminal-v1.json')
    assert receipt['terminal'] and receipt['exit_code'] == 0
    assert retained['archive_sha256'] == receipt['archive_sha256'] == '4b480ad5e4a04cef08dad1449fd99e0b46827af23617e6b72be6e02a043b42bc'
    assert retained['members'] == 15124
    assert all(retained[key] for key in ('all_member_readback_verified',
        'all_members_size_and_sha256_verified', 'whole_archive_byte_readback_verified',
        'all_notes_tree_anchors_verified'))
    refs = [retained['ref']] + [row['ref'] for row in retained['chunks']]
    remote = subprocess.check_output(['git', '-C', str(ROOT), 'ls-remote', 'origin', *refs], text=True)
    observed = {ref: commit for commit, ref in (line.split() for line in remote.splitlines())}
    expected = {retained['ref']: retained['notes_commit'],
        **{row['ref']: row['notes_commit'] for row in retained['chunks']}}
    assert observed == expected
    assert fidelity.source_version(FIXTURE_SOURCE) == dict(revision='fb448a129c498ed7ddc06db73e1b8f179f6bcfac', dirty=False)
    sys.path.insert(0, str(FIXTURE_SOURCE / 'tools'))
    import natural_level4_third_objective as third
    prior = third.fixture()
    path = T4 / 'compare-level4-native-v2.py'
    assert fidelity.sha256(path) == 'deb7d20c6974c87371016d012b61ac623ddd564977971c8a9c3b98f9427e4d64'
    spec = importlib.util.spec_from_file_location('column_native_only_projection_reader_v2', path)
    decoder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(decoder)
    decoder.LAST, decoder.FRAMES, decoder.ROUTE_SHA = 11740, 2319, pins['level3-route.txt']
    decoder.PREVIEWS = set()
    TARGET.mkdir()
    records = list(decoder.native_records(OUT, TARGET).values())
    assert len(records) == 4700
    assert records[:4060] == prior[1:-1]
    assert len(records[4060:]) == 640
    assert records[-1]['projection']['mapped']['progress'] == [3,244]
    assert records[-1]['projection']['mapped']['players'][0]['energy'] == 22
    assert records[-1]['projection']['mapped']['players'][0]['inventory'] == [200,4,0,0,1]
    header = copy.deepcopy(prior[0])
    header.update(schema='lezac-natural-level4-support-column-v1', ticks=11740,
        frames=2380, boundaries=4700, gameplay_frames=2319, raw_ds_boundaries=7018,
        route_sha256=pins['level3-route.txt'], prior_manifest_sha256=third.MANIFEST_SHA256,
        repeated_prior_boundaries=4060, added_boundaries=640, cpp_expectations_used=False,
        expectations_source='closed_retained_atomic_original_snapshots')
    footer = dict(kind='complete', frames=2380, boundaries=4700, patches_restored=True)
    target = TARGET / 'reference.jsonl.gz'
    with target.open('wb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0, filename='') as stream:
            for row in (header, *records, footer):
                stream.write(original.json_bytes(row))
    restored = handoff.load(target)
    assert restored[0] == header and restored[1:-1] == records and restored[-1] == footer
    shutil.copyfile(OUT / 'level3-route.txt', TARGET / 'route.txt')
    assert fidelity.sha256(TARGET / 'route.txt') == pins['level3-route.txt']
    proof = dict(status='original_only_column_reference_prepared', prepared_utc=datetime.now(timezone.utc).isoformat(),
        reference=str(target), reference_sha256=fidelity.sha256(target), reference_bytes=target.stat().st_size,
        route_sha256=pins['level3-route.txt'], source_sha256=fidelity.sha256(Path(__file__)),
        header=header, native_files=pins, native_processes_closed=process_checks,
        producer_hashes=preparation['producer_hashes'], reader_sha256=fidelity.sha256(path),
        native_retention=retained, remote_retention_refs_verified=observed,
        prior_fixture_manifest_sha256=third.MANIFEST_SHA256,
        repeated_prior_boundaries=4060, added_boundaries=640, native_frames=2380,
        expected_bytes_source='original_only', cpp_outputs_read_for_expected_bytes=False,
        input_injections=False, fresh_cpp_regression_executed=False, tracked_promotion_complete=False,
        capacity_before=capacity, free_after=shutil.disk_usage('/dev/shm').free,
        whole_game_complete=False)
    (TARGET / 'preparation-proof.json').write_bytes(original.json_bytes(proof))
    (CONTROL / 'column-reference-preparation-v3.json').write_bytes(original.json_bytes(proof))
    print(json.dumps({key: proof[key] for key in ('status','reference','reference_sha256','reference_bytes',
        'repeated_prior_boundaries','added_boundaries','native_frames','fresh_cpp_regression_executed')}), flush=True)


if __name__ == '__main__':
    main()
