"""Keep the original observer on its own verified silent X server."""
from common import *
import runpy

runpy.run_path(str(frozen('private-capture.py')), run_name='__main__')
