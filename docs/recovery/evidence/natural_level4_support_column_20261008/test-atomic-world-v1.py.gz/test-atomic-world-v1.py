"""Test the new observer against retained raw DS, including all legacy mismatches."""
from contextlib import contextmanager
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys

ROOT = Path('/mnt/c/Users/andrz/git/LEZAC')
CONTROL = Path(__file__).parent
OLD = Path('/dev/shm/lezac-results-handoff-original-20261006-t1')
sys.path.insert(0, str(ROOT / 'tools'))
import level1_original as original

spec = importlib.util.spec_from_file_location('atomic_world_v1', CONTROL / 'atomic-world-v1.py')
atomic = importlib.util.module_from_spec(spec)
spec.loader.exec_module(atomic)


def load_stream(name):
    with gzip.open(OLD / name, 'rt') as stream:
        return [json.loads(line) for line in stream]


class MockSession:
    ds, base, resident = 0x100000, 0, 0x200000

    def __init__(self, data, state, sequence):
        self.data, self.state, self.sequence = data, state, sequence
        self._atomic_ds, self.atomic_snapshot = None, None
        self.stopped_now, self.ds_reads, self.stop_count, self.scratch_reads = False, 0, 0, 0
        self.fail = None
        self.handshake = struct.pack('<8HI', 3, 0x1234, 0x1334, 0, 0, 0, 0, 0, sequence)
        self.heaps = {}
        for key, pointer in (('tiles', 0xc1e0), ('words', 0x6612)):
            offset, segment = struct.unpack_from('<HH', data, pointer)
            self.heaps[(segment << 4) + offset] = bytes.fromhex(state[key])

    @contextmanager
    def stopped(self):
        assert not self.stopped_now
        self.stopped_now = True
        self.stop_count += 1
        try:
            yield
        finally:
            self.stopped_now = False

    def raw_read(self, at, count):
        assert self.stopped_now, 'mock memory read escaped stopped process'
        if at == self.ds and count == 65536:
            self.ds_reads += 1
            return self.data[:-1] if self.fail == 'short_ds' else self.data
        if at == self.resident + original.SCRATCH and count == 20:
            self.scratch_reads += 1
            value = bytearray(self.handshake)
            if self.fail == 'changed_handshake' and self.scratch_reads > 1:
                value[-1] ^= 1
            return bytes(value)
        if at in self.heaps:
            result = self.heaps[at][:count]
            return result[:-1] if self.fail == 'short_heap' else result
        raise AssertionError(('unexpected mock address', at, count))

    def read(self, at, count):
        return atomic.cached_read(self, at, count, self.raw_read)


def validate(state, dimensions, level):
    assert state['frame'] >= 0 and 1 <= level <= 7
    assert len(bytes.fromhex(state['tiles'])) == dimensions[0] * dimensions[1]
    assert len(bytes.fromhex(state['words'])) == dimensions[0] * dimensions[1] * 2


def capture(session, decoder=original.OriginalSession.state):
    return atomic.capture_world(session, session.raw_read, decoder, validate, original.SCRATCH)


def rejected(session, decoder=original.OriginalSession.state):
    try:
        capture(session, decoder)
    except (AssertionError, original.fidelity.EvidenceError):
        assert session._atomic_ds is None and session.atomic_snapshot is None and not session.stopped_now
        return
    raise AssertionError('invalid snapshot accepted')


def main():
    journal = json.loads((OLD / 'results-handoff-ds-journal.json').read_text())
    reels, level4 = load_stream('level3-results.jsonl.gz'), load_stream('level4-handoff.jsonl.gz')
    rows = {r['sequence']: r['state'] for r in reels[1:-1]}
    rows.update({level4[0]['ack_sequence']: level4[0]['baseline'], level4[0]['intro_sequence']: level4[0]['intro']})
    rows[journal['records'][0]['sequence']] = reels[0]['baseline']
    for row in level4[1:-1]:
        rows.update({row['sequences'][i]: row[key] for i, key in enumerate(('pre', 'rendered', 'post'))})
    legacy, checked, sample = [], 0, None
    with gzip.open(OLD / 'results-handoff-ds.bin.gz', 'rb') as stream:
        for record in journal['records']:
            data = stream.read(65536)
            assert len(data) == 65536 and hashlib.sha256(data).hexdigest() == record['sha256']
            prior = rows[record['sequence']]
            session = MockSession(data, prior, record['sequence'])
            state, dimensions = capture(session)
            assert session.ds_reads == session.stop_count == 1
            assert not session.stopped_now and session._atomic_ds is None
            assert session.atomic_snapshot['data'] == data
            assert session.atomic_snapshot['sequence'] == record['sequence']
            assert dimensions == record['dimensions']
            assert all(state[key] == prior[key] for key in state if key != 'globals')
            for i, (a, b) in enumerate(zip(bytes.fromhex(prior['globals']), data[0x79a0:0x79fa])):
                if a != b:
                    legacy.append(dict(record=record['index'], offset=0x79a0 + i, projected=a, raw=b))
            assert bytes.fromhex(state['globals']) == data[0x79a0:0x79fa]
            checked += 1
            if sample is None:
                sample = data, prior, record['sequence']
        assert not stream.read(1)
    assert checked == 148 and len(legacy) == 11
    assert {r['offset'] for r in legacy} == {0x79a1, 0x79c4}
    negatives = []
    for failure in ('short_ds', 'short_heap', 'changed_handshake'):
        session = MockSession(*sample)
        session.fail = failure
        rejected(session)
        negatives.append(failure)
    for name, offset, replacement in (('bad_level', 0x79b7, b'\0'),
                                      ('bad_scroll', 0x2096, b'\1\0'),
                                      ('bad_dimensions', 0xc204, b'\0\0')):
        data = bytearray(sample[0])
        data[offset:offset + len(replacement)] = replacement
        rejected(MockSession(bytes(data), sample[1], sample[2]))
        negatives.append(name)
    for name, offset in (('wrong_sequence', 16), ('released_gate', 14)):
        session = MockSession(*sample)
        handshake = bytearray(session.handshake)
        handshake[offset] ^= 1
        session.handshake = bytes(handshake)
        rejected(session)
        negatives.append(name)
    def broken_decoder(session):
        raise AssertionError('intentional decoder failure')
    rejected(MockSession(*sample), broken_decoder)
    negatives.append('decoder_failure_releases_stop_and_cache')
    session = MockSession(*sample)
    session._atomic_ds = sample[0]
    try:
        capture(session)
    except AssertionError:
        assert session.stop_count == 0
    else:
        raise AssertionError('nested snapshot accepted')
    negatives.append('nested_snapshot')
    report = dict(status='atomic_snapshot_mock_contract_passed', checked_retained_raw_records=checked,
                  legacy_projection_raw_mismatches=legacy, legacy_mismatch_count=len(legacy),
                  atomic_projection_raw_mismatches=0, ds_reads_per_snapshot=1,
                  negative_contracts_rejected=negatives, raw_capture_mutated=False,
                  source_sha256=hashlib.sha256((CONTROL / 'atomic-world-v1.py').read_bytes()).hexdigest(),
                  test_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  heap_inputs='retained historical projection, mock process only',
                  native_live_capture_claim=False, original_fidelity_claim=False, whole_game_complete=False)
    target = CONTROL / 'atomic-world-v1-test-report.json'
    assert not target.exists()
    target.write_bytes(original.json_bytes(report))
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    main()
