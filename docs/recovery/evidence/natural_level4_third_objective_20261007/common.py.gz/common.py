"""Bind the preserved prefix to the healthy ordinary third-objective route."""
import importlib.util
import os
from pathlib import Path
import shutil
import sys

ROOT = Path('/mnt/c/Users/andrz/git/LEZAC')
DURABLE = Path(__file__).parent
WORK = Path('/dev/shm/lezac-level4-third-native-comparison-20261007-t4')
OUT = Path('/dev/shm/lezac-level4-third-native-original-20261007-t4')
CPP_WORK = Path('/dev/shm/lezac-level3-results-regression-20261006-t1')
OLD_CONTROL = ROOT / 'build-codex-tmp/level3-double-medium-gate-original-work-20261006'
FIRST_CONTROL = ROOT / 'build-codex-tmp/level4-first-objective-native-work-20261007'
PORTAL_CONTROL = ROOT / 'build-codex-tmp/level4-portal-native-work-20261007-t3'
sys.path.insert(0, str(ROOT / 'tools'))
import level1_fidelity as fidelity
import level1_original as original
import level1_handoff as handoff
import natural_campaign as campaign

SOURCE = ROOT / 'build-codex-tmp/level3-first-large-retime-work-20261006/probe-capture-version.py'
assert fidelity.sha256(SOURCE) == '626f4cb419ab7cb315bc7d56d7d80bf0fbfd93a62dbbc78967ef1aec3fc6e5a7'
spec = importlib.util.spec_from_file_location('portal_owned_protocol', SOURCE)
reuse = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reuse)
protocol = reuse.protocol
protocol.DURABLE, protocol.WORK = DURABLE, WORK
protocol.SRC, protocol.EXE = CPP_WORK, Path('/dev/shm/lezac-level3-results-regression-build-20261006-t1/lezac_cpp')
protocol.HEAD = protocol.BUILT_HEAD = '4fe016ad7bfce8ab41f70301b22e7216067df3e5'
protocol.EXE_SHA = 'f25e005ce78add7e2c90926c05440a08e70acd166fdd4924a138c325474db91f'
protocol.MARKER = ['lezac-level4-third-native-keepalive-20261007-t4', '86400']
save, reserve = protocol.save, protocol.reserve
GATE, LAST, FRAMES, LEVEL4_FIRST, LEVEL4_FRAMES = 8905, 11420, 5129, 9422, 1999
NATIVE = Path('/dev/shm/lezac-double-medium-gate-original-20261006-t1/level3-handoff.jsonl.gz')
NATIVE_SHA = '481da8aae48e547d58dd912fdbd5e50d00dedcfb8c21d6ec88d3f66490a999d8'
PARENT = Path('/dev/shm/lezac-level3-east-support-20261006-t1/objective-observer-wrapper.py')
PARENT_SHA = '67fbad0106d75c06652708f8ec9667d2b607665947b26d5811d05e6c1c5206f7'
ROUTE = WORK / 'level4-healthy-third-objective-v1.route'
ROUTE_SOURCE = Path('/dev/shm/lezac-level4-left-pit-early-descent-20261007-t1/route.txt')
ROUTE_SHA = '00e22cf9842b7ae313f5efe966e948abea665cf42f51d5be1d14aed8195c4240'
ATOMIC_SOURCE = DURABLE / 'atomic-world-v1.py'
ATOMIC_SHA = '7c790a582bb2578ea87492f5124b5e05f7400e6cddd271f5eddf9d15b364f741'
assert fidelity.sha256(ATOMIC_SOURCE) == ATOMIC_SHA
atomic_spec = importlib.util.spec_from_file_location('native_atomic_world_v1', ATOMIC_SOURCE)
atomic = importlib.util.module_from_spec(atomic_spec)
atomic_spec.loader.exec_module(atomic)


def load(name):
    return fidelity.strict_json((DURABLE / name).read_text())


def protected():
    protocol.protected()
    assert fidelity.sha256(NATIVE) == NATIVE_SHA and fidelity.sha256(PARENT) == PARENT_SHA
    assert fidelity.sha256(ROUTE_SOURCE) == ROUTE_SHA
    assert fidelity.sha256(ATOMIC_SOURCE) == ATOMIC_SHA


def producer(name):
    assert fidelity.sha256(DURABLE / name) == load('preparation-proof.json')['producer_hashes'][name]


def route_bytes():
    assert fidelity.sha256(ROUTE) == ROUTE_SHA
    settings, events = fidelity.read_route(ROUTE)
    prior_settings, prior = fidelity.read_route(Path('/dev/shm/lezac-level3-double-medium-gate-original-20261006-t1/double-medium-gate-v1.route'))
    assert settings['ticks'] == LAST and prior_settings['ticks'] == GATE
    assert all(settings[key] == prior_settings[key] for key in ('seed', 'step_us'))
    assert {tick: rows for tick, rows in events.items() if tick < GATE} == prior
    prefix = CPP_WORK / 'tests/fixtures/natural_level3_handoff/route.txt'
    assert fidelity.sha256(prefix) == 'f283afd6e746f43f972dc4721139dc18e1526dd801b99168b75704737771e09f'
    assert {tick: rows for tick, rows in events.items() if tick < 9450} == fidelity.read_route(prefix)[1]
    first_route = Path('/dev/shm/lezac-level4-pit-coast-20261007-t1/route.txt')
    assert fidelity.sha256(first_route) == 'a58ae584bf24044d7b437e0e0f54a1a5b91fb35c4f31b3fb346a0ae12a1c132a'
    first_settings, first_events = fidelity.read_route(first_route)
    assert first_settings['ticks'] == 9760
    assert {tick: rows for tick, rows in events.items() if tick < 9760} == first_events
    portal_route = Path('/dev/shm/lezac-level4-portal-left-fall-20261007-t1/route.txt')
    assert fidelity.sha256(portal_route) == '4bef0a96a8a3607025138192956013338a8afb3112d590399c3cc6d992db5b5b'
    portal_settings, portal_events = fidelity.read_route(portal_route)
    assert portal_settings['ticks'] == 10720
    assert {tick: rows for tick, rows in events.items() if tick < 10720} == portal_events
    assert all(event['key'] in original.BANK and event['action'] in ('up', 'down')
               for tick, rows in events.items() if tick >= 9450 for event in rows)
    return ROUTE.read_bytes()
