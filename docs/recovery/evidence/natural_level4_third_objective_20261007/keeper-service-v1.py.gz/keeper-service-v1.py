"""Create one identified silent keeper for this fresh capture attempt."""
from common import *
import json
import subprocess
import time

UNIT = 'lezac-level4-third-keeper-20261007-t4.service'
protected()
assert load('preflight-v1-report.json')['transitive_setup_passed']
assert not OUT.exists() and not (DURABLE / 'preparation-proof.json').exists()
target = DURABLE / 'keeper-service-start-proof.json'
assert not target.exists()
state = subprocess.run(['systemctl', '--user', 'show', UNIT, '--property=LoadState'],
    text=True, capture_output=True)
assert 'LoadState=not-found' in state.stdout
marker, seconds = protocol.MARKER
assert marker == 'lezac-level4-third-native-keepalive-20261007-t4' and seconds == '86400'
command = ['systemd-run', '--user', '--unit=' + UNIT, '--service-type=exec',
    '--working-directory=' + str(ROOT), '--property=Restart=no', '--property=RuntimeMaxSec=7200',
    '--property=KillMode=control-group', '--property=StandardInput=null',
    '--setenv=SDL_AUDIODRIVER=dummy', '/usr/bin/bash', '-c',
    'exec -a ' + marker + ' /usr/bin/sleep ' + seconds]
result = subprocess.run(command, text=True, capture_output=True)
assert result.returncode == 0, result.stderr
for _ in range(20):
    properties = 'ActiveState,SubState,MainPID,ControlGroup,ExecMainCode,ExecMainStatus,Result'
    unit_state = dict(line.split('=', 1) for line in subprocess.check_output([
        'systemctl', '--user', 'show', UNIT, '--property=' + properties], text=True).splitlines())
    assert unit_state['ActiveState'] == 'active' and unit_state['SubState'] == 'running'
    identity = protocol.identity(int(unit_state['MainPID']))
    if identity['argv'] == protocol.MARKER:
        break
    time.sleep(.1)
else:
    raise AssertionError('keeper did not reach its owned sleep executable')
assert identity['exe'] == '/usr/bin/sleep'
proof = dict(unit=UNIT, state=unit_state, identity=identity, command=command,
    launcher_stdout=result.stdout, launcher_stderr=result.stderr, audio='dummy',
    source_sha256=fidelity.sha256(Path(__file__)), native_capture_started=False)
target.write_bytes(original.json_bytes(proof))
print(json.dumps(proof), flush=True)
