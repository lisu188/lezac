"""Read the exact tracked unit without restarting it."""
from common import *
import json
import subprocess

UNIT = 'lezac-level4-third-capture-20261007-t4.service'
protected()
protocol.owner()
properties = 'LoadState,ActiveState,SubState,MainPID,ControlGroup,ExecMainCode,ExecMainStatus,Result'
state = dict(line.split('=', 1) for line in subprocess.check_output([
    'systemctl', '--user', 'show', UNIT, '--property=' + properties], text=True).splitlines())
lines = (WORK / 'run-logs/stdout.txt').read_text().splitlines()
live = state['ActiveState'] == 'active' and state['SubState'] == 'running'
if live:
    assert protocol.identity(int(state['MainPID'])) == load('tracked-service-start-proof.json')['identity']
else:
    assert state['SubState'] in ('exited', 'failed', 'dead') and state['MainPID'] == '0'
payload = dict(status='tracked_original_observer_live' if live else 'tracked_original_observer_terminal',
               unit=UNIT, state=state, latest_output=lines[-3:], capacity=reserve(0))
print(json.dumps(payload), flush=True)
