"""Pack the third-objective expectations exclusively from closed original data."""
import sys
from pathlib import Path

CONTROL = Path(__file__).parent
NATIVE_CONTROL = CONTROL.parent / 'level4-third-objective-native-work-20261007-t4'
sys.path.insert(0, str(NATIVE_CONTROL))
from common import *
import gzip
import importlib.util
import json

TARGET = Path('/dev/shm/lezac-level4-third-objective-regression-20261007-t1')
FIXTURE = TARGET / 'tests/fixtures/natural_level4_third_objective'
EVIDENCE = TARGET / 'docs/recovery/evidence/natural_level4_third_objective_20261007'
PREVIEWS = Path('/dev/shm/lezac-level4-third-reference-pack-20261007-t1')
READER = NATIVE_CONTROL / 'compare-level4-native-v2.py'


def main():
    protected()
    assert fidelity.sha256(READER) == 'deb7d20c6974c87371016d012b61ac623ddd564977971c8a9c3b98f9427e4d64'
    assert not FIXTURE.exists() and not EVIDENCE.exists() and not PREVIEWS.exists()
    assert load('capture-terminal-receipt.json')['exit_code'] == 0
    closed = load('owned-services-closed-v1.json')
    assert closed['keeper_pidfd_terminal_verified'] and closed['capture_state']['MainPID'] == '0'
    assert all(row['original_process_no_longer_live'] for row in closed['closed_processes'])
    assert load('owned-services-closed-v1-tool-receipt.json')['exit_code'] == 0
    retained = load('third-native-retention-complete.json')['retention']
    assert all(retained[key] for key in ('all_notes_tree_anchors_verified',
        'all_member_readback_verified', 'whole_archive_byte_readback_verified'))
    audit = load('native-coherence-v1.json')
    assert audit['boundaries'] == 6058 and audit['differing_byte_observations'] == audit['normalized_bytes'] == 0
    native_audit = load('native-audit.json')
    for name, key in (('level3-handoff.jsonl.gz', 'native_gate_stream_sha256'),
        ('level3-results.jsonl.gz', 'native_results_sha256'), ('level4-handoff.jsonl.gz', 'native_level4_stream_sha256'),
        ('results-handoff-ds.bin.gz', 'raw_ds_sha256'), ('results-handoff-ds-journal.json', 'raw_ds_journal_sha256')):
        assert fidelity.sha256(OUT / name) == native_audit[key]
    assert load('paired-comparison-v1.json')['status'] == 'match'
    assert load('native-comparison-terminal-v1.json')['exit_code'] == 0
    assert all(load('native-extension-tool-receipts-v1.json')[key]['exit_code'] == 0
        for key in ('seal', 'coherence', 'cpp_replay'))
    for name in load('preparation-proof.json')['producer_hashes']:
        producer(name)
    outcome = fidelity.strict_json((OUT / 'outcome-manifest.json').read_text())
    assert outcome['status'] == 'captured' and outcome['patches_restored']
    assert original.fingerprint(OUT) == handoff.PREFIX_SHA256
    for name, digest in outcome['files'].items():
        assert fidelity.sha256(fidelity.safe_file(OUT, name)) == digest
    usage = shutil.disk_usage('/dev/shm')
    assert usage.free - 128 * 1024**2 > usage.total // 10 + 3 * 1024**3
    spec = importlib.util.spec_from_file_location('third_native_reference_reader_v1', READER)
    reader = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reader)
    PREVIEWS.mkdir()
    wanted = reader.native_records(OUT, PREVIEWS)
    progress = reader.native_progression(wanted)
    assert [row['tick'] for row in progress['objective_changes']] == [9680, 10662, 11286]
    assert [row['tick'] for row in progress['portal_transitions']] == [10633, 11301]
    header = dict(kind='header', schema='lezac-natural-level4-third-objective-v1', first_tick=GATE,
        ticks=LAST, gameplay_frames=1999, frames=2060, boundaries=4060, raw_ds_boundaries=6058,
        repeated_original_level3_frames=5129, route_sha256=ROUTE_SHA, assets=outcome['assets'],
        audio='dummy', state_injections=False, completed_levels=[1, 2, 3], entered_level=4,
        native_objective_changes=progress['objective_changes'], native_portal_transitions=progress['portal_transitions'],
        expectations_source='closed_retained_atomic_original_snapshots', cpp_expectations_used=False,
        full_prefix_cpp_comparison_claim=False, full_actor_clock_sound_byte_parity=False,
        level4_completion_claim=False, original_fidelity_claim=False, port_functionally_complete=False)
    rows = [header, *wanted.values(), dict(kind='complete', frames=2060, boundaries=4060, patches_restored=True)]
    FIXTURE.mkdir(parents=True)
    with original.compressed_writer(FIXTURE / 'reference.jsonl.gz') as emit:
        for row in rows:
            emit(row)
    (FIXTURE / 'route.txt').write_bytes(route_bytes())
    entry = handoff.load(OUT / 'level4-handoff.jsonl.gz')
    guarded = campaign.guard_inputs(entry[-2]['post'], entry[-2]['dac'][2], entry[0]['atlas'])
    assert campaign.guard_projection(guarded, rows[-2]['projection']['mapped']) == 291
    (FIXTURE / 'guard-input.json').write_bytes(original.json_bytes(guarded))
    EVIDENCE.mkdir(parents=True)
    names = [*load('preparation-proof.json')['producer_hashes'], 'preparation-proof.json',
        'native-audit.json', 'capture-terminal-receipt.json', 'native-extension-tool-receipts-v1.json',
        'native-coherence-v1.json', 'paired-comparison-v1.json', 'native-comparison-terminal-v1.json',
        'owned-services-closed-v1.json', 'owned-services-closed-v1-tool-receipt.json',
        'third-native-retention-complete.json', 'retain-third-objective-native-v1-tool-receipt.json']
    assert len(names) == len(set(names))
    sources = {name: NATIVE_CONTROL / name for name in names}
    sources[Path(__file__).name] = Path(__file__)
    pins = {}
    for name, source in sources.items():
        data = source.read_bytes()
        (EVIDENCE / (name + '.gz')).write_bytes(gzip.compress(data, mtime=0))
        pins[name] = fidelity.sha256(source)
    manifest = dict(schema='lezac-native-level4-third-objective-evidence-v1', reference_header=header,
        fixture_pins={name: fidelity.sha256(FIXTURE / name) for name in ('reference.jsonl.gz', 'route.txt', 'guard-input.json')},
        producer_pins=pins, raw_native_sha256=native_audit['raw_ds_sha256'],
        raw_native_journal_sha256=native_audit['raw_ds_journal_sha256'],
        native_stream_sha256=native_audit['native_level4_stream_sha256'],
        snapshot_coherence_differences=0, normalized_bytes=0, closed_native_sessions=True,
        all_raw_members_independently_retained=True, expected_bytes_source='original_only')
    (EVIDENCE / 'manifest.json').write_bytes(original.json_bytes(manifest))
    selected = {str(tick) + '_' + phase: wanted['level4', tick, phase]['projection']['mapped']
        for tick in (11286, 11301, 11420) for phase in ('present', 'post_update')}
    report = dict(status='native_only_level4_third_objective_reference_packed', frames=2060, boundaries=4060,
        fixture_pins=manifest['fixture_pins'], manifest_sha256=fidelity.sha256(EVIDENCE / 'manifest.json'),
        producer_count=len(pins), selected_native_states=selected, cpp_expectations_used=False, whole_game_complete=False)
    target = CONTROL / 'third-reference-pack-v1-report.json'
    assert not target.exists()
    target.write_bytes(original.json_bytes(report))
    print(json.dumps({key: value for key, value in report.items() if key != 'selected_native_states'}), flush=True)


if __name__ == '__main__':
    main()
