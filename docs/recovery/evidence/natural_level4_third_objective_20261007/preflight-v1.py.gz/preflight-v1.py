"""Check the new route and complete observer setup without starting a game."""
import ast
import json
import common
from common import *

protected()
common.ROUTE = ROUTE_SOURCE
common.route_bytes()
assert LAST == 11420 and LEVEL4_FIRST == 9422 and LEVEL4_FRAMES == LAST - LEVEL4_FIRST + 1 == 1999
assert not WORK.exists() and not OUT.exists() and not (DURABLE / 'preparation-proof.json').exists()
assert fidelity.sha256(DURABLE / 'atomic-world-v1-test-report.json') == '0c6d167a5d939752968575139f82307c1967a7f5b13f6dbe737d631de1a9d237'
assert fidelity.sha256(DURABLE / 'atomic-world-v1-test-terminal.json') == '7837684cd6e83577d71cc415ca56ddd3017f30227dcca5b2f5900a40ac42a100'
assert fidelity.sha256(DURABLE / 'test-atomic-world-v1.py') == '9e490a33aba2d18187fa1ac821b2f06062543b70f74c6087e9c737b8a0e30e96'
mock = load('atomic-world-v1-test-report.json')
assert mock['checked_retained_raw_records'] == 148 and mock['atomic_projection_raw_mismatches'] == 0
assert len(mock['negative_contracts_rejected']) == 10 and mock['source_sha256'] == ATOMIC_SHA
assert load('atomic-world-v1-test-terminal.json')['exit_code'] == 0
first = fidelity.strict_json((FIRST_CONTROL / 'paired-comparison-v1.json').read_text())
assert first['rgb_differing_frames'] == first['state_differing_boundaries'] == 0
assert first['compared_rgb_frames'] == 400 and first['compared_mapped_boundaries'] == 740
candidate = fidelity.strict_json((FIRST_CONTROL / 'left-pit-early-descent-v1-report.json').read_text())
assert candidate['command']['route_sha256'] == ROUTE_SHA and not candidate['original_comparison_claim']
assert candidate['endpoint']['xy'] == [271.0, 360.0] and candidate['endpoint']['progress'][:2] == [3, 244]
assert candidate['endpoint']['health'] == [22, 0, 0, 0, 0]
assert candidate['full_state_fork_boundaries'] == 4 and candidate['fork_rgb_frames'] == 1
parent_spec = importlib.util.spec_from_file_location('preflight_native_parent', PARENT)
parent = importlib.util.module_from_spec(parent_spec)
parent_spec.loader.exec_module(parent)
parent.FRAMES, parent.ROUTE, parent.route_bytes = FRAMES, ROUTE_SOURCE, common.route_bytes
observer = parent.load_observer()
base = observer.base_module()
route_base, prefix_events = base.setup()
session_type = observer.session_class(base)
assert observer.FRAMES == FRAMES and observer.FIRST_TICK == 3777
assert issubclass(session_type, original.OriginalSession) and prefix_events
hashes = {}
for path in sorted(DURABLE.glob('*.py')):
    ast.parse(path.read_text())
    hashes[path.name] = fidelity.sha256(path)
report = dict(status='third_objective_observer_transitive_setup_preflight_passed',
    producer_hashes=hashes, route_sha256=ROUTE_SHA, first_cpp_tick=LEVEL4_FIRST,
    last_cpp_tick=LAST, planned_level4_frames=LEVEL4_FRAMES,
    unchanged_original_backed_input_prefix_last_tick=10720,
    transitive_setup_passed=True, transitive_level2_events=len(prefix_events),
    observer_source=str(observer.__file__), observer_sha256=fidelity.sha256(Path(observer.__file__)),
    outcome_source=str(base.__file__), outcome_sha256=fidelity.sha256(Path(base.__file__)),
    session_class=session_type.__name__, owned_protocol_source=str(protocol.__file__),
    historical_atomic_mock_reused=True, atomic_mock_rerun_claim=False,
    capture_budget=reserve(2 * 1024**3), native_capture_launched=False,
    keeper_launched=False, source_production_changed=False,
    original_portal_comparison_claim=False, whole_game_complete=False)
target = DURABLE / 'preflight-v1-report.json'
assert not target.exists()
target.write_bytes(original.json_bytes(report))
print(json.dumps(report), flush=True)
