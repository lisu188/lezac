"""Freeze the third-objective observer after its new owned keeper exists."""
from common import *
import json
import subprocess

protected()
assert load('atomic-world-v1-test-report.json')['status'] == 'atomic_snapshot_mock_contract_passed'
assert load('atomic-world-v1-test-report.json')['source_sha256'] == ATOMIC_SHA
assert load('atomic-world-v1-test-terminal.json')['exit_code'] == 0
capacity = reserve(2 * 1024**3)
assert not OUT.exists() and not (DURABLE / 'preparation-proof.json').exists()
if WORK.exists():
    assert sorted(path.name for path in WORK.iterdir()) == [ROUTE.name]
    route_bytes()
owners = []
for path in Path('/proc').iterdir():
    if not path.name.isdigit():
        continue
    try:
        item = protocol.identity(int(path.name))
        if item['argv'] == protocol.MARKER:
            assert item['exe'] == '/usr/bin/sleep'
            owners.append(item)
    except (FileNotFoundError, ProcessLookupError, PermissionError):
        pass
assert len(owners) == 1
unit = sys.argv[1]
assert unit == 'lezac-level4-third-keeper-20261007-t4.service'
unit_state = dict(line.split('=', 1) for line in subprocess.check_output([
    'systemctl', '--user', 'show', unit, '--property=ActiveState,SubState,MainPID'], text=True).splitlines())
assert unit_state['ActiveState'] == 'active' and unit_state['SubState'] == 'running'
assert int(unit_state['MainPID']) == owners[0]['pid']
first = fidelity.strict_json((FIRST_CONTROL / 'paired-comparison-v1.json').read_text())
assert first['rgb_differing_frames'] == first['state_differing_boundaries'] == 0
assert first['compared_rgb_frames'] == 400 and first['compared_mapped_boundaries'] == 740
candidate = fidelity.strict_json((FIRST_CONTROL / 'left-pit-early-descent-v1-report.json').read_text())
assert candidate['status'] == 'closed_cpp_only_route_candidate'
assert candidate['command']['route_sha256'] == ROUTE_SHA
assert candidate['endpoint']['xy'] == [271.0, 360.0] and candidate['endpoint']['progress'][:2] == [3, 244]
assert candidate['endpoint']['health'] == [22, 0, 0, 0, 0]
assert candidate['full_state_fork_boundaries'] == 4 and not candidate['original_comparison_claim']
for name in ('left-pit-early-descent-v1-terminal.json',):
    assert fidelity.strict_json((FIRST_CONTROL / name).read_text())['exit_code'] == 0
WORK.mkdir(exist_ok=True)
if ROUTE.exists():
    assert ROUTE.read_bytes() == ROUTE_SOURCE.read_bytes()
else:
    shutil.copyfile(ROUTE_SOURCE, ROUTE)
route_bytes()
hashes = {name: fidelity.sha256(DURABLE / name) for name in (
    'common.py', 'prepare-v1.py', 'capture.py', 'private-capture.py', 'launch-capture-v1.py',
    'atomic-world-v1.py', 'test-atomic-world-v1.py', 'preflight-v1.py',
    'service-launch-v1.py', 'keeper-service-v1.py', 'observe-service-v2.py',
    'replay-level4-cpp-v1.py', 'compare-level4-native-v2.py', 'audit-level4-native-v1.py')}
dependencies = [fidelity.strict_json((PORTAL_CONTROL / name).read_text())['retention'] for name in (
    'portal-pickup-retention-complete.json', 'healthy-third-pickup-retention-complete.json',
    'support-scout-retention-complete.json', 'portal-regression-retention-complete.json')]
transport = protocol.transport_module()
for retained in dependencies:
    assert retained['all_member_readback_verified'] and retained['all_notes_tree_anchors_verified']
    for row in [retained, *retained['chunks']]:
        assert transport.git(ROOT, 'ls-remote', 'origin', row['ref']).split() == [row['notes_commit'], row['ref']]
save('preparation-proof.json', dict(status='original_healthy_third_objective_observer_prepared', capacity=capacity,
    keeper=dict(identity=owners[0], tool_session=None, service_unit=unit, service_state=unit_state), producer_hashes=hashes,
    source_head=protocol.HEAD, executable_sha256=protocol.EXE_SHA, route_sha256=ROUTE_SHA,
    prior_native_stream_sha256=NATIVE_SHA, unchanged_level3_frames=FRAMES,
    independently_retained_dependencies=dependencies, audio='dummy', new_gameplay_state_injections=False,
    original_portal_route_compared=False, historical_atomic_mock_reused=True,
    atomic_mock_rerun_claim=False, transitive_preflight=load('preflight-v1-report.json'), whole_game_complete=False))
protocol.owner()
print('Owned silent third-objective observer, unchanged native prefix and reserve verified', flush=True)
