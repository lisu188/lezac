"""Run only under one identified private X server, with dummy audio."""
from common import *
import runpy

protected()
protocol.owner()
producer('private-capture.py')
assert os.environ.get('SDL_AUDIODRIVER') == 'dummy' and os.environ.get('SDL_VIDEODRIVER') == 'x11'
display = os.environ.get('DISPLAY')
assert display and os.environ.get('XAUTHORITY')
servers = []
for path in Path('/proc').iterdir():
    if not path.name.isdigit():
        continue
    try:
        item = protocol.identity(int(path.name))
        if Path(item['exe']).name == 'Xvfb' and display in item['argv']:
            servers.append(item)
    except (FileNotFoundError, ProcessLookupError, PermissionError):
        pass
assert len(servers) == 1 and not OUT.exists()
save('private-display-proof.json', dict(private_display_server=servers[0], actual_literal_output=str(OUT),
    source_sha256=fidelity.sha256(Path(__file__)), capture_sha256=fidelity.sha256(DURABLE / 'capture.py'),
    route_sha256=ROUTE_SHA, audio='dummy', video='x11', new_gameplay_state_injections=False, whole_game_complete=False))
sys.argv = [str(DURABLE / 'capture.py'), '--approve-procmem', '--approve-runtime-instrumentation']
runpy.run_path(str(DURABLE / 'capture.py'), run_name='__main__')
