import hashlib
import importlib.util
from pathlib import Path
import sys

ROOT = Path('/mnt/c/Users/andrz/git/LEZAC')
OUT = Path('/dev/shm/lezac-timed-writeback-20261005')
sys.path.insert(0, str(ROOT / 'tools'))
import capture_original_monster_writeback as writeback
import capture_original_timed_gravity as timed

spec = importlib.util.spec_from_file_location('timed_writeback_support', OUT / 'discovery-helper.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
helper.ROOT = ROOT
HOOKS = (helper.HOOKS[0], timed.HOOKS[1], writeback.HOOKS[2])
FRICTION = bytes.fromhex('5589e531c09adf0420098b7e04368b45f49931d029d03d2b007d0b8b7e0431c0368945f4eb1c8b7e0436837df4007d0a8b7e04368345f42aeb088b7e0436836df42ac9c20200')
WINDOWS = dict(writeback.WINDOWS) | dict(HOOKS) | {0x701C: timed.RAW + bytes.fromhex('807edf00740455e82eebe9'), 0x5b86: FRICTION}
PROFILES = ((32760, 24), (24, 32760), (32760, 32760), (-32760, 24), (24, -32760), (-32760, -32760), (24, 32765), (32765, 32765))
original_runtime_windows = helper.runtime_windows


def runtime_windows(load_segment):
    windows = original_runtime_windows(load_segment)
    raw = bytearray(windows[0x5b86])
    struct.pack_into('<H', raw, 8, (struct.unpack_from('<H', raw, 8)[0] + load_segment) & 0xffff)
    windows[0x5b86] = bytes(raw)
    return windows


import struct
helper.runtime_windows = runtime_windows


def cases():
    rows = []
    def add(kind, mask, glyph, vx, vy, profile=0, x=336, y=99):
        cells = {1: ((41, 12), (41, 13)), 2: ((44, 12), (44, 13)),
                 4: ((42, 11), (43, 11)), 8: ((42, 14), (43, 14))} if kind == 12 else {
                 1: ((41, 13),), 2: ((43, 13),), 4: ((42, 12),), 8: ((42, 14),)}
        rows.append({'index': len(rows), 'kind': kind, 'mask': 0, 'edge_mask': mask, 'glyph': glyph,
                     'vx': vx, 'vy': vy, 'x': x, 'y': y, 'profile': profile,
                     'frac_x': 165, 'frac_y': 90, 'mode': 0, 'frame': 420 + (mask & 1),
                     'ai0': 14, 'ai1': 271, 'ai2': 75, 'hp_byte': 255,
                     'tiles': [[cx, cy, glyph] for bit, positions in cells.items() if mask & bit for cx, cy in positions]})
    for kind in (12, 13):
        for glyph in (0, 1, 0x4c, 0x4d, 0x52, 0x53, 0x75, 0xff):
            for mask in range(16):
                add(kind, mask, glyph, -513 if mask & 1 else 513, -513 if mask & 4 else 513)
    for kind in (12, 13):
        for mask in (1, 2, 8, 9, 10, 15):
            for vx in (-32768, -32767, -513, -1, 0, 1, 513, 32767):
                for vy in (-32768, -64, 0, 1, 32704):
                    add(kind, mask, 1, vx, vy, 1)
    for profile, (x, y) in enumerate(PROFILES, 2):
        for kind in (12, 13):
            for vx in (-32768, -256, 0, 32767):
                for vy in (-32768, -256, 0, 512, 1983, 32704, 32767):
                    add(kind, 0, 0, vx, vy, profile, x, y)
    assert len(rows) == 1184
    return tuple(rows)


CASES = cases()


def configure():
    helper.HOOKS, helper.WINDOWS, helper.CASES = HOOKS, WINDOWS, CASES
    helper.RELOCATIONS = {0x7134, 0x7146, 0x5b8e}


def self_check():
    configure()
    image = helper.self_check()
    print('timed_writeback_discovery_self_check=ok cases=1184 kinds=12,13 live=0', flush=True)
    return image


def capture(*args):
    configure()
    report = helper.capture(*args, retain_writeback=True)
    report.update(schema='lezac-timed-writeback-discovery-v1', profile_coverage=list(range(10)),
                  complete_coordinate_writeback_observed=True, hotspot_seed=6, timer_seed=11,
                  shared_actor_profiles=True, natural_constructor_claim=False,
                  executed_discovery_helper_sha256=hashlib.sha256((OUT / 'discovery-helper.py').read_bytes()).hexdigest())
    return report


if __name__ == '__main__':
    configure()
    base = helper.base
    base.HOOKS, base.WINDOWS, base.CASES = HOOKS, WINDOWS, CASES
    base.self_check, base.trampoline, base.capture = self_check, helper.trampoline, capture
    base.runtime_windows = helper.runtime_windows
    base.__file__ = __file__
    raise SystemExit(base.main())
