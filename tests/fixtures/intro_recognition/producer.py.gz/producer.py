"""Pin the owned RAM session, restore the unchanged executable and package captures."""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import tarfile
import zipfile

from PIL import Image

ROOT = Path('/mnt/c/Users/andrz/git/LEZAC')
WORK = Path('/dev/shm/lezac-intro-recognition-20261005')
DURABLE = ROOT / 'build-codex-tmp/intro-recognition-work-20261005'
BASE = 'ad4751e55351998d73cd92482ad085c866b05308'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    for parent in (WORK, DURABLE):
        (parent / name).write_bytes(data)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--keeper-session', type=int, required=True)
    args = parser.parse_args()
    assert not WORK.exists()
    assert shutil.disk_usage('/dev/shm').free > 10 * 1024**3
    assert digest((ROOT / 'AGENTS.md').read_bytes()) == '0d57cf7e656d018fe6c756171e98a31ee5bab0f12387bc4106f1140eece426ea'
    assert digest((ROOT / 'LEZAC.EXE').read_bytes()) == '7579255148c2cb540b26f70dc8181c50b218b6808d8fa5208c832391bafa53ec'
    expected_args = ['lezac-intro-recognition-keepalive-20261005', '86400']
    identities = []
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            cmd = [part.decode() for part in (proc / 'cmdline').read_bytes().split(b'\0') if part]
            if cmd == expected_args:
                assert os.readlink(proc / 'exe') == '/usr/bin/sleep'
                identities.append(dict(pid=int(proc.name), cmdline=cmd, exe='/usr/bin/sleep',
                    start_ticks=int((proc / 'stat').read_text().rsplit(')', 1)[1].split()[19]),
                    boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip()))
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    assert len(identities) == 1
    WORK.mkdir()
    save('keeper-identity.json', dict(keeper=identities[0], tool_session=args.keeper_session,
        base=BASE, observed_at_utc=datetime.now(timezone.utc).isoformat(), audio='dummy'))
    prior = json.loads((ROOT / 'build-codex-tmp/level3-destruction-work-20261005/exact-package-proof.json').read_text())
    artifact = prior['artifact']
    raw = subprocess.check_output(['gh', 'api', 'repos/lisu188/lezac/actions/artifacts/' + str(artifact['id']) + '/zip'])
    assert digest(raw) == artifact['digest'].removeprefix('sha256:')
    package = WORK / 'exact-package'
    package.mkdir()
    (package / 'artifact.zip').write_bytes(raw)
    with zipfile.ZipFile(io.BytesIO(raw)) as bundle:
        assert bundle.namelist() == ['lezac-linux-x86_64.tar.gz']
        data = bundle.read(bundle.namelist()[0])
    (package / 'payload.tar.gz').write_bytes(data)
    seen = set()
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as bundle:
        for member in bundle:
            name = PurePosixPath(member.name)
            assert not name.is_absolute() and '..' not in name.parts and (member.isdir() or member.isfile())
            path = package / member.name
            if member.isdir():
                path.mkdir(parents=True, exist_ok=True)
                continue
            assert member.name in prior['payload_files'] and member.name not in seen
            payload = bundle.extractfile(member).read()
            expected = prior['payload_files'][member.name]
            assert len(payload) == expected['bytes'] and digest(payload) == expected['sha256']
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(payload)
            path.chmod(member.mode)
            seen.add(member.name)
    assert seen == set(prior['payload_files'])
    exe = package / 'lezac/lezac_cpp'
    assert digest(exe.read_bytes()) == prior['executable_sha256']
    save('exact-package-proof.json', dict(status='unchanged_game_package_restored', artifact=artifact,
        executable=str(exe), executable_sha256=digest(exe.read_bytes()), all_payload_files_verified=True,
        base=BASE, source_head=prior['package_source_head'], audio='dummy', whole_game_complete=False))

    fixture = ROOT / 'tests/fixtures/intro_recognition'
    assert not fixture.exists()
    fixture.mkdir()
    sources = {
        'original-intro': ROOT / 'docs/recovery/evidence/intro_buffer_awaiting_20260930.png',
        'ci-failure-intro': ROOT / 'build-codex-tmp/level3-destruction-work-20261005/ci-bios-failure-frame.png',
        'original-gameplay-one': ROOT / 'docs/recovery/evidence/menu_held_choice_gameplay_20260930.png',
        'original-gameplay-two': ROOT / 'docs/recovery/evidence/menu_held_two_gameplay_20260930.png',
    }
    records = {}
    for name, source in sources.items():
        image = Image.open(source).convert('RGB')
        assert image.size == (320, 200)
        ppm = b'P6\n320 200\n255\n' + image.tobytes()
        compressed = gzip.compress(ppm, mtime=0)
        (fixture / (name + '.ppm.gz')).write_bytes(compressed)
        records[name] = dict(file=name + '.ppm.gz', gzip_sha256=digest(compressed),
            ppm_sha256=digest(ppm), rgb_sha256=digest(image.tobytes()),
            source_png=source.relative_to(ROOT).as_posix(), source_png_sha256=digest(source.read_bytes()))
    native = json.loads((ROOT / 'docs/recovery/evidence/intro_buffer_original_20260930.json').read_text())
    assert native['captures'][3]['pixel_sha256'] == records['original-intro']['rgb_sha256']
    assert native['status'] == 'observed' and native['audio'] == 'dummy' and native['hooks_restored'] == 1
    observer = ROOT / 'docs/recovery/evidence/intro_buffer_observer_20260930.py.gz'
    assert digest(gzip.decompress(observer.read_bytes())) == native['observer_sha256']
    assert records['ci-failure-intro']['rgb_sha256'] == 'f8d71fb8a1fe037c95fdc6d443765a967e81e3966d947cf1c0b9c46eef09ab6d'
    manifest = dict(schema=1, scope='Italian Level 1 intro scene recognition, not whole-game parity',
        frames=records, original_record='docs/recovery/evidence/intro_buffer_original_20260930.json',
        original_record_sha256=digest((ROOT / 'docs/recovery/evidence/intro_buffer_original_20260930.json').read_bytes()),
        original_observer=observer.relative_to(ROOT).as_posix(), original_observer_sha256=native['observer_sha256'],
        original_exe_sha256=digest((ROOT / 'LEZAC.EXE').read_bytes()),
        ci_failure=dict(run=37368764559, job=111960302952, artifact=11370823585, head=BASE,
            executable_sha256=prior['executable_sha256'], failure_preserved=True),
        producer_sha256=digest(Path(__file__).read_bytes()), whole_game_parity=False)
    (fixture / 'producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
    (fixture / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    save('fixture-packaging-proof.json', dict(manifest_sha256=digest((fixture / 'manifest.json').read_bytes()),
        frames=records, original_caption_white=620, original_caption_shadow=360))
    print(json.dumps(dict(status='prepared', frames=len(records),
        manifest_sha256=digest((fixture / 'manifest.json').read_bytes()))), flush=True)


if __name__ == '__main__':
    main()
